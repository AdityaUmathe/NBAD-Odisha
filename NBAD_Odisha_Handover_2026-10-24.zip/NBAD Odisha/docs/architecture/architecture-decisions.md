# NBAD Architecture Decision Records

**Status of this log:** draft v0.1 (2026-10-24). **No decision has been approved.** S-03 §9 calls D-01 to D-07 "design decisions we have already made". Here they are carried forward as *Proposed*, because no approval record exists.

**Status values:**

| Status | Meaning |
|---|---|
| Proposed | Recommended, awaiting approval |
| Proposed — pending benchmark | Recommended, but cannot be approved until a named gate passes |
| Accepted | Approved, with the approver and date recorded |
| Rejected | Considered and not adopted |
| Superseded | Replaced by a later ADR |

**How to review:** the approver records `Accepted (name/role, date)` or `Rejected (reason)` in the Status field and adds a line to [CHANGELOG.md](../../CHANGELOG.md). A change to an Accepted ADR needs a new ADR that supersedes it.

## Index

| ADR | Title | Status | Source |
|---|---|---|---|
| ADR-001 | Passive-only collection (TAP/SPAN/flow export); no inline devices | Proposed | S-03 D-01, TR-17 |
| ADR-002 | Separate stores per data class | Proposed | S-03 D-02 |
| ADR-003 | Durable replicated queue between collection and processing | Proposed | S-03 D-03 |
| ADR-004 | Rules and baselines first; ML as an additional explainable scorer | Proposed | S-03 D-04 |
| ADR-005 | Control plane separated from data plane | Proposed | S-03 D-05 |
| ADR-006 | Fully offline install, update and operation; no outbound path by default | Proposed | S-03 D-06, TR-35 |
| ADR-007 | Canonical, versioned schema and common event envelope | Proposed | S-03 D-07 |
| ADR-008 | One analyst console; third-party UIs used only as back ends | Proposed | TR-02, TR-39, C-11 |
| ADR-009 | PostgreSQL HA: primary + streaming standby; failover method pending | Proposed — pending decision | OBL-04 |
| ADR-010 | No per-host / per-flow licensed components in analytics paths | Proposed | TR-37, C-13 |
| ADR-011 | Spare capacity means ≤ 70% of tested ceiling at peak (÷ 0.7) | Proposed | OBL-04, C-03 |
| ADR-012 | Response actions limited to Suggest and Prepare in R1 | Proposed | TR-10, C-06 |
| ADR-013 | Flow/session store: ClickHouse (Option C), OpenSearch as fallback | Proposed — pending benchmark G-T1/G-T2 | technology-evaluation §5 |
| ADR-014 | Packet archive: custom PCAP writer + per-session index on local storage | Proposed — pending benchmark G-T3 | technology-evaluation §2.3 |
| ADR-015 | Ingest queue: Apache Kafka (KRaft) | Proposed — pending B-03 | technology-evaluation §2.5 |
| ADR-016 | Capture: AF_PACKET + Zeek; Suricata included if CPU headroom allows | Proposed — pending G-T4 | technology-evaluation §2.1–2.2 |
| ADR-017 | Flow collector: goflow2 | Proposed — pending exporter samples | technology-evaluation §2.4 |
| ADR-018 | Services in Go; console in React + TypeScript | Proposed — pending team-skill confirmation | technology-evaluation §2.6, §2.9 |
| ADR-019 | Deployment: systemd-managed services, Ansible, no Kubernetes in R1 | Proposed | technology-evaluation §2.9 |
| ADR-020 | Observability: Prometheus/Alertmanager/Grafana; log aggregation pending | Proposed — pending licence review | technology-evaluation §2.9 |
| ADR-021 | Secrets & PKI: OPTCL's vault/CA if available, else OpenBao + internal CA | Proposed — pending Q-25 | technology-evaluation §2.9 |
| ADR-022 | Benchmark definitions PD-01 (TR-36) and PD-02 (TR-41) | Proposed — needs OPTCL confirmation | A-05, A-06 |
| ADR-023 | Remote-server-only development, build, test and deployment | Accepted (project lead instruction, S-11, 2026-10-24) | S-11 |
| ADR-024 | Schema registry as versioned JSON Schema files in the repository | Proposed | data-flow-and-contracts §8 |

## Records

### ADR-001 — Passive-only collection
- **Context:** TR-17 requires non-intrusive monitoring. NBAD watches a production power-utility network.
- **Alternatives:** inline sensors (rejected: risk to production traffic); active scanning by NBAD (rejected: out of scope, and vulnerability data comes from INT-08).
- **Decision:** TAP, SPAN/ERSPAN and flow export only. Capture NICs are receive-only.
- **Consequences:** no blocking capability; SPAN loss must be monitored; no traffic modification.

### ADR-002 — Separate stores per data class
- **Context:** PCAP (≈ 5.5 TB/day at 512 Mbps sustained) and searchable metadata have different write and read patterns. TR-36 needs fast record retrieval.
- **Alternatives:** a single store for everything (rejected unless a benchmark proves it, as S-03 notes).
- **Decision:** PCAP archive, analytics store, transactional store and baseline/model store are kept separate.
- **Consequences:** evidence links (`packet_ref`, `evidence_ref`) are first-class; more than one store to operate.

### ADR-003 — Durable replicated queue
- **Context:** bursts, downstream outages and replay needs (P2).
- **Alternatives:** direct insert from collectors (rejected for production, technology-evaluation §2.5).
- **Decision:** a replicated queue (RF 3, min in-sync 2) between collection and processing, with local spools at the producers.
- **Consequences:** a 3-node cluster to operate; consumers must be idempotent.

### ADR-004 — Rules and baselines first, ML second
- **Context:** POC predictability, explainability (DR-06), SOW-06 false-positive reduction.
- **Alternatives:** ML-first (rejected: opaque, needs a stable baseline period, harder to validate).
- **Decision:** deterministic rules, thresholds and robust baselines form the foundation. ML (Phase 10) adds a further scorer that stores contributing features. Models are promoted only with a recorded approval.
- **Consequences:** TR-24 "undiscovered patterns" is covered first by new-edge, new-host, new-country and baseline detectors, then by ML.

### ADR-005 — Control plane separated from data plane
- **Decision:** the data plane runs from cached configuration. Failure of the API, console or PostgreSQL does not stop capture, spooling or queueing.
- **Consequences:** configuration distribution must be versioned and cached on the data-plane nodes.

### ADR-006 — Fully offline operation
- **Decision:** every artifact goes through the offline supply chain. No outbound path is enabled by default. The egress soak test (ST-01) is required before go-live.
- **Consequences:** threat intelligence is only as fresh as the import cadence (C-05). The UI has no CDN assets.

### ADR-007 — Canonical schema and envelope
- **Decision:** as defined in data-flow-and-contracts §4–§8.
- **Consequences:** a mapping layer per source; fields are frozen only after real samples are reviewed (Phase 5 gate).

### ADR-008 — Single console
- **Context:** TR-02 and TR-39 require one console for logs and raw packets.
- **Decision:** all analyst functions, including PCAP retrieval and playback, are in the NBAD console. Third-party UIs (Arkime, Grafana) are not part of the analyst workflow. Grafana may serve operations staff.
- **Consequences:** the console must implement packet retrieval and download/playback views.

### ADR-009 — PostgreSQL HA
- **Context:** OBL-04 (no single point of failure).
- **Alternatives:**
  - (a) streaming replication + documented manual promotion: simplest, but RTO depends on on-call response;
  - (b) Patroni + etcd (etcd can run with the queue coordination nodes): automatic failover, more components;
  - (c) OPTCL's existing database platform, if one exists.
- **Recommendation:** (b) if the RTO agreed under Q-14 is under about 15 minutes; otherwise (a).
- **Status:** pending Q-14.

### ADR-010 — No per-host/per-flow licensing in analytics
- **Decision:** components on analytics and ML paths must not be licensed per host, flow or interface (TR-37).
- **Consequences:** nProbe and commercial ML/NDR engines are excluded unless the commercial owner approves.

### ADR-011 — Spare capacity interpretation
- **Decision:** peak demand ≤ 70% of the tested ceiling, per tier (÷ 0.7). This replaces the ×1.3 margin in S-02/S-08.
- **Consequences:** sizing about 10% larger than S-08. The tender definition must be confirmed (Q-26).

### ADR-012 — Response actions limited in R1
- **Decision:** R1 provides Suggest and Prepare only. Execute-with-approval needs a later ADR plus OPTCL authorisation. Automatic is out of scope.
- **Consequences:** TR-10 is met by real-time suggestions; no risk of NBAD disrupting the network.

### ADR-013 — Flow/session store (pending benchmark)
- **Decision (provisional):** ClickHouse for flows, sessions, packet_ref and health records; PostgreSQL for alerts and state.
- **Gates:** G-T1 and G-T2 (technology-evaluation §5.1).
- **Fallback:** Option A (OpenSearch).
- **Consequences if accepted:** weaker free-text search, so search is designed around structured filters.

### ADR-014 — Packet archive (pending benchmark)
- **Decision (provisional):** a sensor-side rotating PCAP writer, per-session offset index in `packet_ref`, local XFS on RAID, replication to a second archive node (RF subject to AD-05).
- **Gate:** G-T3.
- **Fallback:** Arkime capture with its index in OpenSearch, which moves the platform to Option A.

### ADR-015 — Queue: Kafka (KRaft)
- **Alternatives:** Redpanda (licence concern), NATS JetStream (fewer connectors).
- **Gate:** B-03.

### ADR-016 — Capture and analyzers
- **Decision (provisional):** AF_PACKET with fanout, plus Zeek workers. Suricata on the same sensor if B-01 shows ≤ 70% CPU at 130% load; otherwise on a separate sensor or omitted.
- **Gate:** G-T4.

### ADR-017 — Flow collector: goflow2
- **Gate:** template and sampling compatibility with OPTCL exporter samples (Q-09).
- **Fallback:** pmacct.

### ADR-018 — Go services, React/TS console
- **Context:** single static binaries simplify offline delivery.
- **Gate:** team-skill confirmation (Q-30). Java is the alternative.

### ADR-019 — Deployment model
- **Decision:** services managed by systemd (native packages or Podman containers) and configured with Ansible from the management node. No Kubernetes in R1.
- **Consequences:** HA comes from each product's own replication, not from an orchestrator.

### ADR-020 — Observability
- **Decision:** Prometheus, Alertmanager, node_exporter. Grafana for operations views.
- **Pending:** AGPL acceptance (G-T5) and the log aggregation choice.

### ADR-021 — Secrets and PKI
- **Decision (provisional):** reuse OPTCL's vault/HSM and CA if they exist; otherwise OpenBao plus an internal CA.
- **Pending:** Q-25.

### ADR-022 — Benchmark definitions
- **PD-01 (TR-36):** one forensic query over normalized flow/session records, filtered by a time range and at least one entity attribute, returning ≥ 5,000,000 matching records exported to a file on the platform side within 180 s, while normal ingest and detection run.
- **PD-02 (TR-41):** "normalized packet data" means session/protocol metadata plus flow records. It excludes per-packet rows and payload copies.
- **Status:** these must be confirmed with OPTCL **before** acceptance testing.

### ADR-023 — Remote-server-only development (Accepted)
- **Decision:** all development, dependency installation, builds, runtime tests and deployments happen only on the server the project lead authorises. The local machine holds documentation and planning only.
- **Approver:** project lead instruction (S-11), restated 2026-10-24.

### ADR-024 — Schema registry as files
- **Decision:** JSON Schema files, versioned in the repository and validated in CMP-NRM. No registry service in R1.

## Decisions requiring approval (AD list)

Each item needs a decision from the project lead (or OPTCL where stated). Recommendations are given.

| ID | Decision | Options | Recommendation | Who decides |
|---|---|---|---|---|
| AD-01 | Technology direction for the prototype and proof of technology | A / B / C | Option C as the target, benchmarked against A (technology-evaluation §5) | Project lead |
| AD-02 | Proposed definitions PD-01 and PD-02 for TR-36/TR-41 | Accept / modify | Accept as working definitions and send to OPTCL for confirmation | Project lead → OPTCL |
| AD-03 | Spare-capacity interpretation | ×1.3 / ÷0.7 | ÷ 0.7 (ADR-011) | Project lead → confirm in tender |
| AD-04 | Response-action scope in R1 | Suggest+Prepare / +Execute / +Automatic | Suggest + Prepare (ADR-012) | Project lead + OPTCL |
| AD-05 | PCAP replication | RF 2 across nodes / RF 1 + RAID | RF 2 for the DC edge archive, if the budget allows (evidence survives a node loss) | Project lead + OPTCL |
| AD-06 | Working zone model | A-03 / other | Use A-03 until OPTCL confirms | Project lead |
| AD-07 | Single management node as an accepted exception to no-SPOF | Accept / add second node | Accept for R1 if OPTCL agrees that monitoring/backup degradation is not "downtime"; otherwise add a node | Project lead + OPTCL |
| AD-08 | Implementation language | Go / Java | Go (ADR-018) | Project lead (team skills) |
| AD-09 | Orchestration | systemd+Ansible / Kubernetes | systemd + Ansible (ADR-019) | Project lead |
| AD-10 | Version control | Initialise Git now (local docs repo) / on the remote server only / an OPTCL-hosted remote | Initialise Git for the documentation now. The code repository is created on the remote server in Phase 3. | Project lead |
| AD-11 | Role of the remote server | Dev only / dev + staging / representative benchmark host | Treat it as dev. Request representative hardware for B-01/B-05/B-06 (Q-29). | Project lead |
| AD-12 | Suricata in R1 | Yes / No / separate sensor | Yes, pending G-T4 | Project lead |
| AD-13 | SLDC collection | Flow-only / sensors | Flow-only (A-07) | OPTCL |
| AD-14 | GPL/AGPL component acceptance | Accept / substitute | Submit the list to OPTCL licence policy (Q-17) | OPTCL / commercial |
