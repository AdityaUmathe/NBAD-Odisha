# NBAD Open Questions and Risks

**Status:** draft v0.1 (2026-10-24). Owners are **roles** (S-02 §15). No named individuals have been assigned, and none are invented here.
**Priority:**

| Priority | Meaning |
|---|---|
| P1 | Blocks sizing, technology selection or acceptance |
| P2 | Blocks a later phase |
| P3 | Refinement |

## 1. Open questions

| ID | Question | Impact if unanswered | Pri | Responsible role | Closure criterion | Status |
|---|---|---|---|---|---|---|
| Q-01 | What exactly is TR-36 "retrieve at least 5M records within 180 s"? Record type, time window, filters, concurrency, background load, and does "retrieve" mean execute, render, export or deliver? | Search tier and hardware cannot be fixed. Acceptance test undefined. | P1 | Bid lead → OPTCL | Written definition (or acceptance of PD-01) | Open |
| Q-02 | What is "normalized packet data" (TR-41)? Per-packet rows, per-session records, or a payload copy? Is payload included? | 15-day storage varies from about 1 TB to about 83 TB+ | P1 | Bid lead → OPTCL | Written definition (or acceptance of PD-02) | Open |
| Q-03 | What are the "3 separate zones" (TR-01)? | Zone model, dashboards, policies | P1 | Network engineering → OPTCL | Zone list with subnets and sites | Open |
| Q-04 | Basis of 512 Mbps (TR-42): sustained or peak, per direction or aggregate, which link, before or after NAT | Sensor and archive sizing | P1 | Network engineering → OPTCL | Written basis + interface counters | Open |
| Q-05 | Hypervisor and virtual switch products (TR-16) | Virtual visibility design | P2 | Network engineering | Product and version list | Open |
| Q-06 | Network topology: observation points, TAP/SPAN feasibility per link, existing packet brokers | Collection design | P1 | Network engineering | Approved observation-point list | Open |
| Q-07 | Measured traffic profile per observation point: avg/peak Mbps, pps, packet sizes, flows/s, encrypted share (inputs I-01 to I-05) | All sizing | P1 | Network engineering | Worksheet filled with sources and dates | Open |
| Q-08 | SLDC scope: number of sites, links, whether packet capture is required, whether they are in the first deployment (C-02) | Scope and cost | P1 | Bid lead → OPTCL | Written scope | Open |
| Q-09 | Exporter inventory: vendor, model, firmware, NetFlow/IPFIX/sFlow versions, templates, sampling, timers | Collector choice and mapping | P1 | Network engineering | Compatibility matrix rows + sample data | Open |
| Q-10 | SIEM product, version, accepted formats, ports, who writes the parser | INT-01 design | P1 | Integration owner → OPTCL | Product sheet + test endpoint | Open |
| Q-11 | Commercial interpretation of TR-37 (ML for unlimited hosts without additional licence) | Compliance risk | P1 | Bid/commercial owner | Written position | Open |
| Q-12 | Air-gap boundary, approved transfer method, approval authority and turnaround | Update and feed process | P1 | Security → OPTCL | Written boundary description | Open |
| Q-13 | NAT at the DC edge: can capture happen inside NAT? Are NAT logs available? | TR-09 origin identification | P1 | Network engineering | Decision + log sample | Open |
| Q-14 | RTO, RPO, uptime measurement window, maintenance treatment, second-site expectation | HA design (ADR-009) | P1 | Operations → OPTCL | Agreed values in capacity-and-resilience §5.3 | Open |
| Q-15 | Original 107-page tender: Annexure-2, Schedule-4/13, PQR, POC procedure, pass thresholds, dates, acceptance authority, real-time latency expectations (AM-06), asterisk markers (C-09) | All requirements | P1 | Bid lead | Clause-by-clause review against S-01 | Open |
| Q-16 | OPTCL policies to enforce: forbidden services, directions, countries, "unnecessary" ports (TR-14) | Policy detections | P2 | SOC → OPTCL | Policy list | Open |
| Q-17 | Does OPTCL accept open source, including GPL/AGPL? What is the support policy? | Stack eligibility (G-T5) | P1 | Commercial owner → OPTCL | Written policy | Open |
| Q-18 | Approved OS, virtualisation, hardware vendors, rack/power/cooling, failure-domain separation | Deployment design | P2 | Operations / facilities | Constraints list | Open |
| Q-19 | Retention for alerts, incidents and audit. Legal hold. Do replicas/backups count toward TR-41? Are retention periods minimums or maximums? | Storage and deletion | P2 | Security → OPTCL | Retention policy | Open |
| Q-20 | AD structure, groups for role mapping, MFA mechanism, user↔IP sources (DC logon events, DHCP, VPN) | Auth and identity context | P2 | Identity owner | Directory details | Open |
| Q-21 | Vulnerability scanner product and API or export format | INT-08, TR-32 | P2 | Integration owner | Product + sample export | Open |
| Q-22 | Sandbox product, API, size and throughput limits | INT-10, TR-40b | P2 | Integration owner | Product sheet | Open |
| Q-23 | Firewall, IPS, VPN, proxy products and log formats | INT-04 to INT-07 | P2 | Integration owner | Product list + samples | Open |
| Q-24 | Threat-intel sources, licences, desired cadence | INT-09, TR-34 | P2 | SOC / security | Feed list | Open |
| Q-25 | Cryptographic standards, approved algorithms, key custody, existing CA/vault/HSM, hardening baseline | ADR-021, security §8 | P2 | Security → OPTCL | Standards document | Open |
| Q-26 | Exact tender definition of "30% spare capacity at peak" (C-03) | Sizing ±10% | P1 | Bid lead | Clause text | Open |
| Q-27 | Data-locality boundary "SLDC" vs "OPTCL" premises, and who approves outbound movement (C-04) | Outbound paths | P1 | Bid lead → OPTCL | Written boundary + approver | Open |
| Q-28 | Who is the "OEM" for a self-built platform (C-10)? Support staffing for 24x7x365. Annual OEM audit. BOQ unit (AM-09). | Commercial and support model | P1 | Commercial owner | Commercial position | Open |
| Q-29 | Remote server details: purpose, OS, resources, network access, whether representative hardware is available for B-01/B-05/B-06 | Phase 2 onward | P1 | Project lead | Credentials + assessment report | **Waiting for the project lead** |
| Q-30 | Team composition and language skills (Go/Java/React) | ADR-018 | P2 | Project lead | Decision AD-08 | Open |
| Q-31 | GeoIP database source and licence | TR-40b country context | P2 | Commercial owner | Licence decision | Open |
| Q-32 | Host/asset count per zone. Concurrent analysts and forensic queries (A-11). | Sizing | P2 | SOC / network | Numbers | Open |
| Q-33 | Approval to use benign OPTCL traffic samples for baselines and testing, and how samples are transferred to the dev server | Detection testing | P2 | Security → OPTCL | Written approval | Open |
| Q-34 | Meaning of "isolate such traffic" (TR-40b, C-08). Future response-action policy. | ADR-012 scope | P2 | Bid lead → OPTCL | Written clarification | Open |
| Q-35 | Version control: where the repository will live (local Git, remote server, OPTCL-hosted) (AD-10) | Change tracking | P2 | Project lead | Decision | Open |

## 2. Risks

Likelihood (L) and impact (I) are rated H/M/L. The ratings are judgement, not measurement.

| ID | Risk | L | I | Mitigation | Responsible role | Trigger / closure |
|---|---|---|---|---|---|---|
| R-01 | Traffic profile unknown, leading to undersized capture/storage or overspend | H | H | Measure (Q-07). Size ÷ 0.7. Benchmarks B-01/B-04. | Network + data engineering | Closed when the worksheet is complete and B-04 has passed |
| R-02 | Working copy S-01 is incomplete or inaccurate (C-09) | M | H | Clause-by-clause review of the original tender (Q-15) | Bid lead | Review completed |
| R-03 | Packet loss under load weakens evidence and detection | M | H | NIC/driver benchmark, loss metrics, overlap sensors, capture-loss flags | Network engineering | B-01 passes at 130% |
| R-04 | TR-36 cannot be met under the definition OPTCL chooses | M | H | Agree PD-01 early. Benchmark both stores. Query guards and separate export pool. | Data engineering | G-T1 passed under the agreed definition |
| R-05 | "Normalized packet data" defined as per-packet or payload, so storage multiplies | M | H | Close Q-02 before procurement | Bid lead | Q-02 closed |
| R-06 | Forensic queries compete with real-time detection | M | M | Resource isolation, concurrency limits, replica for exports | Data engineering | B-05 + B-09 run concurrently with ingest |
| R-07 | False positives or poisoned baselines overwhelm analysts | M | H | Cold-start controls, maintenance windows, freeze/rollback, monitor-only rule rollout, verdict tracking | Detection engineering | False-positive rate within agreed target in POC |
| R-08 | Air-gap dependencies overlooked (call-home, CDN, licence checks) | M | H | Dependency inventory, default-deny egress, ST-01 soak test | Security / DevOps | ST-01 passes |
| R-09 | TR-37 licensing interpretation challenged | M | H | ADR-010 + written commercial position (Q-11) | Commercial owner | Q-11 closed |
| R-10 | Detection claims are overstated in the bid (OBL-06: binding, no roadmap features) | M | H | Claim only tested capabilities (DR-07). Visibility limits stated (TR-11c). | Bid lead + detection engineering | Every "Yes" backed by a test record |
| R-11 | Shared dependencies (power, switch, hypervisor, DNS, time) undermine no-SPOF | M | H | Failure-domain review. Anti-affinity. Redundant NTP/DNS. | DevOps/SRE | Failure-domain review signed off |
| R-12 | Encrypted traffic limits TR-33/TR-27/TR-40b capabilities | H | M | Metadata analytics. Proxy-log enrichment. State the limits openly. | Detection engineering | Limits accepted by bid lead/OPTCL |
| R-13 | NAT hides internal hosts (TR-09) | M | M | Inside-NAT capture or NAT logs (Q-13) | Network engineering | Q-13 closed |
| R-14 | Five-year support burden of open-source and custom code (OBL-01/02, DR-05) | M | H | Minimise the number of products (P10). Support routes table. Component EOL inventory. | Commercial + architecture lead | Support routes confirmed |
| R-15 | Dev server is not representative, so performance and HA cannot be proven there (A-10) | H | H | Request representative hardware for B-01/B-05/B-06/B-11. Never extrapolate to claims. | Project lead | Q-29 closed with suitable hardware |
| R-16 | Dev server has no Internet, so dependency delivery slows Phase 3 | M | M | Prepare the offline dependency route early (security §6). Find out in Phase 2. | DevOps | Phase 2 assessment |
| R-17 | Custom PCAP indexing (ADR-014) takes longer than planned | M | M | Time-box the PoT. Arkime fallback (G-T3). | Data engineering | G-T3 decided |
| R-18 | Integration products lack usable APIs/formats, or no test instances are available | M | M | Early product inventory (Q-10, Q-21 to Q-23). File-import fallbacks. | Integration owner | Test endpoints available |
| R-19 | Scope creep into SIEM/UEBA functions | M | M | Keep NBAD's boundary (system-architecture §1). Changes go through ADRs. | Architecture lead | Ongoing |
| R-20 | Timeline expectations: the blueprint indicates 22 weeks (S-02 §14) while the effort estimate given to the project lead is about 7–11 months for the full scope | M | M | Phase gates with explicit dependencies. Re-estimate after Phase 2 and Q-07. | Project lead | Re-estimate recorded |
| R-21 | Secrets leak into the repository or logs | L | H | Placeholders only. Secret store. Pre-commit secret scan once Git is in place. Static checks. | All engineers | Ongoing check |
| R-22 | Active response action disrupts the production network | L | H | ADR-012 (no execution in R1) | Architecture lead | ADR-012 accepted |
