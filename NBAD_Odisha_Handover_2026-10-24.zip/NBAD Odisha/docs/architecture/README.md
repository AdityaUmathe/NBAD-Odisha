# NBAD Architecture Documentation

**Project:** OPTCL Next Generation SOC & NOC — Network Behaviour Anomaly Detection (NBAD)
**Status:** PROPOSED architecture, draft v0.1 (2026-10-24). **No decision has been approved and nothing has been implemented, benchmarked or deployed.**

## Document index

| Document | Content |
|---|---|
| [system-architecture.md](system-architecture.md) | Context, principles, four planes, components, trust boundaries, observation and collection, zones, topology, latency budget, failure behaviour, visibility limits |
| [data-flow-and-contracts.md](data-flow-and-contracts.md) | Data categories and stores, event lifecycle, envelope, canonical schemas, IDs and deduplication, validation, schema evolution, ownership, API/SIEM contracts, retention |
| [technology-evaluation.md](technology-evaluation.md) | Per-category options, Options A/B/C, weighted scorecard, provisional recommendation, decision gates, support routes |
| [capacity-and-resilience.md](capacity-and-resilience.md) | Sizing inputs and formulas, low/base/high scenarios, failure domains, backpressure, RTO/RPO decisions, backup, benchmark plan |
| [security-and-airgap.md](security-and-airgap.md) | Threat model, zones, RBAC, secrets, offline supply chain, content import, cryptography, outbound path register, audit, hardening, security tests |
| [integration-design.md](integration-design.md) | Integration inventory (SIEM, AD/LDAP, appliances, vulnerability management, TI, sandbox, …), response-action levels |
| [architecture-decisions.md](architecture-decisions.md) | ADR-001 to ADR-024 and the approval list AD-01 to AD-14 |
| [open-questions-and-risks.md](open-questions-and-risks.md) | Q-01 to Q-35, R-01 to R-22, with closure criteria |
| [implementation-roadmap.md](implementation-roadmap.md) | Phases 0 to 13, dependencies, acceptance criteria, effort assumptions |

Related:

- [../requirements/](../requirements/) — baseline, conflicts, traceability
- [../implementation/master-checklist.md](../implementation/master-checklist.md)
- [../testing/test-strategy.md](../testing/test-strategy.md)
- [../operations/](../operations/)

## Provisional architecture in one paragraph

Passive collection: a TAP at the DC Internet edge (inside NAT) feeds two sensors running AF_PACKET + Zeek (Suricata pending), which also write rotating PCAP. Network devices export NetFlow/IPFIX/sFlow to two collectors. Everything lands in a 3-node Kafka queue. Go workers normalize to a versioned canonical schema, enrich from local caches, and run rules, thresholds, baselines, graph and TI detections, with ML added in Phase 10. Flows, sessions and packet references go to ClickHouse. Alerts, incidents, assets, rules, config and audit go to PostgreSQL. Raw PCAP sits on replicated local storage. A single React console on a versioned Go API provides investigation from alert to flow to packet. Alerts go to the SIEM over syslog-TLS/REST. Everything is installed and updated offline, with no outbound path by default. **This is Option C, provisional, pending benchmark gates G-T1 to G-T6. Option A (OpenSearch + Arkime) is the fallback.**

## Labels used throughout

| Label | Meaning |
|---|---|
| EXPLICIT | Stated in the tender working copy (S-01). Still to verify against the original. |
| DERIVED | Our necessary interpretation |
| PROPOSED | Our design, not approved |
| ASSUMPTION | Working assumption (A-xx) |
| Estimate / scenario | Calculated, not measured |
| Unverified | Compatibility or behaviour not tested |

## How decisions are reviewed

1. The reviewer reads the ADR and the AD list in [architecture-decisions.md](architecture-decisions.md).
2. For each AD item, the reviewer records accept, modify or reject with a reason. The engineer then updates the ADR status (`Accepted (role, date)`) and `CHANGELOG.md`.
3. ADRs marked *pending benchmark* can only be accepted after their gate result is recorded in `docs/testing/results/`.
4. A changed decision gets a new ADR that supersedes the old one. Accepted ADRs are never silently edited.
5. Open questions close only when their closure criterion is met. The answer and its source are recorded in the Q table.
