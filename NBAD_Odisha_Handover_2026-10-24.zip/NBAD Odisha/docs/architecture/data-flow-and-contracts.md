# NBAD Data Flows and Contracts

**Status:** PROPOSED — draft v0.1 (2026-10-24). Schemas are representative. They have **not** been checked against real exporter, Zeek/Suricata, SIEM or vendor output from the OPTCL environment. Field mappings are frozen only after sample data is reviewed (Phase 5 gate).
**Refines:** S-05 (Data Model and Schema Specification v0.1). Differences are listed in §12.

## 1. Data categories and stores

| Category | Record types | Store (provisional, see ADR-013/014) | Write pattern | Retention (proposed) | Sensitivity |
|---|---|---|---|---|---|
| Raw packets | PCAP files | CMP-PCA packet archive | Sequential append, very high volume | **≥ 7 days** (TR-41) | RESTRICTED |
| Normalized network data | flow, session, packet_ref | CMP-FST analytics store | Bulk append, high volume | **≥ 15 days** (TR-41, PD-02) | INTERNAL (flow), RESTRICTED (session) |
| Detections & cases | alert, incident, evidence_ref | CMP-PGS | Insert and update, low/medium volume | OPTCL policy (Q-19). Placeholder 1 year. | INTERNAL |
| Context | asset, indicator, zone/subnet, identity cache | CMP-PGS (+ cache in workers) | Upsert | Assets: life of asset. Indicators: until expiry + 90 d audit tail. | INTERNAL / RESTRICTED (identity) |
| Baselines & models | baseline_profile, model artifacts | CMP-BMS (analytics-store tables + artifact files) | Periodic recompute, snapshot | Rolling, plus N snapshots for rollback | INTERNAL |
| Health | health | CMP-FST (+ Prometheus for operations metrics) | Append | 30 d placeholder | OPERATIONAL |
| Audit | audit | CMP-PGS append-only tables, exported to backup | Append-only | OPTCL policy (Q-19) | RESTRICTED |
| Quarantine | quarantined raw events | Queue topic + analytics-store table | Append | 7 d placeholder | Same as source |

**Sensitivity classes (proposed):**

| Class | Meaning |
|---|---|
| OPERATIONAL | No customer content |
| INTERNAL | Network metadata |
| RESTRICTED | Payload, URLs/DNS names, identities, audit |
| SECRET | Credentials or keys. Never stored in data stores. Secret store only. |

Access to RESTRICTED payload (PCAP download or playback) is a separate permission from viewing alerts (security-and-airgap §4).

## 2. End-to-end data flow

```mermaid
flowchart LR
    subgraph SRC["Sources"]
        EXP["Flow exporters"]
        MIR["Mirrored packets"]
        SYS["Syslog sources<br/>NAT · proxy · VPN · IPS"]
        CTX["Context pulls<br/>LDAP · vuln scanner"]
        IMP["Offline imports<br/>TI · GeoIP · rules"]
    end
    subgraph COL["Collection"]
        FLC["Flow collector"]
        SEN["Sensor: analyzer + PCAP writer"]
        LGC["Log receiver"]
    end
    subgraph Q["Ingest queue (topics)"]
        RAW["raw.flow · raw.session · raw.ids · raw.log"]
        NORM["norm.flow · norm.session · norm.packet_ref · norm.health"]
        QUA["quarantine"]
        ALR["alert.v1"]
        OUT["out.siem"]
    end
    EXP --> FLC --> RAW
    MIR --> SEN --> RAW
    SEN --> PCA[("Packet archive")]
    SYS --> LGC --> RAW
    RAW --> NRM["Normalize · validate · dedupe · enrich"]
    NRM --> NORM
    NRM --> QUA
    CTX --> PGS[("PostgreSQL")]
    IMP --> TIF["Content import"] --> PGS
    PGS -. "cached context" .-> NRM
    NORM --> FST[("Analytics store")]
    NORM --> DET["Detection"]
    FST --> DET
    DET --> ALR --> COR["Correlation / incidents"] --> PGS
    COR --> OUT --> SIEMC["SIEM connector"]
```

### 2.1 Event lifecycle

| Step | Owner | Guarantee | On failure |
|---|---|---|---|
| 1 Observe | Sensor / collector / receiver | Records stamped with `source.*`, `event_time` and `ingest_time` (collector clock) | Drops counted as health records (`capture_drops`, `seq_gaps`) |
| 2 Publish raw | Same | At-least-once into `raw.*`. Local spool when the queue is down. | Spool full → counted drops plus a critical health alarm |
| 3 Normalize | CMP-NRM | Deterministic mapping. Stable `event_id`. Schema validation. | Invalid → `quarantine` with reason code. The original is kept. |
| 4 Enrich | CMP-NRM | Context only from local caches. Every enrichment field records its source and cache version. | Cache stale → enrichment marked `stale`. The event is not blocked. |
| 5 Persist | Store writer | Idempotent insert keyed on `event_id` (the store deduplicates, or a dedupe window is applied) | Store unavailable → consumer pauses, queue retains, lag alarm |
| 6 Detect | CMP-DET | Alert carries rule/model version, evidence refs, observed and expected values | Worker crash → rebalance and replay. Alert IDs deterministic, so no duplicate alerts. |
| 7 Correlate | CMP-COR | One incident per correlated group. Lifecycle audited. | DB down → alerts accumulate in `alert.v1` |
| 8 Forward | CMP-INT | At-least-once to the SIEM. `event_id` is the deduplication key. | SIEM down → `out.siem` retains. Backlog alarm. |
| 9 Retain/delete | Retention job | Deletes only data past its retention minimum, and never data under legal hold | Job failure → retention-age alarm |

## 3. Conventions

| Topic | Rule |
|---|---|
| Time | All timestamps are UTC, ISO 8601 with `Z`, millisecond precision (microsecond where the sensor provides it). The original source timestamp and timezone are kept in `source.original_time` and `source.original_tz` when they differ. |
| Clock quality | Each sensor and collector publishes `clock_offset_ms` in health. Records produced while the offset is above threshold carry `quality.clock_suspect = true`. |
| Naming | snake_case. Dotted groups (`src.ip`, `dst.port`), as in S-05. |
| IP | One field for IPv4 and IPv6, using the native IP type in the store |
| Missing vs zero | **Absent or null = unknown or not applicable. Zero = measured zero.** Empty strings are never used as "unknown". Counters from sampled flows are scaled and flagged `quality.estimated = true`. |
| Raw retention | `raw` (original fields) kept on session and flow records for the normalized retention period where storage permits, so records can be re-normalized after a mapping fix (S-05 §2) |
| Enumerations | Closed enums are validated. Unknown values map to `other` and the original is kept in `raw`. |
| Community ID | Flows and sessions carry `community_id` (the open Community ID flow-hash standard, supported by Zeek and Suricata, to be confirmed for the chosen versions) to correlate across tools and sensors |

## 4. Common event envelope (all canonical records)

| Field | Type | Req. | Description |
|---|---|---|---|
| `event_id` | string (32 hex) | R | Stable, deterministic ID (§6). Idempotency key. |
| `record_type` | enum | R | `flow`, `session`, `packet_ref`, `alert`, `incident`, `asset`, `baseline_profile`, `indicator`, `evidence_ref`, `health`, `audit` |
| `schema_version` | string `MAJOR.MINOR` | R | Version of this record type's schema, for example `1.0` |
| `source.type` | enum | R | `netflow_v5`, `netflow_v9`, `ipfix`, `sflow`, `zeek`, `suricata`, `pcap_writer`, `syslog_fw`, `syslog_proxy`, `syslog_vpn`, `syslog_ips`, `ldap`, `vuln_import`, `ti_import`, `nbad_internal` |
| `source.id` | string | R | Sensor, exporter or connector identifier from the inventory |
| `source.observation_point` | string | O | Observation point ID (for example `dc-inet-edge-in`) |
| `source.zone` | string | O | Zone of the observation point |
| `event_time` | timestamp | R | When the observed activity happened (for a flow: `start_time`) |
| `ingest_time` | timestamp | R | When the collector received the record |
| `normalize_time` | timestamp | R | When CMP-NRM produced the canonical record |
| `provenance.pipeline_version` | string | R | Normalizer build or mapping version |
| `provenance.raw_ref` | string | O | Queue topic/partition/offset or file ref of the original |
| `provenance.transport_secure` | bool | O | Whether the record arrived over an authenticated or encrypted transport |
| `correlation.community_id` | string | O | Flow hash |
| `correlation.flow_id` / `session_id` / `incident_id` | string | O | Links |
| `quality` | object | O | `estimated`, `clock_suspect`, `capture_loss`, `partial` (one-sided) flags |
| `sensitivity` | enum | R | `operational`, `internal`, `restricted` |

## 5. Record schemas (representative)

### 5.1 `flow` (v1.0)

Fields follow S-05 §4, plus:

| Field | Type | Req. | Notes |
|---|---|---|---|
| `flow_id` | string | R | Equal to `event_id` |
| `start_time`, `end_time` | timestamp | R | |
| `duration_ms` | int | R | Derived |
| `src.ip`, `dst.ip` | ip | R | As observed |
| `src.port`, `dst.port` | int | O | Absent when the protocol has no ports |
| `protocol` | int (IANA) | R | |
| `protocol_name` | string | O | |
| `tcp_flags` | int | O | Cumulative |
| `bytes_src_to_dst`, `bytes_dst_to_src` | int | O | Absent if the exporter is unidirectional and the reverse direction is unknown |
| `packets_src_to_dst`, `packets_dst_to_src` | int | O | |
| `sampling_rate` | int | O | 1 = unsampled. Counters already scaled when > 1, with `quality.estimated` |
| `input_interface`, `output_interface` | int | O | Exporter ifIndex. The name is resolved via inventory/SNMP. |
| `zone_src`, `zone_dst`, `subnet_src`, `subnet_dst`, `site_src`, `site_dst` | string | O | From the zone model |
| `orientation` | enum | O | `inbound`, `outbound`, `internal`, `east_west` |
| `app_protocol` | string | O | Detected application (from a session join or exporter NBAR/AVC-type fields if present) |
| `country_src`, `country_dst` | ISO 3166-1 alpha-2 | O | Plus `geo_db_version` |
| `asset_src_id`, `asset_dst_id` | string | O | |
| `nat.*` | object | O | Pre/post-NAT addresses from NAT-log correlation (TR-09) |
| `segment` | object | O | `{index, of, stitched_from[]}` for long flows split by exporter timers |
| `raw` | object | O | Original fields |

Sample (illustrative, not real data):

```json
{
  "event_id": "9f1c2a7e4b0d4c1e8a3f6b2d7c9e1a04",
  "record_type": "flow",
  "schema_version": "1.0",
  "source": {"type": "ipfix", "id": "exp-dc-fw-01", "observation_point": "dc-inet-edge-in", "zone": "Z1"},
  "event_time": "2026-10-21T08:14:02.120Z",
  "ingest_time": "2026-10-21T08:15:03.004Z",
  "normalize_time": "2026-10-21T08:15:03.410Z",
  "provenance": {"pipeline_version": "norm-0.1.0", "raw_ref": "raw.flow/3/1882771"},
  "flow_id": "9f1c2a7e4b0d4c1e8a3f6b2d7c9e1a04",
  "start_time": "2026-10-21T08:14:02.120Z",
  "end_time": "2026-10-21T08:14:59.870Z",
  "duration_ms": 57750,
  "src": {"ip": "10.20.4.17", "port": 51522},
  "dst": {"ip": "198.51.100.23", "port": 443},
  "protocol": 6, "protocol_name": "tcp",
  "bytes_src_to_dst": 18234, "bytes_dst_to_src": 912311,
  "packets_src_to_dst": 211, "packets_dst_to_src": 688,
  "sampling_rate": 1,
  "zone_src": "Z3", "zone_dst": "external", "orientation": "outbound",
  "country_dst": "ZZ", "geo_db_version": "geo-2026-10-01",
  "correlation": {"community_id": "1:hO+sN4H+MG5MY/8hIrXPqc4ZQz0="},
  "sensitivity": "internal"
}
```

The example addresses are documentation ranges (RFC 5737/1918) and the country code `ZZ` is a placeholder.

### 5.2 `session` (v1.0)

Contains every flow field plus protocol groups (S-05 §5): `dns.*`, `http.*` (cleartext only), `tls.*` (version, SNI, cert subject/issuer, fingerprint hashes, ALPN), `file.*` (name, MIME type, size, hashes, `extracted_ref`), `ssh.*`, `smb.*`, `smtp.*`, `ftp.*`. Also:

| Field | Notes |
|---|---|
| `session_id` | = `event_id` |
| `analyzer` | `zeek` / `suricata` + version |
| `app_detected`, `app_expected_for_port` | Supports the non-standard port and tunnelling detections (TR-13, TR-27) |
| `payload_visibility` | `cleartext`, `encrypted`, `partial`, `none` (TR-33 limit) |
| `http.content_type_req`, `http.content_type_resp`, `http.direction` | TR-33, cleartext only |
| `packet_ref_ids[]` | Links to packet references |
| `quality.partial` | One-sided session (asymmetric routing) |

### 5.3 `packet_ref` (v1.0)

S-05 §6 fields: `packet_ref_id`, `sensor_id`, `interface`, `file_key`, `offset_start`/`offset_end` (or a packet index range), `time_start`, `time_end`, `sha256` (of the file or segment), `session_id`/`flow_id`, `capture_loss_flag`. Also: `archive_node[]` (replica locations), `retention_until`, `legal_hold` (bool).

### 5.4 `alert` (v1.0)

Follows S-05 §7. Required fields: `alert_id`, `detection.name`, `detection.category`, `detection.method` (`rule`|`threshold`|`baseline`|`graph`|`intel`|`signature`|`ml`), `rule_id` + `rule_version` **or** `model_id` + `model_version`, `severity` (`informational`|`low`|`medium`|`high`|`critical`), `confidence` (0–1), `risk_score` (0–100), `scoring_version`, `first_seen`, `last_seen`, `src.*`, `dst.*` (where applicable), `observed`, `expected`, `window`, `contributing_features[]`, `evidence_ref_id`, `status`.
Optional fields: `incident_id`, `threat_refs[]`, `recommended_action`, `action_state` (`none`|`suggested`|`prepared`|`approved`|`executed`|`failed`|`rolled_back`), `count` (deduplicated repeats), `quality` (inherited, for example `capture_loss`).

**Severity is impact and confidence is likelihood.** They are separate fields (S-06 §2). The tender's "High, Medium, Low etc." (TR-15) maps onto the 5-level scale (S-06 §6).

The S-05 sample alert (`horizontal_scan`, `scan-rules-1.3`) is the reference example.

### 5.5 `evidence_ref` (v1.0)

| Field | Notes |
|---|---|
| `evidence_ref_id` | |
| `owner_type`, `owner_id` | `alert` or `incident` |
| `flow_ids[]`, `session_ids[]`, `packet_ref_ids[]` | Bounded lists (cap configurable, for example 1,000), plus `query` (a saved, reproducible query) for larger sets |
| `time_range` | Covering window |
| `capture_loss_in_range` | bool. Evidence completeness warning. |
| `integrity` | Hashes of referenced packet segments at alert time |
| `retention_state` | `available`, `partially_expired`, `expired`, `legal_hold` |

Evidence older than raw-packet retention keeps its flow and session references, and the console shows packets as expired.

### 5.6 `incident` (v1.0)

As S-05 §8. Lifecycle: `new → triaged → investigating → contained → resolved → closed`, plus `false_positive`. Every transition writes an `audit` record and a timeline entry. `siem_reference` stores the forwarded IDs.

### 5.7 `asset` (v1.0)

As S-05 §9. Also: `discovery_source` (`traffic`, `ldap`, `vuln_import`, `manual`), `first_seen_on_network` per zone, `vuln_summary.scan_date` and `vuln_summary.stale` (bool), `services_seen[]` with `first_seen`/`last_seen` (TR-14, TR-32).

### 5.8 `baseline_profile` (v1.0)

As S-05 §10: `entity_type`, `entity_id`, `metric`, `bucket` (hour-of-week 0–167, plus roll-ups for hour/day/week, TR-31), `statistics` (median, p90, p99, mean, std, ewma, sample_count), `model_version`, `learning_state` (`learning`|`active`|`frozen`|`stale`), `min_samples`, `updated_at`, `snapshot_id`.

### 5.9 `indicator` (v1.0)

As S-05 §11. `valid_until` is **required**, and import is rejected without it. Also: `import_batch_id`, `signature_status` (`verified`|`failed`), `enabled`.

### 5.10 `health` (v1.0)

| Field | Notes |
|---|---|
| `component`, `instance` | |
| `metric` | `capture_packets`, `capture_drops`, `if_drops`, `spool_bytes`, `seq_gaps`, `exporter_silence_s`, `clock_offset_ms`, `queue_lag`, `connector_last_success`, … |
| `value`, `unit`, `interval_s` | |
| `status` | `ok` / `warn` / `crit` |

Health records drive the evidence-quality flags. Operations metrics are also exposed to Prometheus. These two outputs are intentionally separate (S-09 §5: the health alert path is separate from the security alert path).

### 5.11 `audit` (v1.0)

| Field | Notes |
|---|---|
| `audit_id`, `time` | |
| `actor.user`, `actor.role`, `actor.source_ip`, `actor.auth_method` | |
| `action` | Controlled vocabulary: `login`, `login_failed`, `role_change`, `rule_create`, `rule_update`, `packet_search`, `packet_download`, `export`, `incident_update`, `config_change`, `content_import`, `break_glass_use`, … |
| `target_type`, `target_id` | |
| `before`, `after` | Values, with secrets redacted |
| `reason` | Required for exports, break-glass use and suppressions |
| `result` | `success` / `denied` / `error` |
| `prev_hash`, `hash` | Hash chain for tamper evidence (security-and-airgap §10) |

## 6. Identity, deduplication and idempotency

| Record | `event_id` derivation (proposed) | Deduplication |
|---|---|---|
| flow | `hash(source.id, exporter_observation_domain, src.ip, src.port, dst.ip, dst.port, protocol, start_time_ms)` | Same exporter replay: identical ID, so the store deduplicates. Same flow from two observation points: different IDs, with a `dedup_group` = `hash(community_id, start_time bucketed 1 s)` so analytics can count it once. |
| session | `hash(sensor_id, analyzer, analyzer_uid)` | Analyzer UID is unique per sensor |
| alert | `hash(rule_id, rule_version, entity_key, window_start)` | A replay produces the same alert. Repeats within a suppression window increment `count`. |
| incident | Random UUID at creation | Grouping key stored |
| SIEM message | `event_id` = alert or incident ID + `update_seq` | SIEM-side deduplication on event_id (S-07 §4) |

The hash is SHA-256 truncated to 128 bits and hex-encoded. Final choice is in Phase 5, because collision risk at the expected volume must be documented.

Consumers are **idempotent**: replaying any queue offset range does not create duplicates. This is a design requirement, to be verified by test IT-03 in the testing strategy. It has not been tested yet.

## 7. Validation and malformed events

| Check | Action |
|---|---|
| Unparseable record | `quarantine` with `reason=parse_error`, original bytes kept |
| Missing required field | `quarantine`, `reason=missing:<field>` |
| Timestamp more than 24 h in the future or older than the queue retention | Accept with `quality.clock_suspect`. Future timestamps beyond the threshold go to quarantine. |
| Unknown flow template (NetFlow v9/IPFIX) | Collector buffers until the template arrives (bounded), then quarantines |
| Counter overflow or negative values | Quarantine |
| Exporter not in inventory | Accept with `source.id=unknown:<ip>` and raise a health warning (configurable to reject) |
| Quarantine rate above threshold | Health alarm. The rate per source is shown in the console. |

Quarantined events can be re-processed after a mapping fix. Each quarantine event has an audit trail.

## 8. Schema evolution

S-05 §13 rules apply.

- MINOR = additive only. MAJOR = breaking.
- During migration, producers dual-publish (`*.v1` and `*.v2` topics) and both versions are supported until every consumer has migrated.
- The schema registry is a **versioned directory of JSON Schema files in the repository**. Each record carries `schema_version`. Validation happens in CMP-NRM. A separate registry service is not proposed for R1 (P10).
- The store schema follows MAJOR versions. Migrations are scripted, reversible where possible, and rehearsed in staging.
- A change log is kept with the schemas.

## 9. Data ownership

| Record | Writer (single owner) | Readers |
|---|---|---|
| flow, session, packet_ref | CMP-NRM / sensor PCAP writer (packet_ref) | DET, API, RPT |
| alert | CMP-DET (create). CMP-COR (status, grouping). API (analyst status changes). | API, INT |
| incident, evidence_ref | CMP-COR. API (analyst edits). | API, INT |
| asset | CMP-NRM (traffic discovery), CMP-INT (LDAP, vulnerability), API (manual) — field-level ownership by `discovery_source` | All |
| baseline_profile, models | CMP-DET baseline jobs | DET, API |
| indicator | CMP-TIF | NRM, DET, API |
| health | All components | OBS, API |
| audit | API, CMP-TIF, CMP-RSP, CMP-CFG | Auditor role only |

## 10. External contracts

### 10.1 Backend API (CMP-API)

| Convention | Rule |
|---|---|
| Style | REST/JSON over HTTPS. Versioned path `/api/v1/…`. OpenAPI 3 specification kept in the repository (Phase 8). |
| Auth | Session after an LDAPS bind or local break-glass login. Service tokens for internal automation, scoped and expiring. |
| Authorization | RBAC per endpoint and per data class. RESTRICTED payload endpoints need a separate permission. |
| Pagination | Cursor-based for searches. Large result sets go through the async export job API (TR-36), not one HTTP response. |
| Query guards | Max time range, max concurrent heavy queries per user and globally, server-side timeouts (ADR-013 benchmark sets the values) |
| Errors | RFC 9457 problem+json with a stable error code |
| Audit | Every RESTRICTED access and every state change writes `audit` |

Key resources (initial): `/alerts`, `/incidents`, `/search/flows`, `/search/sessions`, `/exports`, `/packets/{packet_ref_id}` (download, audited), `/assets`, `/rules`, `/rules/{id}/test`, `/zones`, `/subnets`, `/suppressions`, `/baselines`, `/integrations/health`, `/health`, `/audit` (auditor), `/content/imports`.

### 10.2 SIEM outbound (CMP-INT)

- Payload is the common alert message (S-07 §10): all §5.4 fields needed by the SIEM, plus `console_url` back-link, `event_id`, `incident_id`, `update_seq`.
- Transport and format are configurable: syslog over TLS with **CEF** or **JSON** (RFC 5424), or REST. The mapping table (NBAD severity → SIEM severity) is kept in configuration.
- Delivery is at-least-once, with ordering preserved per incident.
- The SIEM-side parser and the product are unknown (Q-10). The format is fixed only after the SIEM is identified, and **no compatibility is claimed until test IT-10 passes**.

### 10.3 Inbound context contracts

| Source | Contract (proposed) | Verification status |
|---|---|---|
| NetFlow v5/v9, IPFIX, sFlow v5 | Standard protocol fields. Vendor-specific IEs mapped per exporter in a compatibility matrix. | Unverified. Needs per-model samples (Q-09). |
| Firewall NAT / proxy / VPN / IPS syslog | Per-product parser profiles | Unverified (Q-23) |
| LDAP/AD | LDAPS search with a read-only bind. Attributes for users, groups and computers. | Unverified (Q-20) |
| Vulnerability scanner | API pull or CSV/XML/JSON file import, mapped to `asset.vuln_summary` | Unverified (Q-21) |
| Sandbox | Submit file plus hash, then poll or callback for the verdict | Unverified (Q-22) |
| Threat intel | STIX 2.1 bundle or CSV (`type,value,source,confidence,valid_until`), signed batch | Format proposed (S-07 §8) |
| GeoIP | Offline DB file, versioned. Licence of the chosen DB to be checked (Q-31). | Unverified |

## 11. Retention enforcement

- Per-class policy in configuration (`min_days`, `max_days`, `legal_hold_exempt=false`).
- Raw PCAP: deletion by time partition once age > `min_days` **and** disk pressure or `max_days` is reached. Partitions with legal hold are skipped.
- Analytics store: time-partitioned tables dropped per partition (no row deletes).
- Every deletion writes a summary audit record: class, partition, record or file count, bytes.
- Alarm when the oldest data is younger than policy (premature deletion) or older than `max_days` (S-09 §5).
- Whether replicas and backups count toward retention: Q-19.

## 12. Differences from S-05

| Topic | S-05 | Here | Reason |
|---|---|---|---|
| Envelope | Provenance fields listed loosely | Formal envelope (§4) with `event_id`, `normalize_time`, `quality`, `sensitivity` | Prompt §10, DR-06, DR-10 |
| Severity levels | High/Medium/Low (+ S-06 adds Informational and Critical) | 5 levels, mapped to the tender's "etc." | TR-15 |
| Health and audit schemas | Listed only | Defined (§5.10, §5.11) with a hash chain | security-and-airgap §10 |
| Dedup across observation points | Not covered | `dedup_group` via Community ID | Duplicate observation risk (system-architecture §5.4) |
| Long-flow stitching | Not covered | `segment` group | TR-12 with exporter timers |
