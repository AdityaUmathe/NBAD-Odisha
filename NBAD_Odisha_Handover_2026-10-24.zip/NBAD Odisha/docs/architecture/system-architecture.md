# NBAD System Architecture

**Status:** PROPOSED — draft v0.1 (2026-10-24). Nothing in this document has been built, deployed or benchmarked.
**Inputs:** S-01 to S-10 (see [requirements baseline](../requirements/requirements-baseline.md)). This document refines S-03 (System Architecture Specification v0.1) and supersedes it where they differ. Every difference is listed in §13.

## 1. Context

NBAD is a **passive** network behaviour anomaly detection platform for the OPTCL NG-SOC & NOC. It observes network traffic (mirrored packets and exported flows), detects anomalous and policy-violating behaviour, keeps evidence (flows, sessions, raw packets), and presents everything in a single analyst console (TR-02, TR-39). Alerts and incidents are forwarded to the organisation's SIEM (SOW-05).

**NBAD is not a SIEM and not a UEBA.** It does not collect general-purpose logs for correlation across the enterprise, and it does not analyse endpoint processes or user behaviour. It consumes a limited set of external context sources (identity, vulnerability, appliance, proxy and VPN logs) only to enrich network observations.

```mermaid
flowchart LR
    subgraph OPTCL["OPTCL premises (air-gapped boundary — C-04)"]
        NET["Network devices<br/>routers · switches · firewalls · VPN"]
        TAP["TAP / SPAN / packet broker"]
        NBAD["NBAD platform"]
        SIEM["SIEM (product TBD, Q-10)"]
        AD["AD / LDAP"]
        VM["Vulnerability scanner (Q-21)"]
        SBX["Sandbox (Q-22)"]
        PRX["Internet proxy / IPS / VPN logs"]
        SOC["SOC analysts"]
        XFER["Transfer station<br/>(approved import route, Q-12)"]
    end
    NET -- "NetFlow / IPFIX / sFlow" --> NBAD
    TAP -- "mirrored packets (receive-only)" --> NBAD
    PRX -- "syslog" --> NBAD
    AD -- "LDAPS (read-only)" --> NBAD
    VM -- "scan results (API or file)" --> NBAD
    NBAD -- "alerts / incidents (syslog-TLS or REST)" --> SIEM
    NBAD <-- "file submit / verdict" --> SBX
    SOC -- "HTTPS console" --> NBAD
    XFER -- "signed packages, TI feeds, GeoIP (one-way in)" --> NBAD
```

Nothing goes from NBAD to any network outside the premises (DR-01, DR-02).

## 2. Architecture principles (binding for every design choice)

| # | Principle | Requirement link |
|---|---|---|
| P1 | **Passive first.** Nothing inline. Capture NICs have no IP and never transmit. Any action that changes a network goes through the response-action path (ADR-012). | TR-17, DR-08 |
| P2 | **Durable, replayable ingestion.** A replicated queue sits between collection and processing. Sensors and collectors spool locally when the queue is unreachable. | DR-04, TR-38 |
| P3 | **Separate data classes.** Raw PCAP, normalized flows/sessions, alerts/incidents/state, baselines/models and audit each have their own store and retention. | TR-41, TR-36 |
| P4 | **Explainable detections.** Every alert stores its evidence references, rule/model version, observed vs expected values and contributing features. | DR-06, TR-11 |
| P5 | **Control plane separate from data plane.** If the console, API or PostgreSQL fails, capture and spooling continue. | OBL-04 |
| P6 | **Data stays on premises.** There are no outbound paths by default, and every proposed outbound path is listed in security-and-airgap §9. | TR-35, OBL-05 |
| P7 | **Size from measurements.** No production size is fixed until traffic is measured and benchmarks pass. | OBL-04, TR-42 |
| P8 | **Design for failure.** Every component has documented failure behaviour (§9). | OBL-03, OBL-04 |
| P9 | **Secure by design.** mTLS, RBAC enforced in the API, least privilege, local secrets, append-only audit. | OBL-05 |
| P10 | **Operational simplicity.** Use the smallest number of stateful products that meets the gates. No Kubernetes, no microservice sprawl. | DR-05 |
| P11 | **Incremental delivery.** Start with flow and packet ingestion and rules with evidence. Advanced analytics come only after the pipeline is reliable. | OBL-06 |

## 3. Logical architecture — four planes

```mermaid
flowchart TB
    subgraph DP["DATA PLANE"]
        SEN["CMP-SEN Packet sensor<br/>capture · protocol metadata · PCAP writer"]
        FLC["CMP-FLC Flow collector<br/>NetFlow v5/v9 · IPFIX · sFlow"]
        LOGC["CMP-LGC Context log receiver<br/>firewall NAT · proxy · VPN · IPS syslog"]
        ING["CMP-ING Durable ingest queue"]
        NRM["CMP-NRM Normalize · validate · dedupe · enrich"]
        DET["CMP-DET Detection workers<br/>rules · thresholds · baselines · graph · TI · ML scorer"]
        COR["CMP-COR Correlation & incident service"]
    end
    subgraph SP["STORAGE PLANE"]
        FST[("CMP-FST Flow/session analytics store")]
        PCA[("CMP-PCA Raw packet archive")]
        PGS[("CMP-PGS Transactional store<br/>alerts · incidents · assets · rules · config · audit")]
        BMS[("CMP-BMS Baseline & model store")]
    end
    subgraph AP["APPLICATION PLANE"]
        API["CMP-API Backend API (RBAC enforced)"]
        UI["CMP-UI Analyst console"]
        INT["CMP-INT Integration connectors"]
        RSP["CMP-RSP Response-action service<br/>(suggest / prepare only in R1)"]
        REP["CMP-RPT Reports & export"]
    end
    subgraph MP["MANAGEMENT PLANE"]
        OBS["CMP-OBS Metrics · logs · alerting"]
        AUD["CMP-AUD Audit pipeline"]
        BKP["CMP-BKP Backup & restore"]
        PKG["CMP-REPO Offline package & artifact repository"]
        TIM["CMP-TIM Time service"]
        PKI["CMP-PKI Secrets & certificates"]
        CFG["CMP-CFG Config management"]
        CNT["CMP-TIF Content import<br/>TI · GeoIP · rules · signatures"]
    end
    SEN --> ING
    FLC --> ING
    LOGC --> ING
    SEN --> PCA
    ING --> NRM --> ING
    ING --> FST
    ING --> DET
    DET <--> BMS
    DET --> COR --> PGS
    FST --> DET
    API --> FST
    API --> PCA
    API --> PGS
    UI --> API
    COR --> INT
    INT --> PGS
    RSP --> PGS
    API --> RSP
    REP --> API
    CNT --> NRM
    CNT --> DET
```

### 3.1 Component responsibilities

| ID | Component | Responsibilities | Not responsible for | Key requirements |
|---|---|---|---|---|
| CMP-SEN | Packet sensor | Receive mirrored traffic (receive-only NIC). Capture with loss counters. Produce protocol/session metadata (connections, DNS, HTTP, TLS, files, dynamic protocol detection). Write rotating PCAP files with per-session index entries. Spool locally if downstream is unavailable. Report health. | Detection logic beyond what the analyzer itself does. Any traffic transmission. | TR-26, TR-38, TR-13, TR-27, TR-33, TR-40a, TR-42 |
| CMP-FLC | Flow collector | Receive NetFlow v5/v9, IPFIX and sFlow. Handle templates and sampling rates. Report per-exporter sequence gaps and silence. Publish raw flow records to the queue. | Normalization (done in CMP-NRM) | TR-22, TR-26, SOW-03 |
| CMP-LGC | Context log receiver | Receive syslog (TLS where supported) from firewalls (including NAT), proxy, VPN and IPS. Publish to the queue. | General-purpose SIEM log management | TR-25, TR-09 (NAT), TR-33 (proxy) |
| CMP-ING | Ingest queue | Durable, replicated, partitioned buffer. Replay. Backpressure. Topic per source class and stage. | Long-term storage | DR-04, P2 |
| CMP-NRM | Normalization & enrichment | Map to the canonical schema ([data-flow-and-contracts](data-flow-and-contracts.md)). Validate. Quarantine malformed events. Assign stable IDs. Deduplicate. Enrich zone, subnet, asset, GeoIP country, TI match and vulnerability summary from local caches. | Blocking on slow enrichment (enrichment runs from caches, never from synchronous external calls) | TR-06, TR-21, TR-40b, DR-09 |
| CMP-DET | Detection workers | Streaming rules and thresholds. Baseline deviation. Longitudinal detectors (beaconing, low-and-slow). Communication-graph detectors (fan-out, new edges). TI matching. ML scoring (Phase 10). Emit alerts with evidence. | Incident lifecycle | TR-03 to TR-05, TR-08, TR-12 to TR-15, TR-18 to TR-20, TR-24, TR-31, TR-32 |
| CMP-COR | Correlation & incident service | Deduplicate alerts. Group by entity and behaviour chain. Own the incident lifecycle and timeline. Compute severity and confidence. | Alert generation | TR-15, POC "Correlation & Incident Detection" |
| CMP-FST | Flow/session analytics store | Store and query normalized flows, sessions, packet_refs and health samples for 15 days or more. Aggregations for profiles and dashboards. Forensic queries and exports. | Transactional state | TR-06, TR-28 to TR-31, TR-36, TR-41 |
| CMP-PCA | Raw packet archive | Time- and sensor-partitioned PCAP files. Integrity hashes. Retention enforcement for 7 days or more. Retrieval by packet_ref. | Indexing payload content | TR-39, TR-40a, TR-41 |
| CMP-PGS | Transactional store | Alerts, incidents, assets, rules (versioned), policies, zones/subnets, users/roles, integration config, suppressions, audit (append-only tables) | Bulk flow storage | TR-15, TR-19, TR-32 |
| CMP-BMS | Baseline & model store | Hour-of-week baseline statistics per entity and metric. Model artifacts and versions. Snapshots for rollback. | | TR-31, TR-24, TR-37 |
| CMP-API | Backend API | REST/JSON, versioned (`/api/v1`). AuthN via LDAPS or local break-glass. RBAC on every endpoint. Query guards (limits, timeouts, concurrency). Packet retrieval and export with audit. | UI rendering | TR-02, TR-36, TR-39 |
| CMP-UI | Analyst console | Dashboards, alert queue, incidents, search, entity pages, timelines, PCAP download/playback, rule management, reports, integration and platform health. All assets served locally. | | TR-02, TR-29, TR-30, TR-39 |
| CMP-INT | Integration connectors | SIEM output (at-least-once, idempotent). Inbound context pulls (LDAP, vulnerability scanner). Sandbox submission. Per-connector health. | State-changing actions (CMP-RSP) | TR-25, TR-32, TR-40b, SOW-05 |
| CMP-RSP | Response-action service | R1: generate mitigation suggestions and prepared (unsent) change proposals. Execution only in a later, separately approved release. | Automatic action (out of scope, ADR-012) | TR-10 |
| CMP-RPT | Reports & export | Scheduled and ad-hoc reports. Controlled exports with hash and audit. | | TR-11, TR-29 |
| CMP-OBS | Observability | Metrics, local log aggregation, alert routing on a path separate from security alerts, heartbeat | Security detection | OBL-03 |
| CMP-AUD | Audit pipeline | Append-only audit of logins, configuration, rule, packet access and exports, protected from administrators | | security-and-airgap §10 |
| CMP-BKP | Backup | Configuration DB, rules, models, incidents, audit, keys (encrypted), to a separate failure domain | Full PCAP backup (replication policy instead) | OBL-03 |
| CMP-REPO | Offline repository | Signed OS packages, container images or binaries, rule/content bundles | | DR-01, OBL-01 |
| CMP-TIM | Time | Local redundant NTP (chrony). PTP where the sensors' precision needs justify it. Offset monitoring. | | DR-09 |
| CMP-PKI | Secrets & certificates | Internal CA (OPTCL's if one exists). Service certificates, rotation, secret storage. | | P9 |
| CMP-CFG | Configuration management | Declarative host and service configuration (Ansible proposed), versioned, applied from the management zone | | P10 |
| CMP-TIF | Content import | Validate signature, stage, activate and roll back TI feeds, GeoIP DBs, Suricata rules, app signatures | | TR-34, C-05 |

### 3.2 Interfaces between planes and trust boundaries

| From → To | Interface (proposed) | Trust boundary | Control |
|---|---|---|---|
| Network → CMP-SEN | Mirrored frames on a receive-only NIC | Capture zone → platform | NIC without IP. Host firewall. No route out. |
| Exporters → CMP-FLC | UDP NetFlow/IPFIX/sFlow (2055/4739/6343, to be confirmed) | Network devices → integration zone | Allow-list of exporter IPs. Rate limit. UDP has no authentication, so source validation plus sequence checks are used. |
| Log sources → CMP-LGC | Syslog over TLS (6514), UDP/TCP syslog only where the device cannot do TLS | Integration zone | Per-source allow-list. Flag on records saying whether they arrived over TLS. |
| CMP-SEN/FLC/LGC → CMP-ING | Queue client protocol over mTLS | Data plane internal | Per-producer identity and topic ACLs |
| CMP-ING → workers → stores | Queue consumer groups. Store-native bulk insert over TLS. | Data plane internal | Service identities, least-privilege DB roles |
| CMP-UI → CMP-API | HTTPS through a reverse proxy | Analyst zone → application plane | Session auth, CSRF protection, RBAC in the API |
| CMP-API → stores | Store-native protocols over TLS | Application → storage | Read-mostly roles. Query guards. |
| CMP-INT → SIEM / sandbox | Syslog-TLS or REST (SIEM). Vendor API (sandbox). | Platform → integration zone | Per-destination allow-list. Credentials in the secret store. |
| Management → all hosts | SSH from the jump host only. Config management. Metrics scrape. | Management zone | MFA where supported. Command logging. |
| Transfer → CMP-REPO / CMP-TIF | File drop on the staging host | Transfer zone → management | Signature and hash verification before promotion (security-and-airgap §6–7) |

**Rule:** a failure or overload in the application or management plane must not stop the data plane from capturing, spooling or queueing (P5). The data plane needs nothing from the control plane at runtime except configuration it has already loaded and cached.

## 4. Data flow summary

The detailed version is in [data-flow-and-contracts.md](data-flow-and-contracts.md).

```mermaid
sequenceDiagram
    autonumber
    participant S as Sensor / Collector
    participant Q as Ingest queue
    participant N as Normalize/Enrich
    participant F as Flow/session store
    participant D as Detection
    participant C as Correlation
    participant P as PostgreSQL
    participant I as SIEM connector
    S->>Q: raw.flow / raw.session / raw.log (source-native, with provenance)
    Q->>N: consume (consumer group)
    N->>Q: norm.flow / norm.session (canonical v1, stable IDs)
    N-->>Q: quarantine.* (malformed, with reason)
    Q->>F: bulk insert norm.*
    Q->>D: stream norm.*
    D->>F: windowed queries (baselines, longitudinal)
    D->>Q: alert.v1 (evidence refs, rule/model version)
    Q->>C: consume alerts
    C->>P: upsert alert / incident, timeline
    C->>Q: out.siem (incident and alert events)
    Q->>I: consume, deliver at-least-once, idempotent by event_id
```

## 5. Network observation and collection

All observation points are **starting assumptions** from S-03 §4.1. None has been confirmed (Q-06).

### 5.1 Observation methods compared

| Method | Strengths | Limitations | Use in NBAD |
|---|---|---|---|
| **Passive TAP** (optical/copper) | Lossless copy. No load on switches. Sees errors and full duplex. Fails open on most models. | Needs installation in the link (one-time outage, change control). Two directions arrive on two ports unless aggregated. Speed and medium must match. | Preferred for the DC Internet edge (TR-42) |
| **SPAN / mirror port** | No hardware. Quick to configure. | Can drop under oversubscription (both directions onto one port). Lower priority on the switch. May alter timing. Duplicates when several VLANs are mirrored. | Fallback. Core and DMZ where a TAP is not feasible. Loss must be monitored. |
| **RSPAN / ERSPAN** | Remote mirroring. Reaches virtual or remote segments. | Adds encapsulation and bandwidth on the network. Loss is possible. | Virtual environments (TR-16), remote segments |
| **Packet broker** | Aggregates and deduplicates TAP feeds, load-balances sensors, can filter | Cost. Its own HA. | Only if OPTCL already owns one (Q-06) or the number of observation points justifies one |
| **Exported flows** (NetFlow v9/IPFIX/sFlow) | Wide coverage at low cost. Already present on most routers and firewalls. Good for SLDC WAN. | No payload. Sampling reduces fidelity (cannot prove absence). Active/inactive timers delay long flows. Template and vendor variation. | Default for core, Main LDC and SLDC (SOW-03, TR-26) |

### 5.2 Capture depth compared

| Depth | Supports | Cost | Recommended where |
|---|---|---|---|
| Full PCAP | TR-39, TR-40a playback, payload investigation, sandbox file extraction | Highest storage (≈ 5.5 TB/day at 512 Mbps sustained) | DC Internet edge (inside NAT) |
| Selective or filtered PCAP | Forensics for chosen segments or hosts | Moderate | Approval-gated option (C-12). DMZ, if needed. |
| Protocol metadata (sessions) | TR-13, TR-27, TR-33, DNS/TLS analytics | Low to moderate | Everywhere a sensor exists |
| Flow only | Volumetric, scan, graph, policy, long-lived connections | Lowest | Core, Main LDC, SLDC, virtual |

### 5.3 Proposed collection approach per observation point

| Observation point | Zone (A-03) | Proposed method | Packet capture | Confidence | Needs |
|---|---|---|---|---|---|
| DC Internet edge, **inside NAT** | Z1 | TAP (SPAN fallback) to 2 sensors, plus flow export from the edge firewall/router, plus firewall NAT logs | Full PCAP (TR-41/TR-42) | Medium. The TR-42 target is explicit. | Q-04, Q-06, Q-13 |
| DMZ / published services | Z1 | SPAN/TAP to a sensor (could share with the edge if the topology allows), plus flow export | Metadata. PCAP optional (C-12). | Low | Q-06 |
| DC core / distribution (east-west) | Z2 | Flow export from the core, plus SPAN on selected uplinks to a sensor for metadata | Metadata only, until measured | Low | Q-06, Q-07 |
| Virtual environments | Z2 | Hypervisor flow export or vSwitch mirror/ERSPAN to a sensor VM | Metadata only | Low. Product unknown. | Q-05 |
| Main LDC | Z3 | Flow export. Sensor only if link rate and value justify it. | Not by default | Low | Q-06, Q-08 |
| SLDC sites | Z3 | Flow export from site routers to central collectors | No (A-07) | Low | Q-08 |

### 5.4 Collection quality factors (designed for, not assumed away)

| Factor | Effect | Handling |
|---|---|---|
| Packet loss (sensor or SPAN) | Missing evidence, missed detections | Per-interface drop counters exported as health records. `capture_loss_flag` on packet_refs. Loss shown on evidence views. An agreed loss limit (Q-15). |
| SPAN oversubscription | Silent loss | Compare SPAN volume with interface counters (SNMP) where available |
| Asymmetric routing | Half-sessions, broken protocol parsing | Place TAPs where both directions pass. Detect one-sided sessions and report the share per sensor. |
| Duplicate observations (multiple points, VLAN mirroring) | Inflated volumes and false positives | Deduplicate by 5-tuple, time bucket and sensor priority in CMP-NRM. `observation_point` field. |
| Clock skew | Wrong timelines and ordering | chrony on every sensor and collector. Offset alarm at 50 ms (S-09). Offset recorded in health records. |
| Flow sampling | Undercounting, small events missed | Record `sampling_rate`, scale counters, mark derived values as estimates. Never use sampled data for "absence" claims. |
| Flow timers (active timeout) | Long flows appear late or split | Stitch flow segments for long-lived detection (TR-12). Document the latency. |
| Encrypted traffic | No payload visibility | Metadata-only analytics (SNI, certificates, fingerprints, sizes, timing). Stated limitation (TR-11c). |
| Packet truncation | Payload loss | Off by default at TR-40a points |
| NAT | Internal host unknown on the outside | Capture inside NAT and/or ingest NAT logs (Q-13) |
| Collection failure | Gaps | Exporter-silence alarm (5 min), sensor heartbeat, detection confidence reduced for affected intervals |

## 6. Zone model

Every sensor, exporter, subnet, asset and record carries `zone`. TR-01 requires at least 3 zones. The working assumption is A-03 (Z1 Internet edge/DMZ, Z2 DC/servers, Z3 users/LDC/SLDC). The zone model is **data in PostgreSQL** (zones → subnets/CIDRs → sites), editable by the network administrator role. It is not hard-coded, so the confirmed OPTCL definition (Q-03) needs no code change. Thresholds, baselines, policies and dashboards can each be scoped per zone and per CIDR group (TR-21, SOW-04).

## 7. Deployment topology

### 7.1 Production target (PROPOSED — node counts are illustrative, pending benchmark)

```mermaid
flowchart TB
    subgraph CAP["Capture zone"]
        T1["TAP / SPAN feeds"]
    end
    subgraph SENS["Sensor tier (per observation point)"]
        S1["Sensor A"]
        S2["Sensor B (standby / overlap)"]
    end
    subgraph COLL["Collector tier"]
        F1["Flow + syslog collector 1"]
        F2["Flow + syslog collector 2"]
    end
    subgraph CORE["Platform core zone"]
        K1["Queue node 1<br/>+ coordination"]
        K2["Queue node 2<br/>+ coordination"]
        K3["Queue node 3<br/>+ coordination"]
        D1[("Analytics store replica 1")]
        D2[("Analytics store replica 2")]
        A1[("Packet archive node 1")]
        A2[("Packet archive node 2")]
        P1[("PostgreSQL primary")]
        P2[("PostgreSQL standby")]
        W1["App/worker node 1<br/>API · console · workers · connectors"]
        W2["App/worker node 2"]
    end
    subgraph MGMT["Management zone"]
        M1["Mgmt node: monitoring · repo · config mgmt · backup"]
        J["Jump host"]
        BK[("Backup target — separate failure domain")]
    end
    T1 --> S1 & S2
    S1 & S2 --> K1 & K2 & K3
    F1 & F2 --> K1 & K2 & K3
    S1 & S2 --> A1 & A2
    K1 & K2 & K3 --> W1 & W2
    W1 & W2 --> D1 & D2
    W1 & W2 --> P1
    P1 -. replication .-> P2
    D1 -. replication .-> D2
    A1 -. replication .-> A2
    M1 --> BK
```

- **Illustrative count:** about 12 to 14 nodes for the DC deployment, plus one sensor per additional packet observation point. This is an **estimate**. The real numbers come from benchmarks B-01 to B-06 ([capacity-and-resilience](capacity-and-resilience.md)).
- **Coordination:** the queue's controller quorum and the analytics store's coordination service (if the chosen store needs one) run together on the three queue nodes, so there is no extra cluster.
- **Management node:** losing it does not stop collection, detection or the console. Monitoring and backup are degraded until it is restored. Running a single management node is a **proposed accepted exception** to "no single point of failure" and needs approval (AD-07 in [architecture-decisions](architecture-decisions.md)). The alternative is a second management node.
- **Failure-domain separation:** each replica pair goes on separate power feeds, top-of-rack switches and hypervisor hosts. This depends on facilities (Q-18).

### 7.2 Development / prototype topology on the authorised remote server (Phase 3 onward)

- Single host, **all-in-one**, replication factor 1. Functional development only.
- No capture from production interfaces unless separately authorised. Test traffic is replayed (PCAP replay into a virtual interface) inside the server.
- **What this topology cannot validate:** 512 Mbps capture on real NICs, HA/no single point of failure, 30% spare capacity at production scale, or failure-domain separation. These need representative hardware (Q-29) and are gated in Phases 11 and 12.

## 8. Processing latency budget (PROPOSED engineering targets, not tender figures)

The figures come from S-03 §6. AM-06: the tender does not quantify "real time".

| Stage | Target (p95 under normal load) |
|---|---|
| Capture/export → queue | ≤ 5 s (flow export adds the exporter's active timeout) |
| Normalize and enrich | ≤ 10 s |
| Streaming rule or threshold alert | ≤ 60 s after the event is observable |
| Baseline deviation | Within one evaluation window (hourly profile: ≤ 1 h) |
| Longitudinal (beaconing, low-and-slow) | Batch, every 15 min to 24 h by design |
| Incident → SIEM delivery | ≤ 10 s, while the SIEM is reachable |

## 9. Redundancy and failure behaviour

| Failure | Expected behaviour (design intent) | Component that addresses it | Verified? |
|---|---|---|---|
| One sensor down | The overlapping or standby sensor keeps covering critical links. Health alarm raised. The gap is recorded where there is no overlap. | Second sensor on the same TAP feed or packet broker | No (Phase 11) |
| Queue unreachable from a sensor | The sensor spools to local disk (bounded). Drops counted once the spool is full. Replays on reconnect. | Local spool | No |
| One queue node down | No data loss with replication factor 3 and min in-sync 2. Producers and consumers continue. | 3-node queue | No |
| Analytics store replica down | Queries served by the other replica. Writes continue. The replica resyncs on return. | 2 replicas + coordination quorum | No |
| Detection worker down | Consumer-group rebalance. Reprocessing is idempotent. Stateful detectors restore from their checkpoint. | ≥ 2 worker instances | No |
| PostgreSQL primary down | Standby promoted (automatic or documented manual, ADR-009). Alerts buffer in the queue until promotion. Capture is unaffected. | Primary + standby | No |
| API/console node down | Load balancer or VIP moves sessions to the other node | 2 app nodes | No |
| SIEM unreachable | Outbound events held in the queue up to retention. Backlog alarm. Ordered delivery after recovery. | Queue retention + connector retries | No |
| Packet archive node or disk down | Replica (or RAID) serves retrieval. Re-replication. | Archive replication | No |
| Disk filling | Watermarks warn at 70% and are critical at 85% (S-09). Retention runs before the critical level. Data younger than the policy minimum is never deleted without approval (runbook §9.4 in S-09). | Retention job + alarms | No |
| Time source lost | Redundant NTP sources. The offset alarm marks affected evidence intervals. | 2+ local NTP | No |
| Site loss | Undefined until RTO/RPO are agreed (Q-14) | — | — |

## 10. Scaling model

Sensors scale per link, sized by packets per second. The queue scales by partitions. Workers scale horizontally. The analytics store scales by time partitions and adds shards when one shard's capacity is exceeded. The packet archive scales by adding nodes. At peak, no tier may exceed 70% of its tested ceiling (DR-03).

## 11. Analyst experience (single console, TR-02, TR-39)

| Area | Content | Requirements |
|---|---|---|
| Overview dashboard | Per-zone traffic, bandwidth by application, packet rate, top talkers, alerts by severity, collection health | TR-02, TR-29, TR-30 |
| Alerts & incidents | Queue, triage, assignment, lifecycle, merge and split, timeline, notes | TR-15, POC |
| Investigation | Search flows and sessions. Pivot by IP, CIDR, port, app, country. Entity page (host profile vs baseline, peers, new edges). Evidence panel with PCAP retrieval and playback/download (audited). | TR-06, TR-21, TR-28, TR-31, TR-39, TR-40 |
| Assets | Inventory, new hosts, vulnerable new hosts, services seen | TR-14, TR-32 |
| Detection management | Rules (create, test on history, version, enable), thresholds per zone/CIDR, suppressions, baselines, model status | TR-18, TR-19, TR-21 |
| Reports | Scheduled and ad-hoc reports, export with hash | TR-11 |
| Integration health | Per-connector last success, lag, errors | S-07 §3 |
| Platform health & capacity | Sensors, drops, queue lag, storage watermarks, retention age (embedded or linked operations views) | OBL-03, OBL-04 |
| Audit | Read-only audit viewer for the auditor role | security-and-airgap §10 |

## 12. Visibility limitations (stated openly — TR-11c)

NBAD sees network traffic only, at the observation points that exist. It cannot see:

- payload of encrypted traffic;
- traffic that never crosses a monitored point;
- inner traffic of tunnels and VPNs captured after encapsulation;
- internal hosts behind NAT without inside capture or NAT logs;
- small events in sampled flows;
- anything during collection loss;
- endpoint processes and files.

Malware, botnet, APT and Trojan detection (TR-03, TR-04) is therefore **indirect**: it relies on behaviour, threat-intelligence matches and sandbox verdicts (S-06 §3). No detection is claimed until it passes a test (testing strategy).

## 13. Differences from S-03 (System Architecture Specification v0.1)

| Topic | S-03 | This document | Reason |
|---|---|---|---|
| Spare capacity | "no tier above 70%" (S-03), but other sources apply a ×1.3 margin | ≤ 70% everywhere (÷ 0.7) | C-03 |
| Response actions | Not covered | Suggest/prepare only in R1 | C-06, ADR-012 |
| Context log receiver | Not listed | CMP-LGC added for NAT, proxy, VPN and IPS logs | TR-09, TR-25, TR-33 |
| Single management node | Not covered | Proposed accepted exception, needs approval | OBL-04 |
| Prototype vs production | Not covered | Separate topologies. Limits of the prototype stated. | Remote-only development constraint |
