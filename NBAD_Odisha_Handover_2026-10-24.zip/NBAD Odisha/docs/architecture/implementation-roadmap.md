# NBAD Implementation Roadmap

**Status:** PROPOSED — draft v0.1 (2026-10-24). Status per phase is tracked in [../implementation/master-checklist.md](../implementation/master-checklist.md).

**Binding constraint (ADR-023):** from Phase 2 onward, all work that installs, builds, runs, tests or deploys happens **only on the server the project lead authorises**. Nothing is developed, installed or run on the local machine. Every phase stops at its gate and waits for the project lead's instruction.

## 1. Effort assumptions

Effort figures are **indicative working-day ranges, not commitments**. They assume:

- the AI-assisted engineer does most implementation, with the project lead (plus 1–2 engineers) reviewing, testing and arranging access;
- remote access with sufficient resources, and an offline dependency route if needed;
- timely answers to the P1 questions;
- the availability of traffic samples (Q-33) and integration test endpoints.

Waiting time for OPTCL decisions, procurement and access is **not included**. It can add 1–3 months (R-20). The S-02 blueprint gives 22 weeks for a narrower scope. Both are re-estimated after Phase 2.

| Phase | Name | Indicative effort (working days) |
|---|---|---|
| 0 | Repository and requirements | 1–2 (this session) |
| 1 | Architecture and technology decisions | 2–4 (this session), plus review by the lead/OPTCL (5–10 calendar days) |
| 2 | Remote server assessment | 2–3 |
| 3 | Development foundation | 5–8 |
| 4 | Collection and ingestion | 10–15 |
| 5 | Normalization and enrichment | 8–12 |
| 6 | Initial detection capabilities | 15–25 |
| 7 | Storage and investigation (incl. store PoT) | 15–20 |
| 8 | Backend and analyst interface | 20–30 |
| 9 | Integrations | 15–30 |
| 10 | Advanced analytics (baselines, ML) | 15–25 |
| 11 | Security and resilience | 10–15 |
| 12 | Performance and acceptance | 15–20 |
| 13 | Deployment and handover | 10–15 |
| | **Total (Phases 2–13)** | **≈ 140–218** |

## 2. Dependency overview

```mermaid
flowchart LR
    P0["P0 Requirements"] --> P1["P1 Architecture"]
    P1 --> G1{{"Gate: lead approves<br/>AD-01..AD-14"}}
    G1 --> P2["P2 Server assessment"]
    CRED(["Credentials provided"]) --> P2
    P2 --> G2{{"Gate: server plan approved"}}
    G2 --> P3["P3 Foundation"]
    P3 --> P4["P4 Collection & ingest"]
    P4 --> P5["P5 Normalize & enrich"]
    P5 --> P6["P6 Initial detections"]
    P5 --> P7["P7 Storage & investigation"]
    P6 --> P8["P8 API & console"]
    P7 --> P8
    P8 --> P9["P9 Integrations"]
    P6 --> P10["P10 Advanced analytics"]
    P7 --> P10
    P9 --> P11["P11 Security & resilience"]
    P10 --> P11
    HW(["Representative hardware (Q-29)"]) --> P11
    P11 --> P12["P12 Performance & acceptance"]
    P12 --> G3{{"Gate: acceptance + OPTCL approval"}}
    G3 --> P13["P13 Deployment & handover"]
```

## 3. Phases

Each phase lists **Objective · Prerequisites · Work · Acceptance criteria · Risks · Environment**. When a phase is started, the engineer restates these items and asks for confirmation (master-checklist §1, gate rules).

### Phase 0 — Repository and requirements
- **Objective:** establish the documentation repository, the requirements baseline, conflicts and traceability.
- **Prerequisites:** source documents S-01 to S-11.
- **Work:** inspect the repository and documents. Write the requirements baseline, ambiguities and conflicts, and the traceability matrix.
- **Acceptance criteria:**
  - all 42 TR rows, SOW and OBL items recorded;
  - conflicts C-01 to C-13 and assumptions A-01 to A-12 documented;
  - every TR mapped in the traceability matrix.
- **Environment:** local documentation only.

### Phase 1 — Architecture and technology decisions
- **Objective:** a complete proposed architecture and a provisional technology recommendation with gates.
- **Work:** the docs/architecture set, ADRs, AD list, benchmark plan, remote server prerequisites.
- **Acceptance criteria:**
  - ≥ 2 options compared with a scorecard;
  - data contracts, security, capacity, integration and roadmap documented;
  - static documentation checks pass;
  - **the project lead reviews and records decisions on AD-01 to AD-14** (this approval is the gate, and it is pending).
- **Environment:** local documentation only.

### Phase 2 — Remote server assessment
- **Objective:** understand the authorised server before changing anything.
- **Prerequisites:** credentials from the project lead (Q-29) and an explicit instruction to start.
- **Work:**
  - read-only inspection per [remote-server-prerequisites-and-assessment](../operations/remote-server-prerequisites-and-assessment.md);
  - record OS, CPU, RAM, storage, NICs, existing services, security controls and connectivity;
  - compare with the requirements;
  - produce a server-specific plan.
- **Acceptance criteria:**
  - assessment report committed;
  - conflicts with the architecture listed;
  - plan approved by the project lead;
  - **no installation or modification performed.**
- **Risks:** R-15, R-16.

### Phase 3 — Development foundation
- **Objective:** a working, conventional engineering base on the remote server.
- **Prerequisites:** Phase 2 plan approved, including where dependencies come from.
- **Work:**
  - source repository with the agreed layout;
  - build tooling for the chosen language;
  - configuration loading (config separate from code, secrets via placeholders);
  - structured logging, error-handling conventions, health endpoint pattern;
  - test framework and conventions;
  - JSON Schemas v1.0 for the envelope and records (ADR-024);
  - dependency inventory started.
- **Acceptance criteria:**
  - a skeleton service builds and its unit tests pass **on the remote server**;
  - lint and static checks run;
  - no secrets in the repository (scan);
  - dependency inventory lists every added component with licence.
- **Environment:** remote server.

### Phase 4 — Collection and ingestion
- **Objective:** flows and packet metadata reach the durable queue with health metrics.
- **Prerequisites:** Phase 3. Test traffic (replayed PCAP and synthetic NetFlow/IPFIX). **No capture on production interfaces unless separately authorised.**
- **Work:**
  - flow collector (ADR-017);
  - sensor pipeline on replayed traffic (AF_PACKET + Zeek; Suricata if ADR-016 allows);
  - PCAP writer prototype;
  - queue (ADR-015) as a single node in dev;
  - local spool;
  - health records: drops, sequence gaps, clock offset.
- **Acceptance criteria:**
  - replayed datasets produce the expected record counts (±0 for deterministic replays);
  - spool and replay work after a simulated queue outage, with no duplicates after normalization (IT-03 precursor);
  - backpressure observed and documented;
  - functional parts of B-02/B-03 run on dev, with results recorded.
- **Risks:** R-03, R-16.

### Phase 5 — Normalization and enrichment
- **Objective:** canonical records with validation, deduplication and provenance.
- **Prerequisites:** Phase 4. Real exporter samples if available (Q-09). Otherwise the synthetic samples are labelled as such.
- **Work:**
  - mappers per source;
  - validation and quarantine;
  - deterministic IDs;
  - Community ID;
  - zone/subnet/asset/GeoIP/TI enrichment from local caches;
  - long-flow stitching.
- **Acceptance criteria:**
  - test suite covers malformed inputs, missing fields, timestamp edge cases (skew, future, DST/timezone in source), sampling scaling, duplicates across observation points, and idempotent replay;
  - quarantine reasons visible;
  - **schema freeze for v1.0 only after review against real samples.** If none exist, the freeze is provisional and recorded as such.

### Phase 6 — Initial detection capabilities
- **Objective:** explainable, tested detections for the R1 use-case set.
- **Prerequisites:** Phase 5. Test corpus (S-06 §11). Use-case priority agreed with the project lead (S-06 §12).
- **Proposed R1 set:**
  - vertical and horizontal scan;
  - volumetric DoS and SYN flood;
  - long-lived connection (TR-12);
  - non-standard port / protocol mismatch (TR-13, TR-27);
  - new host and new service (TR-32, TR-14);
  - policy violation (TR-08);
  - unknown-country communication (TR-40b);
  - TI match (TR-34);
  - risky application (TR-20).
- **Work:** rule engine with versioned rules; severity/confidence/risk scoring (S-06 §6); alert evidence; correlation into incidents; monitor-only mode.
- **Acceptance criteria:**
  - every R1 detection has a test case with expected alert, entity, window and evidence, and passes on the corpus;
  - false positives on the benign sample are measured and reported;
  - every alert carries the rule version, observed/expected values and evidence refs;
  - replay creates no duplicate alerts.

### Phase 7 — Storage and investigation
- **Objective:** an approved store for flows, sessions and PCAP, with retention and forensic query.
- **Prerequisites:** Phase 5. ADR-013/014 proof of technology run.
- **Work:**
  - **proof of technology:** the same dataset in ClickHouse and OpenSearch, run PD-01 at dev scale; custom PCAP index vs Arkime on B-06; record results and decide ADR-013/014 (G-T1 to G-T3, with the project lead's approval);
  - implement the chosen store schema, partitions and retention jobs;
  - packet retrieval by packet_ref;
  - export jobs.
- **Acceptance criteria:**
  - retention deletes by partition and respects legal hold;
  - packet retrieval returns integrity-verified segments;
  - query guards are enforced;
  - dev-scale PD-01 results are recorded **and labelled as non-representative**.

### Phase 8 — Backend and analyst interface
- **Objective:** the single console (TR-02, TR-39) and versioned API.
- **Work:**
  - OpenAPI v1;
  - authentication (LDAPS and break-glass) and RBAC in the API;
  - alerts, incidents, search, entity pages, timelines, PCAP retrieval and playback/download with audit;
  - dashboards (TR-29, TR-30, TR-31 views);
  - rule management with test-on-history;
  - reports;
  - integration and platform health views.
- **Acceptance criteria:**
  - API contract tests pass;
  - an RBAC test matrix for every role passes at the API level (ST-04);
  - every RESTRICTED access is audited;
  - the UI loads no external resources (checked in the browser network log);
  - usability walkthrough with the project lead.

### Phase 9 — Integrations
- **Objective:** approved integrations, built and tested one at a time.
- **Prerequisites:** product details and test endpoints (Q-10, Q-20 to Q-23).
- **Order (proposed):**
  1. SIEM (INT-01)
  2. AD/LDAP (INT-02)
  3. Firewall NAT logs (INT-04)
  4. Vulnerability import (INT-08)
  5. TI import (INT-09)
  6. Proxy (INT-07)
  7. IPS/VPN (INT-05/06)
  8. Sandbox (INT-10)
- **Acceptance criteria:** for each integration, IT-xx passes (authentication, mapping, duplicate delivery, outage and backlog, recovery order); the compatibility matrix is updated with tested versions only.

### Phase 10 — Advanced analytics
- **Objective:** baselines (TR-31), graph detections (TR-05, lateral movement), longitudinal detections (beaconing, low-and-slow, TR-11b), ML scoring (TR-24, TR-37).
- **Prerequisites:** Phases 6 and 7 stable. Enough history.
- **Acceptance criteria:**
  - cold-start, maintenance windows, freeze and rollback demonstrated;
  - injected deviations detected;
  - false-positive rate measured;
  - model artifacts versioned with a recorded promotion approval;
  - contributing features shown on ML alerts;
  - resource use within budget.

### Phase 11 — Security and resilience
- **Objective:** hardening, offline lifecycle, backup/restore, HA behaviour.
- **Prerequisites:** a **multi-node environment** (Q-29). HA cannot be proven on a single dev server.
- **Work and acceptance criteria:**
  - hardening review against the baseline;
  - ST-01 egress soak;
  - ST-05 audit tamper test;
  - ST-07 offline update rehearsal;
  - ST-08 feed tamper test;
  - backup restore (ST-06, B-12);
  - failure tests B-10/B-11 with measured recovery times;
  - support-bundle tool;
  - all results recorded.

### Phase 12 — Performance and acceptance
- **Objective:** execute B-01 to B-13 and the POC test plan T1 to T12 on **representative** hardware.
- **Prerequisites:** agreed definitions (Q-01, Q-02, Q-04), agreed pass thresholds (Q-15), representative environment.
- **Acceptance criteria:**
  - every test has recorded actual results, environment and dataset;
  - gaps are listed;
  - **no compliance claim beyond the recorded results.**

### Phase 13 — Deployment and handover
- **Objective:** production deployment after approvals, plus operational handover.
- **Prerequisites:** Phase 12 accepted. OPTCL change approval.
- **Work:**
  - production deployment via the offline supply chain;
  - runbooks (S-09 §9 expanded);
  - troubleshooting guides;
  - backup, upgrade and recovery procedures;
  - known limitations;
  - training.
- **Acceptance criteria:** handover checklist signed by the receiving operations role. Known limitations documented.

## 4. What "done" means for R1

See S-02 §19. Each item is evidenced by a test record, not by a demonstration alone.
