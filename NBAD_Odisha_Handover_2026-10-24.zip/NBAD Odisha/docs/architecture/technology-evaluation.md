# NBAD Technology Evaluation

**Status:** PROPOSED — provisional recommendation, **not approved**. No technology has been purchased, installed, deployed or benchmarked for this project.
**Inputs:** S-04 (Technology Stack and Tooling Guide v0.1), S-02 §10, and the requirements in [requirements-baseline](../requirements/requirements-baseline.md).
**Licence notes:** Licence information reflects the authors' understanding at the time of writing (2026-10). Licences change, so each one **must be re-verified** at selection time against the upstream licence file, and confirmed with OPTCL's open-source policy (Q-17). None of this is legal advice.

## 1. Selection criteria

1. Meets the measured performance with ≤ 70% peak utilisation (DR-03), in benchmarks B-01 to B-07 ([capacity-and-resilience §7](capacity-and-resilience.md)).
2. Installs, updates and licenses fully offline (DR-01).
3. Has a 5-year support route and licence clarity (OBL-01, OBL-02, DR-05).
4. Operational simplicity: the number of distinct stateful products the team must run for five years (P10).
5. Explainability and evidence quality (DR-06).
6. Integration suitability (TR-22, TR-25).
7. Security and hardening effort (P9).
8. No per-host or per-flow licensing in analytics paths (TR-37, ADR-010).

## 2. Evaluation by category

### 2.1 Packet capture

| Option | Fit for TR-42 (512 Mbps; ≈ 42k–107k pps typical, ≈ 762k pps worst case, S-08 §3) | Air-gap / licence | Operational burden | Provisional |
|---|---|---|---|---|
| libpcap / **AF_PACKET** (TPACKET_V3, fanout) | Commonly used at these rates on commodity NICs. **Requires benchmark B-01** on the target NIC, kernel and packet mix. | In-kernel / BSD. Offline-friendly. | Low | **Recommended starting point** |
| AF_XDP | More headroom. Needs a recent kernel and driver support. | In-kernel | Medium | Fallback if B-01 fails at 130% of peak |
| DPDK | Highest rates. Dedicated cores and NICs. | BSD | High | Not justified unless measured rates are far above TR-42 |
| Capture cards (Napatech, Endace, …) | Lossless at high rates | Commercial. 5-year driver lifecycle. | Medium | Only if B-01 shows the need |

### 2.2 Protocol analysis and metadata

| Option | Role | Strengths | Concerns | Licence (verify) | Provisional |
|---|---|---|---|---|---|
| **Zeek** | Session metadata (conn, DNS, HTTP, TLS, files, SSH, SMB, …), dynamic protocol detection, scripting | Best metadata quality. DPD supports TR-13/TR-27. Community ID support. | Per-core throughput needs tuning (cluster mode with AF_PACKET workers) | BSD-3-Clause | **Recommended** (primary metadata) |
| **Suricata** | Signature IDS, protocol parsing, file extraction, EVE JSON, optional conditional PCAP logging | Multi-threaded. Large rule ecosystem for TR-03/TR-04 indicators. App-layer detection on any port. | Duplicates some Zeek work (CPU). Rule sets must be imported offline, and ruleset licences checked. | GPL-2.0 (engine). Ruleset licences vary. | **Recommended, pending CPU benchmark** (ADR-016) |
| nDPI-based classification | Application identification | Broad app list (TR-20 risky apps) | Another component | LGPL-3.0 | Candidate if Zeek/Suricata app coverage is insufficient for TR-20/TR-27 |

### 2.3 Packet archive and evidence

| Option | Description | Strengths | Concerns | Provisional |
|---|---|---|---|---|
| **Arkime** | Full packet capture with session index in OpenSearch/Elasticsearch | Mature PCAP-to-session linkage. Fast per-session retrieval. Apache-2.0. | **Requires OpenSearch or Elasticsearch** for its session index, which brings that cluster into any option using it. Its UI is a second console (C-11), so the API would be used. Its capture component could overlap with the sensor's own capture. | Natural fit for Option A |
| **Custom PCAP writer + index** | The sensor writes rotating, time-partitioned PCAP files (for example 60 s per interface). The writer records per-session first and last packet offsets in `packet_ref` rows in the analytics store. | No extra stateful product. Index lives in the same store as flows/sessions. | We own the code for 5 years. Per-session offset indexing must be built and tested. Retrieval of long sessions spans many files. | Natural fit for Option C |
| Suricata conditional `pcap-log` | Suricata writes PCAP itself | Reuses the analyzer | Coupled to the Suricata lifecycle. Index quality is limited. | Candidate component of the custom path |
| Storage substrate | Local XFS on RAID per archive node (with node-to-node replication), Ceph, or on-prem S3-compatible object store | Local RAID + replication is simplest. Ceph/S3 add an operational burden. | Licence of any S3 product to be verified (some popular ones are AGPL) | **Local filesystem + application-level replication** proposed (ADR-014, pending) |

Retrieval cost to plan for (custom path): at 512 Mbps one 60 s file holds about 3.84 GB. Without per-session offsets, retrieving a 5-minute session means scanning about 19 GB. **Per-session offset indexing is therefore mandatory** if the custom path is chosen (benchmark B-06).

### 2.4 Flow collection

| Option | Licence (verify) | Notes | Provisional |
|---|---|---|---|
| **goflow2** | BSD-3-Clause | NetFlow v5/v9, IPFIX, sFlow. Kafka output. Lightweight. Vendor template coverage to be confirmed per exporter (Q-09). | **Recommended** |
| pmacct (nfacctd/sfacctd) | GPL-2.0 | Mature, rich aggregation | Alternative if goflow2 template coverage fails |
| softflowd | BSD | Generates flows from packets (it is not a collector) | Only where no exporter exists, for example a virtual segment |
| nProbe | Commercial | Per-instance licensing, which is a TR-37 risk (C-13) | Not recommended unless procurement approves |

### 2.5 Ingestion and buffering

| Option | Strengths | Concerns | Licence (verify) | Provisional |
|---|---|---|---|---|
| **Apache Kafka (KRaft mode)** | Replay, partitioning, consumer groups. Native ingestion in ClickHouse (Kafka table engine) and OpenSearch (via connectors). Wide support market. | JVM. Disk and memory planning. 3-node minimum for RF 3. | Apache-2.0 | **Recommended** (ADR-015) |
| Redpanda | Kafka-compatible single binary. Simpler operations. | Community edition under a source-available licence (BSL), with some features enterprise-only. 5-year position to be checked. | BSL 1.1 / proprietary | Alternative only if licence review passes |
| NATS JetStream | Small footprint | Smaller analytics-connector ecosystem. More custom code. | Apache-2.0 | Alternative if measured load is small |
| No broker (sensor spool + direct DB insert) | Fewest components | Weak replay and fan-out. Couples collection to storage availability (breaks P2). | — | Rejected for production, acceptable for early prototyping only |

### 2.6 Processing

| Option | Assessment | Provisional |
|---|---|---|
| **Go workers** (normalization, enrichment, streaming rules, correlation) | Single static binaries are easy to move offline. Good concurrency. Low memory. | **Recommended** (ADR-018, pending team skills Q-30) |
| Java workers / Kafka Streams | Strong streaming library. Heavier runtime. | Alternative if the team is Java-centred |
| Apache Flink | Powerful windowing. A heavy cluster to operate. | **Not justified** for R1. Revisit if stateful windowing outgrows the workers plus store aggregations. |
| **Python** (pandas, scikit-learn) | Offline baseline and model development. Batch ML scoring (Phase 10). | Recommended for analytics and ML only, packaged as an offline wheelhouse |

### 2.7 Storage and query

| Option | Best at | Concerns | Licence (verify) |
|---|---|---|---|
| **ClickHouse** | High-volume append, columnar compression, fast aggregation (profiles, bandwidth graphs, TR-29 to TR-31) and large result export (TR-36) | Updates and deletes are expensive (fine for append-only flows). Replication needs ClickHouse Keeper. Free-text search is weaker. Different query model. | Apache-2.0 |
| **OpenSearch** | Flexible search, free text, familiar to SOC teams, dashboards. Required by Arkime. | Storage amplification. JVM heap tuning. Large-result export speed (scroll/PIT) **requires benchmark B-05**. | Apache-2.0 |
| **PostgreSQL** | Transactional state: rules, incidents, assets, config, audit, users | Not for bulk flow volumes | PostgreSQL Licence |
| Redis | Cache | Adds a stateful component | Not proposed (no measured need) |

### 2.8 Detection and ML

The **foundation is deterministic rules, thresholds and robust statistical baselines.** ML adds a further scorer (ADR-004).

| Approach | Explainability | Operating cost | Data needed | Validation | Role |
|---|---|---|---|---|---|
| Rules/thresholds | High | Low | Flows/sessions | Lab test per rule | R1 core (scan, DoS, policy, ports, long-lived, new host) |
| Statistical baselines (hour-of-week, robust percentiles, EWMA) | High (observed vs expected) | Low–medium | ≥ 2–4 weeks of history (to be tuned) | Replay with injected deviations | R1/R2 (TR-31, TR-18) |
| Protocol-aware analytics (DPD mismatch, DNS entropy, TLS fingerprints) | High | Medium (sensor CPU) | Sessions | Lab test | R1/R2 (TR-13, TR-27, tunnelling) |
| Graph analytics (fan-out, new edges) | Medium–high | Medium (state) | Flows | Simulated propagation | R2 (TR-05, lateral movement) |
| Threat-intel matching | High | Low | Indicators + flows/DNS/TLS | Feed test | R1 (TR-34) |
| Unsupervised ML (isolation forest, peer clustering) | Medium (with contributing features) | Medium | Stable baseline period | Held-out replay. False-positive rate measured. | Phase 10 (TR-24, TR-37) |

Self-built or open-source ML (scikit-learn, BSD-3) carries no per-host licence. That is a technical observation. The commercial answer to TR-37 still needs the written position of the commercial owner (Q-11).

### 2.9 Backend, UI, operations

| Area | Provisional | Alternatives | Notes |
|---|---|---|---|
| Backend | Go (REST, OpenAPI) | Java/Spring | ADR-018 |
| UI | React + TypeScript, all assets bundled locally, no CDN | Organisation standard (Q-30) | Required by the security-and-airgap egress rules |
| Metrics/alerting | Prometheus, Alertmanager, node_exporter (Apache-2.0), Grafana (**AGPL-3.0**) for operations views | VictoriaMetrics | Check AGPL acceptability (Q-17) |
| Platform logs | journald → local aggregation. Loki (**AGPL-3.0**) or a dedicated small OpenSearch/ClickHouse table. | | ADR-020 pending |
| Runtime | **systemd services**: native packages or Podman containers (Apache-2.0) managed by systemd | containerd | ADR-019 |
| Orchestration | **No Kubernetes in R1.** Node count (~12–14) and stateful tiers do not justify it (S-04 §8). | RKE2/k3s | Revisit if the node count grows a lot |
| Config management | Ansible (GPL-3.0) from the management node | | Works offline |
| Artifact repository | Local OS package mirror + OCI registry if containers are used (for example Harbor, Apache-2.0) | Plain file repository with signed artifacts | |
| Secrets | OPTCL's existing vault/HSM if available. Otherwise **OpenBao** (MPL-2.0, community fork of Vault). HashiCorp Vault is now under BSL. | Encrypted files + sealed break-glass | ADR-021 pending |
| PKI | OPTCL internal CA if one exists. Otherwise a small internal CA (for example step-ca, Apache-2.0, or the OpenBao PKI engine). | | |
| Time | chrony + local NTP servers. PTP where needed. | | |
| GeoIP | Offline DB. Candidates: DB-IP Lite (CC BY 4.0), MaxMind GeoLite2 (EULA with account and attribution terms). Commercial DB if accuracy needs it. | | Q-31 |
| TI platform | Flat signed STIX/CSV import into PostgreSQL (R1). MISP (AGPL-3.0) or OpenCTI (Apache-2.0) only if OPTCL wants a TI platform. | | |

## 3. Candidate reference architectures

All three options share the same collection layer (AF_PACKET + Zeek + Suricata-pending + goflow2), Kafka, Go workers, PostgreSQL for transactional state, and Prometheus/Grafana.

| Layer | **Option A — Search-centric** | **Option B — Split analytics** | **Option C — Lean split (proposed third option)** |
|---|---|---|---|
| Flows / sessions / packet_ref | OpenSearch | ClickHouse | ClickHouse |
| Alerts / incidents | OpenSearch (search) + PostgreSQL (workflow) | OpenSearch | PostgreSQL |
| PCAP archive | Arkime (index in the same OpenSearch) | Custom writer or Arkime (Arkime adds OpenSearch dependency, already present) | Custom writer, index in ClickHouse |
| Config, rules, assets, audit | PostgreSQL | PostgreSQL | PostgreSQL |
| Distinct stateful products (excluding queue and monitoring) | 2 (OpenSearch, PostgreSQL) + Arkime | 3 (ClickHouse, OpenSearch, PostgreSQL) | 2 (ClickHouse, PostgreSQL) |
| Custom code burden | Lowest for PCAP | Medium | Highest for PCAP indexing |

**Why Option C is meaningfully different:** it removes the search engine completely. This is possible because alert and incident volumes are low or medium (S-05 §3) and fit PostgreSQL, while the high-volume forensic and aggregation work (TR-29 to TR-31, TR-36) goes to a columnar store. The price is building and owning PCAP-to-session indexing and accepting weaker free-text search.

## 4. Scorecard

**Scale:** 1 = poor, 3 = adequate, 5 = excellent, relative to this project's requirements. **Weights:** provisional, from S-04 §11 / project brief (total 100%). **Scores are expert judgement from documentation. No benchmark has been run.** Confidence: L = low, M = medium, H = high.

| Criterion (weight) | Option A | Option B | Option C | Evidence and assumptions |
|---|---|---|---|---|
| Performance with 30% spare (25%) | 3 (L) | 4 (L) | 4 (L) | **Requires benchmark B-04/B-05.** Columnar stores generally compress flow data well and export large result sets efficiently. OpenSearch large-export speed and storage amplification are known concerns (S-04 §5). Not measured here. |
| Air-gap install/update/licence (15%) | 4 (M) | 4 (M) | 4 (M) | All candidates are open source with offline packages or tarballs. None needs online activation, as understood (verify). Arkime adds packaging work in A. |
| 5-year support & licence cost (15%) | 4 (M) | 3 (M) | 4 (M) | All Apache-2.0/PostgreSQL-licensed. B has three stores to support for 5 years. C has fewer products but more custom code to own. |
| Operational simplicity (15%) | 4 (M) | 2 (M) | 4 (M) | B runs two query engines and two clusters. A and C each run one analytics cluster plus PostgreSQL. |
| Explainability & evidence (10%) | 4 (M) | 4 (M) | 3 (L) | Arkime's session↔PCAP linkage is mature. C's linkage must be built and proven (B-06). |
| Integration suitability (10%) | 4 (M) | 4 (M) | 4 (M) | SIEM and context integrations are store-independent (CMP-INT). |
| Security & hardening (10%) | 4 (M) | 3 (M) | 4 (M) | B has the most surfaces to harden. OpenSearch security plugin, ClickHouse RBAC/TLS and PostgreSQL are all capable. |
| **Weighted total** | **3.75** | **3.45** | **3.90** | Σ(weight × score) |

**How to read the totals:** the gap between A and C (0.15) is **smaller than the uncertainty** in the performance score (25% weight, low confidence). On paper the options are effectively tied, and the benchmark decides.

## 5. Provisional recommendation

1. **Production target (provisional): Option C.** ClickHouse for flows, sessions and packet_ref. PostgreSQL for alerts, incidents, assets, rules, config and audit. Custom PCAP writer with per-session index. Kafka (KRaft). Zeek + goflow2. Suricata if B-01 CPU headroom allows. Go services. React/TS console. systemd-managed services with Ansible. Prometheus/Grafana.
2. **Fallback: Option A**, if a gate below fails for C.
3. **Option B is not recommended.** It carries the cost of both A and C without a requirement that needs both stores.
4. **Prototype stack:** the same components as the production target on a single node with replication factor 1, plus a **bounded proof of technology** (roadmap Phase 4/7) that loads the same replayed dataset into ClickHouse **and** OpenSearch and runs PD-01. The PCAP subsystem is prototyped with both a custom writer and Arkime-in-API-mode, compared on B-06.

### 5.1 Decision gates (what would change the recommendation)

| Gate | Test | If it fails |
|---|---|---|
| G-T1 | B-05: PD-01 (5M records, 180 s) meets target with ≥ 30% margin on ClickHouse at 130% ingest load | Re-evaluate the schema and partitioning. If still failing, try A. If both fail, escalate the TR-36 definition. |
| G-T2 | B-05 on OpenSearch also passes, **and** B-07 storage amplification is within budget | Option A becomes preferred because of Arkime evidence maturity and less custom code |
| G-T3 | B-06: custom PCAP retrieval for a 5-minute session at the 512 Mbps archive takes ≤ 30 s (proposed target, to agree) | Adopt Arkime for PCAP. That brings OpenSearch in, so move to A. |
| G-T4 | B-01: AF_PACKET + Zeek (+ Suricata) at 130% of the TR-42 profile, loss ≤ agreed limit, CPU ≤ 70% | Move to AF_XDP. Drop Suricata or put it on a separate sensor. Escalate to capture hardware. |
| G-T5 | Licence review (Q-17) accepts every component, including AGPL ones (Grafana/Loki) and GPL (Suricata, Ansible) | Substitute (for example VictoriaMetrics/own dashboards) |
| G-T6 | OPTCL operations team confirms it can operate the chosen stores, or a support contract is identified (DR-05) | Choose the option with the available support route |

## 6. Support routes (DR-05, OBL-01/02) — to be completed by the commercial owner

| Component | Upstream | Possible support routes (not verified, no contact made) | Status |
|---|---|---|---|
| Zeek, Suricata | Open source foundations / communities | Own team. Commercial vendors exist for both. | Unconfirmed |
| Kafka | Apache Software Foundation | Own team. Several commercial distributions. | Unconfirmed |
| ClickHouse / OpenSearch | Open source (company-led / Linux Foundation) | Own team. Commercial support from vendors. | Unconfirmed |
| PostgreSQL | PostgreSQL Global Development Group | Own team. Many vendors. | Unconfirmed |
| NBAD custom code | Bidder | Bidder (as "OEM", C-10) | Unconfirmed |

## 7. Explicit non-claims

- No benchmark result exists. Every performance statement above is a hypothesis to be tested.
- No compatibility with any OPTCL exporter, SIEM or appliance has been verified.
- Licence descriptions are not legal advice and must be re-verified.
