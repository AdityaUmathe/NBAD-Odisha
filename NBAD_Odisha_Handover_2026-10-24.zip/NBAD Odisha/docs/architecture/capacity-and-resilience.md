# NBAD Capacity, Resilience and Benchmark Strategy

**Status:** PROPOSED — draft v0.1 (2026-10-24). **Every number in this document is an estimate or a scenario calculation.** None is a measurement and none is a procurement size. Nothing has been benchmarked.
**Inputs:** S-08 (Capacity Workbook), S-09 (HA Runbook), S-02 §7–9. Where this document differs from S-08, the reason is stated, mainly C-03.

## 1. Sizing principles

1. **Do not size from 512 Mbps alone.** TR-42 sets a minimum *capture capability* at the DC Internet edge. Storage depends on the **average** captured rate. Sensor load depends on **packets per second** at peak. Indexing depends on **flows and sessions per second**.
2. **Spare capacity (C-03, ADR-011):** required capacity = peak demand ÷ 0.7. At peak, each tier uses ≤ 70% of its *tested* ceiling, which leaves ≥ 30% spare. This replaces the ×1.3 margin in S-08 (×1.3 leaves only about 23% spare).
3. **Redundancy on top:** after losing one node in each clustered tier, the remaining capacity must still meet the peak demand (S-08 §7).
4. **Replace estimates with measurements** as soon as the Q-07 inputs arrive. The worksheet in §8 records the source and date of each input.

## 2. Inputs required (none received yet)

| # | Input | Per | Source | Status |
|---|---|---|---|---|
| I-01 | Average and peak Mbps, per direction, 30 days | Observation point | Interface counters / SNMP | **Missing** |
| I-02 | Packets per second (avg/peak) and packet-size distribution | Observation point | Capture sample | **Missing** |
| I-03 | Concurrent flows, new connections per second | Observation point | Firewall / sensor sample | **Missing** |
| I-04 | Flow records per second (avg/peak), number of exporters, formats, sampling | Exporter | Exporter statistics | **Missing** |
| I-05 | Share of encrypted traffic | DC edge | Capture sample | **Missing** |
| I-06 | Number of hosts/assets per zone | Zone | Inventory | **Missing** |
| I-07 | Concurrent analysts and forensic queries | SOC | SOC | **Missing** (A-11 placeholder) |
| I-08 | Expected export volume per day | SOC | SOC | **Missing** |
| I-09 | Approved capture filters (if any) | — | OPTCL security | **Missing** (default: none, C-12) |
| I-10 | Replication, backup and recovery requirements | — | OPTCL operations | **Missing** (Q-14, Q-19) |
| I-11 | Rack, power, cooling, NIC and storage constraints | Site | Facilities | **Missing** (Q-18) |
| I-12 | Event (syslog) rates from firewall NAT, proxy, VPN, IPS | Source | Source owners | **Missing** |

## 3. Formulas

| Quantity | Formula |
|---|---|
| Raw PCAP per day | `R_avg_bps / 8 × 86,400 × (1 + h_pcap)`, where `h_pcap = 16 B / avg_packet_size` (PCAP per-packet record header) |
| Raw PCAP retained | `PCAP_day × D_raw × RF_pcap ÷ U_max`, plus filesystem reserve `f_fs` |
| Normalized per day | `(S_rate × s_session + F_rate × s_flow + P_rate × s_pref) × 86,400 ÷ c` (c = measured compression ratio) |
| Normalized retained | `Norm_day × D_norm × RF_store ÷ U_max` |
| Sensor required pps capacity | `PPS_peak ÷ U_max` |
| Sensor required bps capacity | `R_peak_bps ÷ U_max` |
| Queue disk | `ingest_bytes_per_s × queue_retention_s × RF_queue ÷ U_max` |
| Forensic export rate (TR-36) | `5,000,000 ÷ 180 s ≈ 27,778 records/s` (sustained during the run) |
| Allowed downtime at 99.9% | 43.2 min / 30-day month, 8.76 h / year (S-09 §2) |

Default parameters: `U_max = 0.7`, `RF_pcap = 2` (placeholder, to agree with OPTCL, Q-19), `RF_store = 2`, `RF_queue = 3`, `D_raw = 7`, `D_norm = 15`, `f_fs ≈ 5–10%` (assumption).

## 4. Scenarios

### 4.1 Raw PCAP at the DC Internet edge (7 days)

Assumptions: average packet 600 B (so `h_pcap` ≈ 2.7%). No capture filters. Decimal TB. RF 2. ÷ 0.7. Filesystem reserve excluded.

| Scenario | Avg captured rate | Per day | 7 days | + PCAP header | ÷ 0.7 | × RF 2 |
|---|---|---|---|---|---|---|
| Low | 128 Mbps (25% of 512) | 1.38 TB | 9.7 TB | 9.9 TB | 14.2 TB | **28.4 TB** |
| Base | 256 Mbps (50%) | 2.76 TB | 19.4 TB | 19.9 TB | 28.4 TB | **56.8 TB** |
| High | 512 Mbps sustained | 5.53 TB | 38.7 TB | 39.7 TB | 56.8 TB | **113.5 TB** |
| Stress | 1 Gbps sustained | 10.8 TB | 75.6 TB | 77.6 TB | 110.9 TB | **221.8 TB** |

Comparison with S-08 §2.2: S-08 gives 50.3 TB (×1.3) and about 100.6 TB with RF 2 for the High case. The difference comes from ÷ 0.7 (C-03) and the PCAP record header.

**Sensitivity:** linear in the average rate, retention days and RF. Choosing RF 1 + RAID (instead of RF 2) halves the storage, but a node loss then loses evidence. That is an OPTCL decision (AD-05).

### 4.2 Sensor packet-rate demand at TR-42 (512 Mbps)

| Average packet on the wire | pps at 512 Mbps | Required tested capacity (÷ 0.7) |
|---|---|---|
| 1,538 B (1,500 MTU + Ethernet overhead) | ≈ 41,600 | ≈ 59,400 pps |
| 600 B | ≈ 106,700 | ≈ 152,400 pps |
| 84 B (minimum frame, flood case) | ≈ 761,900 | ≈ 1,088,400 pps |

**Bitrate:** a sensor must be tested to about **731 Mbps** (512 ÷ 0.7) at the measured packet mix, and also checked at a harsher small-packet mix. Under A-04 (512 Mbps per direction), double these figures.

### 4.3 Normalized data (PD-02: sessions + flows + packet_refs, 15 days)

These are pure placeholders until I-03/I-04 are measured. The 4:1 compression is an **assumption** to be replaced by B-07.

| Scenario | Sessions/s × size | Flows/s × size | Raw per day | 15 days raw | 15 days at 4:1 | ÷ 0.7 × RF 2 |
|---|---|---|---|---|---|---|
| Low | 1,000 × 800 B | 2,000 × 200 B | 0.10 TB | 1.56 TB | 0.39 TB | **1.1 TB** |
| Base | 3,000 × 1,000 B | 5,000 × 200 B | 0.35 TB | 5.18 TB | 1.30 TB | **3.7 TB** |
| High | 8,000 × 1,500 B | 15,000 × 250 B | 1.36 TB | 20.4 TB | 5.10 TB | **14.6 TB** |

If OPTCL defines "normalized packet data" as **per-packet rows** (≈ 13.8 TB / 15 d uncompressed at 106,667 pps × 100 B, S-08 §5) or as a **normalized payload copy** (≈ 83 TB / 15 d), these numbers grow by one to two orders of magnitude. **Q-02 must be closed before storage is ordered.**

### 4.4 Other tiers (method only, values after benchmarks)

| Tier | Driver | First bottleneck to watch (S-08 §7) |
|---|---|---|
| Flow collectors | Flow records/s, exporters, templates | UDP receive buffers, template handling |
| Queue | Ingest bytes/s × retention (proposed ≥ 24 h to cover a weekend outage of a downstream store, to agree) | Disk throughput, partition count |
| Workers | Records/s, state size (baselines, graph) | CPU, memory |
| Analytics store | Insert rate, query concurrency, PD-01 | Disk IOPS/throughput, memory, merges |
| PostgreSQL | Alerts/incidents rate (low) | Rarely a bottleneck. Sized for HA, not load. |
| Packet archive | Sustained sequential write (≈ 64 MB/s at 512 Mbps per replica), retrieval seeks | Disk throughput |

## 5. Resilience design

The design intent is in [system-architecture §9](system-architecture.md). This section adds the operational parameters.

### 5.1 Failure domains

| Domain | Examples | Response | Residual risk |
|---|---|---|---|
| Sensor | NIC, disk, host | Overlap or standby sensor on critical links. Local spool. Health alarm. | Gap if there is no overlap. Recorded. |
| Node | Queue, store, archive, app | Replication, quorum, ≥ 2 instances | Capacity reduced. Must still meet peak after N−1 (§1 rule 3). |
| Rack / power / ToR switch | Shared PDU, switch | Spread replicas across racks, feeds and switches | Depends on facilities (Q-18) |
| Hypervisor host (if virtualised) | Several VMs on one host | Anti-affinity. No two replicas on one host. | Q-18 |
| Shared services | Time, DNS, CA, AD | Redundant local NTP/DNS. Cached directory data. Certificate-expiry alarms. | AD outage beyond the cache policy blocks new logins. Break-glass account remains. |
| Site | DC loss | Undefined until RTO/RPO and a second site are decided (Q-14) | **Open** |

### 5.2 Backpressure and overload policy

| Situation | Policy |
|---|---|
| Queue unreachable | Sensors and collectors spool to local disk (bounded size, proposed ≥ 1 h at peak, to size by benchmark), then count drops |
| Store slow or unavailable | Consumers pause. The queue retains. Lag alarm after 10 min of growth (S-09 §5). Detection on the stream continues where it does not need the store. |
| Detection lagging | Streaming rules take priority over batch analytics. Batch jobs are deferred and logged. |
| Heavy forensic queries | Per-user and global concurrency limits. Timeouts. Heavy exports run in a separate query pool or replica so ingestion and detection are protected (S-02 §18 risk). |
| SIEM slow | `out.siem` backlog. Never blocks detection or storage (S-07 §3). |
| Disk watermarks | Warning at 70%, critical at 85% (S-09). Retention enforcement before critical. **Never delete data younger than the retention minimum without approval.** |

### 5.3 Recovery objectives (decisions needed — Q-14)

| Item | Proposed discussion value | Agreed |
|---|---|---|
| RTO console and alerting | ≤ 1 h for single-node failures (automatic failover expected within minutes) | Pending |
| RTO full ingestion | ≤ 4 h (proposal) | Pending |
| RPO incidents, rules, configuration | ≈ 0 with synchronous replication, otherwise the backup interval (24 h) | Pending |
| RPO flow/packet data | Data during an outage is accepted as a documented gap unless the sensor spool covers it | Pending |
| Second site | None / warm standby / active-active | Pending |
| Uptime measurement | Window, service boundary, maintenance exclusions, whether degraded capture counts | Pending (AM-05) |

### 5.4 Backup scope

As S-09 §6.

| Item | Backed up | Notes |
|---|---|---|
| PostgreSQL (config, rules, incidents, assets, audit) | Yes | Daily, plus before every change. Monthly restore test. |
| Rules, policies and schemas as versioned exports | Yes | |
| Baselines and models | Yes | Daily snapshots |
| Keys and certificates | Yes | Encrypted offline copy |
| Flow/session data | No | Replication only |
| Raw PCAP | No | Replication only |

Backups are encrypted and stored in a separate failure domain.

### 5.5 Upgrade, rollback, schema migration

- Rolling upgrades one node at a time, with health checks between steps.
- Staging environment first (S-09 §8).
- Every release has a rollback procedure, rehearsed in staging.
- Schema migrations are versioned, applied by a migration tool, reversible where possible, and dual-run across MAJOR versions (data-flow-and-contracts §8).
- Upgrades arrive through the offline supply chain (security-and-airgap §6).

### 5.6 Monitoring and capacity alerts

Follows S-09 §5 (monitoring catalogue) and §4 (capacity discipline). Main rules:

- Raise a capacity ticket when projected peak use crosses 60% within the planning horizon.
- Re-test after any large traffic change.
- Platform health alerts travel on a path separate from security alerts, with a heartbeat.

### 5.7 Five-year lifecycle (OBL-01)

- Keep a component inventory with upstream end-of-life dates.
- Choose versions whose support window covers go-live + 5 years, or plan upgrades in advance (every major store version has a scheduled upgrade rehearsal).
- Track NIC driver and firmware lifecycle.
- Hold an annual configuration audit (OBL-02).

## 6. Availability: architecture intent vs evidence

The 99.9% target is a **contractual target, not a demonstrated property**. Architecture alone does not achieve it. These are also required:

- operations staffing for 24x7x365 (OBL-03);
- spares and hardware support;
- tested runbooks;
- measured failover times;
- a facility with independent power and network paths.

**No availability or zero-data-loss claim will be made until test results T11/RT-xx exist** ([test strategy](../testing/test-strategy.md)).

## 7. Benchmark plan

All benchmarks run on the **authorised remote environment** (Phase 2+). Comparisons use identical datasets, hardware, query definitions, retention settings and concurrent load. Results are recorded with hardware, versions, configuration, dataset hash and raw output. **None of these has been run.**

| ID | Benchmark | Method | Pass criterion (proposed, to agree) | Environment needed |
|---|---|---|---|---|
| B-01 | Sensor capture loss | Replay the measured mix and a small-packet mix at 100% and 130% of the TR-42 profile, for ≥ 1 h | Loss ≤ agreed limit (proposal 0.01%). CPU ≤ 70% at 100%. | **Representative NIC + hardware** (not a dev VM) |
| B-02 | Flow collector rate | Synthetic NetFlow/IPFIX at measured peak ×1.43 | No loss. Template handling correct. | Dev server OK for function. Representative for rate. |
| B-03 | Queue throughput and replay | Produce at peak ×1.43. Kill a broker. Replay 24 h of offsets. | No loss. Consumers recover. Replay is idempotent. | 3 nodes |
| B-04 | Normalize and store ingest | End-to-end at peak ×1.43 for ≥ 24 h | Lag bounded. CPU/disk ≤ 70% at peak. | Representative |
| B-05 | **TR-36 forensic retrieval (PD-01)** | Dataset of ≥ 15 days at base scenario. Defined query, filters, result ≥ 5M rows exported to a file, with ingestion and detection running. Repeat ≥ 5 times. Report p50/p95. | ≤ 180 s at p95 (G-T1 requires ≥ 30% margin, so ≤ 126 s) | Representative |
| B-06 | PCAP evidence retrieval | Retrieve sessions of 1 s, 5 min and 1 h from a full 7-day archive | Proposed: 5-min session ≤ 30 s (to agree) | Representative |
| B-07 | Storage amplification and compression | Measure bytes on disk per record per store | Feeds §4.3 | Dev server OK |
| B-08 | Detection throughput and latency | Replay with injected test cases | Latency within §8 budgets of system-architecture | Dev OK for function |
| B-09 | Search concurrency | N concurrent analyst queries (A-11) during ingest | p95 latency target to agree | Representative |
| B-10 | Disk exhaustion and backpressure | Fill disks and stall stores | Policies in §5.2 observed. No silent loss. | Dev OK |
| B-11 | Node and service failure | Kill each component type | Behaviour as in system-architecture §9 | Multi-node |
| B-12 | Recovery and backup restore | Restore PostgreSQL and models into a clean environment | Within agreed RTO | Multi-node |
| B-13 | Long-run soak | ≥ 7 days continuous at base load | No resource growth trend. Retention correct. | Representative |

**Environment caveat (A-10):** a single development server can validate *function* and *relative* comparisons (B-07, B-08, B-10). It **cannot** validate B-01, B-04, B-05, B-06, B-09, B-11 or B-13 at production scale. Those need production-representative hardware (Q-29), and results from smaller hardware must not be extrapolated into compliance claims.

## 8. Input worksheet

S-08 §8 is the master worksheet. Values are recorded there, or in this table when they are received.

| Input | Value | Source | Date | Recorded by |
|---|---|---|---|---|
| (none received) | | | | |
