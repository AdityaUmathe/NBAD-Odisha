# NBAD Security and Air-Gap Design

**Status:** PROPOSED — draft v0.1 (2026-10-24). This document extends S-10 (Air-Gap Operations and Security Design v0.1). OPTCL's air-gap boundary, transfer routes, cryptographic standards and approval authorities are **unknown** (Q-12, Q-25, Q-27). Where this document says "approved", it means approved by the authority OPTCL names. No such approval exists yet.

## 1. Boundary questions to close first (S-10 §2)

| Question | Linked | Design impact |
|---|---|---|
| Fully disconnected, or approved one-way / controlled transfer (data diode, transfer station, removable media)? | Q-12 | Update and feed procedure (§6, §7) |
| Who approves imports and exports, and how fast? | Q-12, Q-27 | Patch and feed cadence that can be promised |
| Which removable media is permitted and how it is scanned | Q-12 | Delivery route |
| OEM/vendor support model: on-site only, supervised session, none | Q-28 | 24x7 support (OBL-03) |
| Offline licence activation for any commercial component | Q-11, Q-17 | Component eligibility |
| "SLDC premises" vs "OPTCL premises" (C-04) | Q-27 | Who approves outbound movement |

**Until these are answered**, the design assumes the strictest case: a **fully disconnected** environment, where all inbound content arrives through a single controlled transfer station and there is **no** outbound path.

## 2. Threat model (summary)

| Threat | Example | Primary controls |
|---|---|---|
| Compromise of the NBAD platform itself (a high-value target: holds PCAP of the network) | Exploit of console or API, stolen admin credentials | Zones, MFA for admins, RBAC in the API, hardening, patching via §6, audit, pentest |
| Insider misuse of PCAP and metadata | Unjustified payload browsing or export | Separate payload permission, reason-required export, audit with hash chain, auditor role |
| Supply-chain tampering | Malicious package or rule bundle | Signed artifacts, hash verification, SBOM, malware scan, staged rollout |
| Data exfiltration from the platform | Telemetry, call-home, misconfigured connector | Default-deny egress, egress soak test, outbound path inventory (§9) |
| Poisoned threat-intel or baselines | Bad feed causing alert floods, or masking an attack | Feed review, expiry, rollback, baseline movement caps and freeze (S-06 §4) |
| Tampering with evidence | Altered PCAP or audit | SHA-256 on PCAP segments and exports, append-only audit with a hash chain, time sync |
| Collection blinding | Attacker floods the sensor to cause drops | Loss monitoring, `capture_loss` flags, capacity headroom, alarms |
| Disruption of production network by NBAD | Inline failure, bad automatic block | Passive only (ADR-001). No automatic actions (ADR-012). |

## 3. Network zones and trust boundaries

From S-10 §3 and S-03 §4.3, with the integration and transfer zones made explicit.

```mermaid
flowchart LR
    subgraph Z_CAP["Capture zone"]
        CAPN["Sensor capture NICs<br/>receive-only · no IP"]
    end
    subgraph Z_CORE["Platform core zone (mTLS)"]
        CORE["Queue · workers · stores · API"]
    end
    subgraph Z_AN["Analyst access zone"]
        RP["Reverse proxy (HTTPS)"]
    end
    subgraph Z_INT["Integration zone (allow-listed)"]
        CONN["Connectors · flow/syslog receivers"]
    end
    subgraph Z_MGMT["Management zone"]
        JH["Jump host (MFA)"]
        MG["Monitoring · repo · config mgmt · backup"]
    end
    subgraph Z_XFER["Transfer zone"]
        TS["Transfer/staging station<br/>verify signatures · scan"]
    end
    SOCN["SOC network"] -->|HTTPS| RP --> CORE
    CAPN --> CORE
    EXT["OPTCL systems<br/>SIEM · AD · exporters · sandbox"] <-->|per-destination allow-list| CONN <--> CORE
    JH -->|SSH| CORE
    MG --> CORE
    TS -->|one-way, after validation| MG
```

| Rule | Detail |
|---|---|
| R-Z1 | Capture NICs have no IP address and no transmit. Only the sensor process reads them. |
| R-Z2 | **No route from any platform zone to an external network.** Default-deny egress on every host (host firewall) and at the zone firewalls. |
| R-Z3 | Every cross-zone flow is documented (§9 and the integration inventory), firewalled and logged. |
| R-Z4 | Administrative access only through the jump host, with MFA where supported and session/command logging. |
| R-Z5 | The transfer zone pushes into management only after verification. Nothing flows from the platform to the transfer zone except audit-approved exports (§12). |

## 4. Identity, authentication and RBAC

Roles follow S-10 §4. The permissions below are the R1 proposal.

| Permission | Analyst | Senior analyst | Detection engineer | Network admin | Platform admin | Auditor | Break-glass |
|---|---|---|---|---|---|---|---|
| View alerts, incidents, dashboards | ✔ | ✔ | ✔ | ✔ | — | — | ✔ |
| Search flows/sessions (metadata) | ✔ | ✔ | ✔ | ✔ | — | — | ✔ |
| View/download PCAP payload | request | ✔ | ✔ (lab/test data) | — | — | — | ✔ |
| Approve packet export outside the platform | — | ✔ | — | — | — | — | — |
| Edit incidents, manage suppressions | own | ✔ | ✔ | — | — | — | ✔ |
| Create/test/enable rules, baselines, models | — | — | ✔ | — | — | — | ✔ |
| Manage sensors, exporters, zones, subnets | — | — | — | ✔ | — | — | ✔ |
| Manage users, integrations, backups, upgrades | — | — | — | — | ✔ | — | ✔ |
| Read audit log, configuration history | — | — | — | — | — | ✔ | — |
| Approve response-action execution (future) | — | ✔ | — | — | — | — | — |

- **Authentication:** LDAPS/StartTLS bind against AD with a read-only service account for lookups (S-07 §5). Directory groups map to roles. One local **break-glass** account with sealed credentials: every use raises an alert and needs a reason.
- **MFA** for administrative roles where the environment supports it (mechanism unknown, Q-20).
- **Authorization is enforced in the API** on every request, including on data class (RESTRICTED). The UI only hides controls.
- **Sessions:** short idle timeout (proposal 15 min for admin roles, 30 min for analysts), secure cookies, CSRF protection.
- **Separation of duties:** platform admins cannot read or alter the audit log, and auditors cannot change configuration.
- **Reviews:** role membership reviewed quarterly (S-10 §12).

## 5. Service identities and secrets

- Each service has its own identity (mTLS client certificate) and least-privilege credentials per store, for example a writer role for normalizers and a read-only role for the API search path.
- Secrets (DB passwords, connector credentials, signing keys) live in the secret store (ADR-021: OPTCL vault/HSM, or OpenBao). Services fetch them at start or have them injected by config management from the secret store. **Secrets never appear in source code, Git history, config files in the repository, logs or documentation.**
- Repository configuration uses placeholders only, for example `${SECRET:siem_connector_password}`.
- Rotation: certificates automatically before expiry (alarms at 30 and 7 days, S-09 §5). Passwords on a schedule set by OPTCL.

## 6. Offline software supply chain (install and upgrades)

From S-10 §6, made concrete:

```mermaid
flowchart LR
    B["Controlled build environment<br/>(outside the air gap)"] --> S["Sign artifacts<br/>record SHA-256 · SBOM"]
    S --> V["Malware + vulnerability scan"]
    V --> A["OPTCL change approval<br/>(written record)"]
    A --> T["Transfer via approved route"]
    T --> X["Transfer station:<br/>verify signature + hash"]
    X --> R["Internal repository<br/>(packages · images · bundles)"]
    R --> ST["Staging deploy + tests"]
    ST --> P["Production rolling deploy<br/>rollback plan ready"]
    P --> L["Install record:<br/>what · when · who · batch ID"]
```

| Control | Detail |
|---|---|
| Artifact types | OS packages, NBAD binaries, container images (if used), Python wheelhouse (ML), UI bundle, rule/content bundles, model artifacts, GeoIP DBs |
| Signing | An organisation signing key held outside the platform. The verification public key is installed on the platform. The mechanism (GPG, Sigstore-style offline signing, or OPTCL's standard) is to be chosen with OPTCL (Q-25). |
| SBOM | Generated per release (SPDX or CycloneDX). Kept with the release record. |
| Dependency pinning | All dependencies vendored or mirrored at pinned versions with hashes. Builds must not reach the Internet inside the air gap. |
| Cadence | Monthly security patch window plus an emergency path for critical fixes (S-10 §6). Both need OPTCL approval. |
| Rollback | Previous artifacts kept in the repository for N releases |

**Note on development (S-11 constraint):** development happens on the authorised remote server. Whether *that* server has Internet access for dependency retrieval is unknown and will be found during the Phase 2 assessment. If it does not, the same offline supply chain is used from the start of development. Either way, every dependency is recorded in a dependency inventory with version, licence and hash.

## 7. Offline content import (threat intel, GeoIP, rules, signatures)

Workflow from S-10 §7: collect outside, package (STIX 2.1 / CSV + source, timestamp, expiry, signature), review, transfer, verify and import to staging, promote, expire automatically, roll back a batch in minutes.

The same pipeline (CMP-TIF) handles:

- GeoIP databases;
- Suricata rule sets (licence of each ruleset to be checked);
- application signatures;
- NBAD rule bundles exported from the lab.

**Freshness limit (C-05):** indicator freshness equals the approved import cadence. This must be stated in the TR-34 response.

## 8. Cryptography

| Area | Proposal (subject to OPTCL standards, Q-25) |
|---|---|
| In transit | TLS 1.2+ (prefer 1.3) for every platform link. **mTLS** service-to-service. HTTPS for the console. LDAPS. Syslog over TLS where devices support it. |
| PKI | Internal CA (OPTCL's if available). Documented issuance, rotation and revocation. |
| At rest | Encryption for the packet archive, analytics store data volumes, PostgreSQL, backups. Mechanism: volume encryption (for example LUKS) unless OPTCL mandates otherwise. Keys held locally (vault/HSM). |
| Integrity | SHA-256 on PCAP files/segments, exported evidence and release artifacts |
| Unencrypted protocols that cannot be avoided | NetFlow/IPFIX/sFlow over UDP and plain syslog from legacy devices. Mitigation: dedicated integration zone, source allow-lists, sequence checks. Recorded as `provenance.transport_secure=false`. |

## 9. Outbound paths inventory and egress control

**Default: no outbound path exists.** Every path below is **proposed** and stays disabled until approved. All are internal to OPTCL premises.

| # | Path | Purpose | Data | Default | Approval needed |
|---|---|---|---|---|---|
| OUT-1 | NBAD → SIEM | Alert and incident forwarding (SOW-05) | Alerts, incident updates, back-links (no PCAP) | Disabled until configured | Yes (Q-10, C-04) |
| OUT-2 | NBAD → sandbox (on-prem) | File analysis (TR-40b) | Extracted files + hashes | Disabled | Yes (Q-22) |
| OUT-3 | NBAD → AD/LDAP | Authentication and lookups | Bind and queries | Enabled once configured | Yes |
| OUT-4 | NBAD → vulnerability scanner API | Pull scan results | API queries | Disabled | Yes |
| OUT-5 | NBAD → firewall/IPS APIs | **Future** response-action execution (ADR-012) | Change requests | **Out of scope for R1** | Separate authorisation |
| OUT-6 | Export of evidence (PCAP/CSV) outside the platform | Investigation, legal | Restricted data | Per-request approval (senior analyst + reason, audited, hashed) | Yes, per export (TR-35) |
| OUT-7 | Support bundle to vendor/OEM | Diagnostics | Logs/config, **redacted, no PCAP** | Per-request | Yes (§16) |

**Blocked dependency classes** (each is a defect until proven absent, S-10 §8): telemetry and crash reporting, online licence checks, update checks and plugin repositories, cloud geolocation/reputation/sandbox lookups, external DNS/NTP, externally loaded fonts/scripts/images in the console, support tunnels and remote agents.

**Verification:**

- default-deny egress on every host;
- packet capture on the management and integration segments during a soak test (≥ 72 h proposed);
- a signed dependency inventory before go-live;
- repeated after every upgrade (security test ST-01).

## 10. Audit and evidence handling

- Events per S-10 §10 and the `audit` schema in data-flow-and-contracts §5.11.
- **Append-only:** the application role can insert into audit tables and cannot update or delete. A hash chain (`prev_hash`, `hash`) makes tampering detectable. Hashes are periodically exported to the backup target and the management zone, outside the control of platform admins. Proposed tamper test ST-05.
- Audit times come from the synchronised clock.
- **Evidence export:** a package with the files, SHA-256 manifest, query used, requester, approver, time and reason (chain of custody).
- **Legal hold:** incidents can place a hold on referenced PCAP/flow partitions, and retention jobs skip held data (S-10 §11).

## 11. Host hardening

From S-10 §9. Each item becomes a check in the Phase 11 hardening review:

- minimal OS install against a secure baseline (CIS-style or OPTCL baseline, Q-25);
- unused services removed;
- host firewall on every node;
- separate admin accounts;
- no shared credentials;
- USB mass storage disabled except on the transfer station;
- SSH restricted to the jump host, key-based;
- privileged command logging;
- monthly vulnerability scanning with offline-updated signatures.

## 12. Handling PCAP and sensitive metadata

- PCAP and session payload fields are **RESTRICTED**. Viewing and downloading need a separate permission, and every access is audited with filter, files and reason.
- Retrieval is by `packet_ref`. Analysts get the minimal file segment, not whole archive files.
- No PCAP in SIEM messages, support bundles or logs.
- Retention deletion is automated and reported. Secure or cryptographic erasure where OPTCL policy requires it (S-10 §11).

## 13. Backup protection

Backups are encrypted, held in a separate failure domain, and protected from the platform admin role where possible. Restores are tested and recorded (S-09 §6).

## 14. Time synchronisation

chrony on every node, pointing to ≥ 2 local NTP sources (PTP where sensor precision needs it). Offset alarm at 50 ms on sensors (S-09). Offsets recorded in `health` and flagged on affected evidence (DR-09).

## 15. Offline licensing

Preference for components with no licence activation (ADR-010). Any commercial component must offer offline licence files and offline renewal. This must be verified **before** selection (Q-17). The TR-37 "unlimited hosts" position is a commercial deliverable (Q-11).

## 16. Support bundles and controlled diagnostics

- A support-bundle tool (Phase 11) collects versions, configuration (secrets redacted), health metrics and logs for a chosen window.
- **No PCAP or session payloads.**
- Output is a hashed archive for review.
- Release from the premises follows OUT-7 approval.
- On-site or supervised vendor sessions follow the OPTCL model (Q-28).

## 17. Dependency inventory and vulnerability management

- Every component and library is recorded with name, version, licence, source, hash and upstream EOL date (OBL-01).
- Vulnerability data is imported offline.
- Platform scan monthly (S-10 §12).
- Critical vulnerabilities trigger the emergency patch path.

## 18. Security testing

| ID | Test | When |
|---|---|---|
| ST-01 | Egress validation (no outbound traffic) | Before go-live, after every upgrade |
| ST-02 | Vulnerability scan of the platform | Monthly, and before go-live |
| ST-03 | Penetration test of console and API | Before go-live, after major changes |
| ST-04 | Access-control review and RBAC tests (API-level, every role) | Each release, plus quarterly review |
| ST-05 | Audit-log tamper test | Before go-live |
| ST-06 | Restore test | At least twice a year |
| ST-07 | Offline update rehearsal (full supply chain) | Before go-live, then yearly |
| ST-08 | Feed import: tampered batch rejected, rollback works | Each release of CMP-TIF |

## 19. Open items

Q-12, Q-17, Q-20, Q-25, Q-27, Q-28 in [open-questions-and-risks](open-questions-and-risks.md). Also S-10 §13: written air-gap boundary, cryptographic standards, offline licensing, supervised-support model, retention and legal-hold policy.
