# NBAD Integration Design and Inventory

**Status:** PROPOSED — draft v0.1 (2026-10-24). This document extends S-07 (Integration Specification v0.1). **No OPTCL product, version or API is known**, so no compatibility is claimed. Every row has verification status "Unverified" until its integration test passes on the authorised environment.

## 1. Common rules

Taken from S-07 §3 and binding for every connector:

- versioned contracts;
- idempotent, at-least-once delivery with acknowledgement;
- bounded buffering with health alarms, which never blocks detection or storage;
- one least-privilege account per connector, with credentials in the secret store;
- read-only by default;
- per-connector health (last success, last error, lag, volume);
- no external or cloud paths.

**Ingesting data and changing an external system are different things.** Inbound connectors only read. Anything that changes an external system is a response action (§4), which is out of scope for R1 beyond suggest/prepare (ADR-012).

## 2. Integration inventory

Abbreviations: Dir = direction (→NBAD inbound, NBAD→ outbound). R1 = first release.

| # | System | Purpose | Dir | Protocol / format (proposed) | Auth | Data exchanged | Permissions needed | Failure / retry behaviour | Audit | Network access | Offline limits | Dependencies | R1? | Verification |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| INT-01 | **SIEM** | Forward alerts/incidents, single view (SOW-05, TR-25) | NBAD→ | Syslog/TLS RFC 5424 with CEF or JSON, or REST | TLS client cert or API token | Common alert message, incident updates, back-link URL | Write to SIEM ingest | Queue `out.siem`, exponential backoff, ordered per incident, backlog alarm | Delivery log (ID, time, result) | Integration zone → SIEM collector port | None if the SIEM is on-prem | SIEM product/version and parser (Q-10) | **Yes** (required) | Unverified |
| INT-02 | **AD / LDAP** | Console login, role mapping, user/computer context | →NBAD | LDAPS / StartTLS | Read-only service account | Users, groups, computer objects | Read on the relevant OUs | Local cache with refresh. Break-glass if AD is down. | Login and role-change audit | → DCs 636/389 | — | Directory structure, groups (Q-20) | **Yes** (auth) | Unverified |
| INT-03 | **Routers / switches** | Flow records (TR-22, TR-26), interface names | →NBAD | NetFlow v5/v9, IPFIX, sFlow v5. SNMP v3 read for ifName. | UDP: source allow-list. SNMPv3 auth/priv. | Flows, interface metadata | Device config change by the network team (export target) | UDP has no retry: sequence-gap counters, exporter-silence alarm (5 min). Dual collectors where devices support two targets. | Exporter inventory changes | Devices → collector ports (2055/4739/6343, to confirm) | — | Model/firmware list, templates, sampling (Q-09) | **Yes** (DC/Main LDC) | Unverified |
| INT-04 | **Firewalls** | Flow/session logs, **NAT logs** (TR-09), policy hits | →NBAD | NetFlow/IPFIX and/or syslog (TLS where supported). Vendor API optional, read-only. | Allow-list / TLS / API token | Flows, NAT translations, policy-hit events | Log forwarding config | Same as INT-03. Syslog over TCP/TLS buffers on the device where supported. | | → receivers | — | Vendor/model (Q-23) | **Yes** (NAT needed at the DC edge) | Unverified |
| INT-05 | **IPS** | Correlate signature hits with behaviour | →NBAD | Syslog or vendor API | TLS / token | IPS alerts, normalised to the alert schema (`detection.method=signature`, source=ips) | Log forwarding | As syslog | | → receiver | — | Q-23 | Optional (R2) | Unverified |
| INT-06 | **VPN** | User ↔ address mapping for remote access | →NBAD | Syslog, RADIUS accounting logs | TLS / allow-list | Session start/stop, user, assigned IP | Log forwarding | As syslog | | → receiver | — | Q-23 | Optional (R2) | Unverified |
| INT-07 | **Internet proxy** | URL, category, user context. Partial TR-33 coverage. | →NBAD | Syslog or log-file forwarding | TLS / allow-list | Web access logs | Log forwarding | As syslog | | → receiver | — | Q-23 | Recommended (R1 if available, for TR-33) | Unverified |
| INT-08 | **Vulnerability management** | New vulnerable host (TR-32), asset enrichment | →NBAD | API pull (scheduled) or controlled file import (CSV/XML/JSON) | API token (read-only) | Per-host findings with severity and scan date | Read scan results | Retry on schedule. Stale-data flag. | Import batch record | → scanner API, or file via transfer process | Must be on-prem | Product (Q-21) | **Yes** (TR-32) | Unverified |
| INT-09 | **Threat intelligence feeds** | Indicator matching (TR-34) | →NBAD (offline) | Signed STIX 2.1 / CSV batch via the transfer zone | Signature verification | Indicators with expiry | — | Reject tampered or unsigned batches. Rollback. | Import batch audit | Transfer zone only | **Freshness = import cadence** (C-05) | Feed sources and cadence (Q-24) | **Yes** | Unverified |
| INT-10 | **Sandbox** | Malware analysis of extracted files (TR-40b) | NBAD→ and verdict → | Vendor API on-prem | API token | File + hash out, verdict/score/report link back | Submit and read verdicts | Hash pre-filter. Queue with size and depth limits. Poll with timeout. | Submission audit | Integration zone → sandbox API | Must be on-prem. Cleartext-extracted files only. | Product (Q-22) | Optional (R2) — confirm | Unverified |
| INT-11 | **Switches (SPAN) / TAPs / packet broker** | Mirrored packets | →NBAD | Physical/ERSPAN | — | Frames | Network change by the network team | Loss monitoring | Change record | Capture zone | — | Q-06 | **Yes** | Unverified |
| INT-12 | **Hypervisor** | Virtual traffic visibility (TR-16) | →NBAD | vSwitch mirror / ERSPAN / hypervisor flow export | Per product | Frames or flows | Hypervisor admin config | As INT-03/11 | | | — | Product (Q-05) | R2 unless confirmed earlier | Unverified |
| INT-13 | **Time service** | Accurate timestamps (DR-09) | →NBAD | NTP (PTP optional) | NTP auth if supported | Time | — | ≥ 2 sources, offset alarm | — | → local NTP | Local only | OPTCL NTP servers | **Yes** | Unverified |
| INT-14 | **Firewall/IPS APIs (response)** | Execute approved mitigation | NBAD→ | Vendor API | Dedicated account | Block-rule changes | Write (high risk) | Not built in R1 | Full approval audit | Restricted | — | Policy (Q-34) | **No** (ADR-012) | — |

## 3. Supported-product list (TR-25 deliverable)

TR-25 asks for a "list of supported technology and products and products/technologies not supported". This list will be produced **only from integration test results** (Phase 9). It is a compatibility matrix of vendor, model, firmware, format, test date and result (S-07 §7). It starts empty. **No product is listed as supported today.**

## 4. Response actions (TR-10)

S-07 §11 levels, with the R1 scope from ADR-012:

| Level | R1 | Notes |
|---|---|---|
| Suggest (recommended action text on the alert) | **In scope** | Per-detection playbook text, for example for DoS: upstream rate-limit request, ACL candidates, ISP contact procedure |
| Prepare (exact change built, not sent) | **In scope** | Visible to the analyst. Exportable for manual application by the network/security team. |
| Execute with approval | Out of scope for R1 | Needs separate authorisation, a never-block list, expiry/rollback and full audit |
| Automatic | **Out of scope** | Conflicts with passive-first (C-06) |

## 5. Integration test checklist

As S-07 §12. The tests are numbered IT-xx in the [test strategy](../testing/test-strategy.md).
