# NBAD Operations Planning (future deployment)

**Status:** PLANNING — draft v0.1 (2026-10-24). Nothing here is deployed. This document is the operations index. It points to the detailed design and lists what Phases 11 and 13 must produce. It does **not** contain deployment manifests or installation scripts (they are out of scope until the technology decisions are approved).

## 1. Deployment planning

| Topic | Design reference | To be produced (phase) |
|---|---|---|
| Production topology and failure domains | system-architecture §7, capacity-and-resilience §5.1 | Site-specific deployment plan (P13) after Q-14, Q-18 |
| Hardware sizing | capacity-and-resilience §3–4 | Bill of materials **after** B-01 to B-06 (P12) |
| Network zones and firewall rules | security-and-airgap §3, integration-design §2 | Firewall rule request per zone (P11/P13) |
| Deployment mechanism | ADR-019 (systemd + Ansible) | Playbooks (P3 onward, on the remote server only) |
| Staging environment | S-09 §8 | Staging spec (P11) |

## 2. Air-gap procedures

| Procedure | Reference | Deliverable |
|---|---|---|
| Software import and upgrade | security-and-airgap §6 | Step-by-step SOP with forms (P11) |
| Content import (TI, GeoIP, rules) | security-and-airgap §7 | SOP + CMP-TIF operator guide (P9/P11) |
| Evidence export | security-and-airgap §9 (OUT-6), §10 | SOP with approval form |
| Support bundles | security-and-airgap §16 | Tool + SOP (P11) |
| Egress validation | security-and-airgap §9, ST-01 | Test record per upgrade |

## 3. Backup and recovery

| Item | Reference | Deliverable |
|---|---|---|
| Backup scope and schedule | capacity-and-resilience §5.4, S-09 §6 | Backup configuration + restore runbook |
| Recovery objectives | capacity-and-resilience §5.3 | Agreed RTO/RPO table (Q-14) |
| DR stages | S-09 §7 | DR runbook |
| Restore testing | ST-06, RT-07 | Test records |

## 4. Monitoring and maintenance

| Item | Reference | Deliverable |
|---|---|---|
| Monitoring catalogue and alert rules | S-09 §5, capacity-and-resilience §5.6 | Alert rules + dashboards (P11) |
| Runbooks | S-09 §9 (drops, lag, search health, archive capacity, baseline misbehaviour, certificates, time drift, SIEM connector) | Expanded runbooks (P13) |
| Maintenance windows and change control | S-09 §8 | Change procedure agreed with the SOC |
| Patch cadence | security-and-airgap §6 | Monthly window + emergency path |
| Capacity reviews | capacity-and-resilience §5.6 | Weekly trend report |
| Lifecycle / EOL tracking | capacity-and-resilience §5.7 | Component EOL register |

## 5. Support model

Roles from S-09 §10: Tier 1 operations, Tier 2 platform engineers, on-call engineer (24x7x365), detection engineers, security officer, OEM/vendor escalation.

**Open:** who staffs each role, response and resolution times, and how the "OEM" obligation is met for a self-built platform (Q-28, C-10).
