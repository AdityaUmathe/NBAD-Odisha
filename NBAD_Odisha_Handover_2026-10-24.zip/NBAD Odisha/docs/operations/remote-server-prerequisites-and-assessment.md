# Remote Server Prerequisites and Assessment Procedure (Phase 2)

**Status:** PROCEDURE — not yet executed. **No server has been accessed.** No credentials have been received, requested from other sources, or stored.
**Governing rule:** ADR-023 (remote-server-only development) and the project lead's instructions (S-11).

## 1. What the project lead provides

| # | Item | Notes |
|---|---|---|
| 1 | Hostname/IP and SSH port of the **one** authorised server (or an explicit list, if more than one) | Only these hosts may be connected to |
| 2 | Account name and authentication method | Credentials are shared through a channel the lead chooses. They are **never** written into the repository, documentation, logs or command history files. |
| 3 | Intended role of the server | Dev only, dev + staging, or benchmark-capable (AD-11) |
| 4 | Permitted actions after the assessment | For example: package installation allowed? Containers allowed? Sudo scope? |
| 5 | Existing workloads that must not be disturbed | Services, ports, directories to avoid |
| 6 | Network policy | Is Internet access expected or forbidden? Is a proxy or internal mirror available? |
| 7 | Data policy | May test PCAP/flow datasets be copied to the server? How? (Q-33) |
| 8 | Working directory | Where project files may be created |

## 2. Minimum resource expectations (for the dev role)

These are **estimates** for a single-node functional environment (all components with replication factor 1, replayed traffic at reduced rates). They are not production sizes.

| Resource | Minimum | Comfortable | Why |
|---|---|---|---|
| CPU | 8 vCPU | 16+ vCPU | Zeek/Suricata + queue + store + workers concurrently |
| RAM | 32 GB | 64 GB | Queue + analytics store + PostgreSQL + analyzers |
| Disk | 500 GB SSD | 1–2 TB NVMe | Test PCAPs, 15-day dev retention at reduced rate, build artifacts |
| OS | 64-bit Linux, a supported LTS release (distribution TBD, Q-18) | Same as the production target | Packaging parity |
| Network | SSH access | Optional dedicated or virtual interface for replay | Capture tests use replay into a virtual interface |
| Privileges | Ability to install packages and run services **once authorised** | Scoped sudo | Phase 3 onward |

**For benchmarks B-01, B-04, B-05, B-06, B-09, B-11 and B-13**, representative hardware is needed: capture-grade NIC, NVMe, production-like core counts and multi-node. A dev server will not prove these (A-10, R-15).

## 3. Assessment procedure (read-only)

Rules during assessment:

- Connect only to the authorised host.
- Run **read-only** commands only. No installs, no configuration changes, no service restarts, no file changes outside a personal scratch directory (only if the lead permits).
- Do not run active network tests (port scans, Internet reachability probes) unless the lead explicitly permits each one.
- Record the outputs in the assessment report. Redact secrets and anything sensitive.

| Area | Information to collect | Example read-only commands (typical Linux; adapt to the distribution) |
|---|---|---|
| Identity of host | Hostname, OS, kernel, virtualisation | `hostnamectl`, `cat /etc/os-release`, `uname -r`, `systemd-detect-virt` |
| CPU | Model, cores, NUMA, flags (AF_XDP/AVX relevance) | `lscpu`, `nproc` |
| Memory | Total/available, swap | `free -h`, `swapon --show` |
| Storage | Disks, type (SSD/NVMe/HDD), RAID, filesystems, free space, mount options | `lsblk -o NAME,SIZE,TYPE,ROTA,MOUNTPOINT,FSTYPE`, `df -hT`, `findmnt` |
| Network | Interfaces, drivers, speeds, IPs, routes, DNS | `ip -br addr`, `ip route`, `ethtool -i <if>` / `ethtool <if>` (read), `resolvectl status` or `cat /etc/resolv.conf` |
| Time | NTP sync source and state | `timedatectl`, `chronyc sources` / `chronyc tracking` (if present) |
| Existing services | Running units, listening ports, containers | `systemctl list-units --type=service --state=running`, `ss -tulpn` (as permitted), `podman ps` / `docker ps` (only if already installed, read-only) |
| Installed software | Package manager, runtimes present (language toolchains, DBs, Java, Python versions) | `rpm -qa` / `dpkg -l` (filtered), `python3 --version`, `which go java node` |
| Security controls | SELinux/AppArmor, host firewall, audit, login policies | `getenforce` / `aa-status` (read), `nft list ruleset` / `firewall-cmd --list-all` (read, if permitted), `systemctl is-active auditd` |
| Privileges | Sudo scope, groups | `id`, `sudo -n -l` (non-interactive, no password prompt) |
| Limits | ulimits, kernel params relevant to capture and DBs | `ulimit -a`, `sysctl net.core.rmem_max vm.max_map_count` (read) |
| Package sources | Configured repositories/mirrors, proxy variables | `cat /etc/yum.repos.d/*` or `/etc/apt/sources.list*`, `env \| grep -i proxy` |
| Connectivity (passive) | Whether Internet or mirror access *appears* configured | Inspect configuration only. **No outbound probe without explicit permission.** |
| Capacity headroom | Current load and usage trends | `uptime`, `vmstat 1 5`, `iostat` (if present) |

## 4. Assessment report (template)

The report is created as `docs/operations/server-assessment-<hostname>-<date>.md` in Phase 2.

1. Summary: suitable or unsuitable for the dev role, and key constraints.
2. Facts collected (tables per area above). Sensitive values redacted.
3. Comparison with §2 minimum expectations.
4. Conflicts with the proposed architecture. Examples: kernel too old for AF_XDP, no NVMe, SELinux policy constraints, existing service on required ports, no package access.
5. Risks to existing workloads and how they will be avoided.
6. Dependency delivery route: online mirror, internal mirror, or offline transfer.
7. **Server-specific implementation plan** for Phase 3: directories, users, ports, resource limits, what will be installed and from where, and rollback for each change.
8. Questions for the project lead.
9. Explicit statement that nothing was changed during the assessment.

The plan is executed **only after the project lead approves it** (Phase 2 gate).

## 5. Rules after approval (Phase 3 onward)

- Change only what the approved plan lists. Never overwrite, restart, expose or remove existing services without explicit authorisation.
- Use dedicated service accounts, directories and ports.
- Keep a change log on the server and in `CHANGELOG.md`.
- No secrets in Git, logs or docs.
- Do not assume Internet access.
- Report actual results only.
