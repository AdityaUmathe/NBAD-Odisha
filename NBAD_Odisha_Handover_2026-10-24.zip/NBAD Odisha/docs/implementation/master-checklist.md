# NBAD Master Implementation Checklist

**Last updated:** 2026-10-24
**Current phase:** Phase 1 complete (documentation). **Waiting at the Phase 1 gate** for project-lead review of AD-01 to AD-14 and for remote-server credentials (Q-29).
Phase definitions, acceptance criteria and effort assumptions are in [../architecture/implementation-roadmap.md](../architecture/implementation-roadmap.md).

**Status keys:**

| Key | Meaning |
|---|---|
| ☐ | Not started |
| ◐ | In progress |
| ☑ | Done (validated as stated) |
| ⛔ | Blocked |
| ⏸ | Waiting for approval |

## 1. Phase-gate rules

1. One phase at a time.
2. Before starting a phase, state its objective, prerequisites, planned changes, risks and acceptance criteria, then get confirmation.
3. Change only what the phase needs.
4. Validate with available checks. Separate checks performed from checks pending.
5. Update this checklist and `CHANGELOG.md` at the end of the phase.
6. Report changed files, decisions, test results, blockers and remaining work.
7. **Stop at the phase boundary** and wait for the project lead's instruction.
8. When blocked on a decision, present the alternatives with a recommendation.
9. Do not repeat completed work without a specific reason.
10. From Phase 2 onward, every build, install, test or deployment happens **only on the authorised remote server** (ADR-023).

## 2. Phase summary

| Phase | Name | Status | Gate condition | Blockers |
|---|---|---|---|---|
| 0 | Repository and requirements | ☑ Done (documentation level) | Requirements baseline, conflicts, traceability exist | Original tender unavailable (Q-15). Baseline built from the working copy. |
| 1 | Architecture and technology decisions | ☑ Done (documentation) / ⏸ approval | Project lead decides on AD-01 to AD-14 | Awaiting review |
| 2 | Remote server assessment | ⛔ Blocked | Credentials + instruction. Assessment report + approved plan. | Q-29 |
| 3 | Development foundation | ☐ | Phase 2 plan approved | Phase 2 |
| 4 | Collection and ingestion | ☐ | Phase 3 accepted. Test datasets available. | Q-33 (samples), Q-09 |
| 5 | Normalization and enrichment | ☐ | Phase 4 accepted | Q-09 (real samples for schema freeze) |
| 6 | Initial detection capabilities | ☐ | Phase 5 accepted. Use-case priority agreed. | Q-16 |
| 7 | Storage and investigation | ☐ | Phase 5 accepted. PoT run. ADR-013/014 decided. | — |
| 8 | Backend and analyst interface | ☐ | Phases 6 and 7 accepted | Q-20 (auth) |
| 9 | Integrations | ☐ | Phase 8 accepted. Product details and test endpoints. | Q-10, Q-20 to Q-23 |
| 10 | Advanced analytics | ☐ | Phases 6 and 7 stable. History available. | — |
| 11 | Security and resilience | ☐ | Multi-node environment | Q-29, Q-12, Q-25 |
| 12 | Performance and acceptance | ☐ | Definitions and thresholds agreed. Representative hardware. | Q-01, Q-02, Q-04, Q-15 |
| 13 | Deployment and handover | ☐ | Acceptance + OPTCL approval | — |

## 3. Detailed checklist

### Phase 0 — Repository and requirements
- ☑ Inspect working directory. Not a Git repository. 10 `.docx` source documents + 1 text clipping (project brief). No code.
- ☑ Read all source documents S-01 to S-11 (text extracted read-only with the built-in macOS `textutil` into the session scratch area, outside the repository).
- ☑ Requirements baseline: 42 TR, 7 SOW, 7 OBL, 10 DR ([requirements-baseline](../requirements/requirements-baseline.md)).
- ☑ Conflicts C-01 to C-13, ambiguities AM-01 to AM-09, assumptions A-01 to A-12 ([ambiguities-and-conflicts](../requirements/ambiguities-and-conflicts.md)).
- ☑ Traceability matrix covering all TR/SOW/OBL/DR ([traceability-matrix](../requirements/traceability-matrix.md)).
- ⛔ Validate against the original 107-page tender (Q-15). Not available.

### Phase 1 — Architecture and technology decisions
- ☑ System architecture: planes, components, trust boundaries, observation points, topology, failure behaviour.
- ☑ Data flows and contracts: envelope, 11 record types, IDs/deduplication, validation, evolution, retention, API/SIEM contracts.
- ☑ Technology evaluation: per-category options, Options A/B/C, scorecard, provisional recommendation, gates G-T1 to G-T6.
- ☑ Capacity and resilience: formulas, low/base/high scenarios, backpressure policy, recovery decisions, benchmark plan B-01 to B-13.
- ☑ Security and air-gap: zones, RBAC, secrets, supply chain, content import, outbound path register, audit, hardening, security tests.
- ☑ Integration design and inventory (INT-01 to INT-14).
- ☑ ADR log ADR-001 to ADR-024 and approval list AD-01 to AD-14.
- ☑ Open questions Q-01 to Q-35 and risks R-01 to R-22.
- ☑ Roadmap with phases, criteria and effort assumptions.
- ☑ Test strategy (DT/FT/IT/RT/T).
- ☑ Remote server prerequisites and read-only assessment procedure.
- ☑ Static documentation checks (see CHANGELOG 0.1.0 for actual results).
- ⏸ **Project lead decides on AD-01 to AD-14.**
- ⏸ Bid lead / OPTCL answers the P1 questions (Q-01 to Q-04, Q-06 to Q-15, Q-17, Q-26 to Q-29).

### Phase 2 — Remote server assessment (do not start without instruction)
- ⛔ Receive credentials and the authorised scope (Q-29).
- ☐ Read-only assessment per the procedure.
- ☐ Assessment report + conflicts with the architecture.
- ☐ Server-specific implementation plan.
- ☐ Project lead approves the plan.

### Phase 3 onward
Tracked once Phase 2 completes. Items come from the roadmap §3 work lists.

## 4. Decisions awaiting the project lead

AD-01 to AD-14, with recommendations, in [architecture-decisions](../architecture/architecture-decisions.md#decisions-requiring-approval-ad-list).
