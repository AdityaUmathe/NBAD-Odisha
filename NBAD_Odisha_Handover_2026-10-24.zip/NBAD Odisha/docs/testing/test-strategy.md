# NBAD Test Strategy, Scenarios and Acceptance Tests

**Status:** PROPOSED — draft v0.1 (2026-10-24). **No test has been executed.** All tests run on the authorised remote environment (ADR-023). Pass thresholds marked "to agree" must be fixed with the project lead and OPTCL **before** testing (S-02 §13).

## 1. Principles

1. Each test has written expected results: alert name, entity, window, evidence, measured values.
2. Results are recorded with environment (hardware, versions, config), dataset ID and hash, date, executor, raw output and pass/fail.
3. A dashboard demonstration alone is never evidence of throughput, search performance, retention or HA (S-02 §13).
4. Results from non-representative hardware are labelled as such and are not used for compliance claims (A-10).
5. Attack traffic is generated only in an isolated lab network or replayed into a virtual interface, never on production links (S-04 §9).

## 2. Test levels

| Level | What | Where | When |
|---|---|---|---|
| Unit | Functions, mappers, rule logic | Remote dev server | Every change (Phase 3+) |
| Contract | JSON Schemas, OpenAPI, SIEM message format | Remote dev server | Every change |
| Component | One service with real dependencies | Remote dev server | Per phase |
| Integration (IT) | Connectors with real or test endpoints | Remote env + OPTCL test systems | Phase 9 |
| Detection (DT) | Use cases against the test corpus | Remote dev server | Phase 6, 10 |
| Functional (FT) | Console and API features | Remote env | Phase 7, 8 |
| Benchmark (B) | Performance | Representative env | Phase 4 (function), Phase 12 (scale) |
| Resilience (RT) | Failure and recovery | Multi-node env | Phase 11 |
| Security (ST) | Egress, vulnerability, pentest, RBAC, tamper | Remote/staging | Phase 11, each release |
| Acceptance (T) | POC plan T1 to T12 | Representative env | Phase 12 |

## 3. Environments

| Env | Purpose | Can validate | Cannot validate |
|---|---|---|---|
| Dev (authorised remote server, A-10) | Development, function, relative comparisons | Unit, contract, component, DT, FT, B-07, B-08, B-10, functional parts of B-02/B-03 | Line-rate capture, production-scale TR-36, HA, failure domains |
| Staging (to be provided) | Pre-production rehearsal, upgrades | Upgrade/rollback, ST-07 | Production scale (unless sized the same) |
| Representative / POC (Q-29) | Benchmarks, acceptance | B-01 to B-13, RT, T | — |

## 4. Test corpus (S-06 §11)

- **Benign baseline:** approved OPTCL traffic samples (Q-33). If they are not approved, use synthetic or public research datasets (for example CIC-IDS2017, UNSW-NB15, CTU-13, imported offline), **labelled as non-OPTCL**.
- **Attack scenarios:** generated in the isolated lab, one per DT case (tools from S-04 §9: nmap/masscan, hping3, tcpreplay, scapy, scripted beacons, DNS tunnelling tool).
- **Synthetic stress data:** for benchmarks.
- Versioned, hashed, stored offline, with an expected-results file per case and a scoring sheet (detected, missed, false alarms, time to detect).

## 5. Detection tests (DT)

| ID | Use case | Requirement | Scenario | Expected |
|---|---|---|---|---|
| DT-01 | Vertical port scan | TR-08 | nmap against a lab host | `port_scan` alert with source, target, distinct ports, window, flow evidence |
| DT-02 | Horizontal sweep | TR-08 | Sweep a lab subnet on one port | `horizontal_scan` alert |
| DT-03 | Volumetric DoS/DDoS | TR-08, TR-18 | Flood-like replay to one target | Alert with pps/bps observed vs baseline, plus mitigation suggestion (IT-15) |
| DT-04 | SYN flood | TR-08 | SYN-heavy traffic | Alert with SYN ratio |
| DT-05 | Worm propagation | TR-05 | Simulated fan-out across lab hosts on a service port | Alert with propagation chain |
| DT-06 | Beaconing | TR-03 | Periodic callbacks with jitter | Alert with period, jitter, destination |
| DT-07 | Long-lived connection | TR-12 | Hold a connection open beyond the threshold | Alert (including when the exporter splits the flow) |
| DT-08 | Non-standard port / protocol mismatch | TR-13, TR-27 | HTTP or SSH on an unusual port | Alert with detected vs expected protocol |
| DT-09 | Unexpected service | TR-08, TR-14 | New listening service on a lab host | Alert |
| DT-10 | New host | TR-32 | Connect a new lab host | New-host event, plus shown in the console |
| DT-11 | New vulnerable host | TR-32 | New host + test scan import with high findings | Alert with scan date |
| DT-12 | Policy violation | TR-08, TR-14, SOW-04 | Traffic matching a forbidden rule | Alert citing the policy rule version |
| DT-13 | Risky application | TR-20 | P2P/file-sharing protocol in the lab | Alert with app category |
| DT-14 | Unknown-country communication | TR-40b | Flows with test addresses mapped to a non-baseline country | Alert with country, business context, IPs |
| DT-15 | DNS tunnelling | TR-08 | DNS tunnelling tool in the lab | Alert with entropy/volume features |
| DT-16 | Low-and-slow exfiltration | TR-11b, TR-04 | Slow transfer over several days (time-compressed replay acceptable, documented) | Longitudinal alert |
| DT-17 | Lateral movement | TR-04 | New internal SMB/RDP edges | Alert with new edges |
| DT-18 | Novel pattern (ML) | TR-24, TR-37 | Synthetic outliers | ML alert with contributing features |
| DT-19 | Threat-intel match | TR-34, TR-03 | Indicator in a test feed + matching traffic | Alert citing the indicator and import batch |
| DT-20 | Tunnelled application classification | TR-27 | Application over HTTP transport in the lab (cleartext) | Classified as the application, not as HTTP. Encrypted case documented as a limitation. |
| DT-21 | Baseline deviation (hour/day/week) | TR-31, TR-18, SOW-07 | Inject deviations after the learning period | Alert with observed vs expected bucket |

For **every** DT: false positives on the benign corpus are measured and reported, replay produces no duplicate alerts, and the evidence links resolve.

## 6. Functional tests (FT)

| ID | Feature | Requirement |
|---|---|---|
| FT-01 | 3+ zones configured, scoped dashboards and thresholds | TR-01 |
| FT-02 | Central dashboard (traffic, alerts, health) | TR-02, TR-07 |
| FT-03 | Analysis by IP, IP group, src/dst pair, bandwidth | TR-06 |
| FT-04 | Origin identification incl. NAT-translated addresses | TR-09 |
| FT-05 | Mitigation suggestions shown | TR-10 |
| FT-06 | Risk levels and severity mapping | TR-15 |
| FT-07 | Custom rule create → test on history → enable → version | TR-19 |
| FT-08 | Subnet/CIDR profiling and per-CIDR thresholds | TR-21, SOW-04 |
| FT-09 | TCP/UDP port profiles | TR-28 |
| FT-10 | Application bandwidth graph (values match the dataset) | TR-29 |
| FT-11 | Packet-rate profile | TR-30 |
| FT-12 | Hour/day/week profiles | TR-31 |
| FT-13 | HTTP content-type view (cleartext/proxy) | TR-33 |
| FT-14 | Alert → flows → sessions → packets in one console | TR-39 |
| FT-15 | PCAP retrieval, playback/download, integrity hash, capture-loss warning | TR-40a, DR-10 |
| FT-16 | Retention: raw ≥ 7 d, normalized ≥ 15 d, deletion audit, legal hold | TR-41 |
| FT-17 | RBAC per role (UI and API) | security §4 |
| FT-18 | Audit records for all listed events | security §10 |
| FT-19 | Physical + virtual sources ingested. Capture NIC transmit = 0. | TR-16, TR-17 |
| FT-20 | Multiple remote (SLDC-like) flow sources centrally ingested | TR-23 |

## 7. Integration tests (IT)

From S-07 §12.

| ID | Test | Pass condition |
|---|---|---|
| IT-01 | Alert delivery to SIEM | Event appears with correct fields and severity |
| IT-02 | Duplicate delivery | Repeat send creates no duplicate in the SIEM |
| IT-03 | Pipeline replay idempotency | Replaying a queue offset range creates no duplicate records or alerts |
| IT-04 | SIEM outage | Events queue locally and arrive in order after recovery |
| IT-05 | Directory login | Correct role. Access removed when removed from the group. |
| IT-06 | Directory outage | Console follows the cache policy. Break-glass works and is alerted. |
| IT-07 | Flow ingest per exporter model | Records parse. Counters match the exporter. Templates and sampling handled. |
| IT-08 | Vulnerability import | New vulnerable host detected with the correct scan date |
| IT-09 | TI feed import | Valid batch imports. Tampered batch rejected. Rollback works. |
| IT-10 | SIEM end-to-end with the OPTCL SIEM parser | SIEM shows parsed fields. Back-link opens NBAD evidence. |
| IT-11 | Sandbox round trip | Test file submitted. Verdict stored and linked. |
| IT-12 | Firewall NAT log correlation | Internal host identified for outbound flows |
| IT-13 | Proxy log enrichment | URL/category/user attached to sessions |
| IT-14 | IPS/VPN log ingestion | IPS alerts normalised. VPN user↔IP mapping applied. |
| IT-15 | Response suggestion/prepare | Suggestion and prepared change shown. **Nothing sent to any device.** |

## 8. Resilience tests (RT)

| ID | Test | Expected (system-architecture §9) |
|---|---|---|
| RT-01 | Sensor failure | Overlap/standby continues. Alarm. Gap recorded. |
| RT-02 | Queue node loss | No data loss. No consumer stall. |
| RT-03 | Analytics store node loss | Search available. Resync. |
| RT-04 | Packet archive node/disk loss | Data retrievable from the replica |
| RT-05 | PostgreSQL primary loss | Failover within the agreed RTO. Alerts buffered. |
| RT-06 | App/API node loss | No user-visible outage beyond a re-login |
| RT-07 | Configuration restore | Restore within RTO. Verified against the export. |
| RT-08 | Site recovery exercise | Per the agreed DR plan (Q-14) |
| RT-09 | Time drift on a sensor | Offset alarm. Evidence flagged. |

Record time to detect, time to recover, data lost and lessons for each (S-09 §11).

## 9. Benchmarks and security tests

- Benchmarks B-01 to B-13: [capacity-and-resilience §7](../architecture/capacity-and-resilience.md).
- Security tests ST-01 to ST-08: [security-and-airgap §18](../architecture/security-and-airgap.md).

## 10. POC / acceptance tests (S-02 §13)

| ID | Test | Built on | Pass condition |
|---|---|---|---|
| T1 | Monitor three zones | FT-01 | Coverage and zone visibility. Loss threshold to agree. |
| T2 | Scanning and traffic spike | DT-01 to DT-03 | Correct alert, supporting flows, source/target evidence, timestamps |
| T3 | Behavioural baseline | DT-21 | Baseline established, deviation detected, explanation available |
| T4 | Low-and-slow | DT-16 | Long-window correlation detects the deviation |
| T5 | Non-standard port/application | DT-08, DT-20 | Correct classification for supported protocols. Limits documented. |
| T6 | Forensic retrieval | FT-14, FT-15, B-06 | Alert→flow→packet linkage. Integrity and replay evidence. |
| T7 | 5M-record benchmark | B-05 | Agreed query and dataset. ≤ 180 s under the agreed conditions. |
| T8 | 512 Mbps capture | B-01 | Agreed traffic profile. Loss and resources within agreed limits. |
| T9 | Retention | FT-16 | Raw 7 d / normalized 15 d verified with documented definitions |
| T10 | SIEM correlation | IT-01, IT-02, IT-10 | Delivery, IDs, deduplication, end-to-end timing |
| T11 | Failure recovery | RT-01 to RT-06 | Recovery time, data loss, impact measured |
| T12 | Air gap | ST-01, ST-07 | Detection and search continue without external access. Offline update audited. |

## 11. Defect and result handling

- Every failed test raises a tracked defect with severity and phase.
- Results go into `docs/testing/results/` (created when the first result exists), one file per run.
- The traceability matrix status changes to "Verified" only with a link to a passing result.
