# NBAD Requirements Traceability Matrix

**Status:** draft v0.1 (2026-10-24).

**Status values used:**

| Status | Meaning |
|---|---|
| Designed | Addressed in the proposed architecture. Nothing is implemented. |
| Partial (limit) | Can only partly be met, for a documented reason |
| Blocked | Needs an answer first |
| Commercial | Not an engineering deliverable |

**No requirement is Implemented or Verified at this date.** Columns:

| Column | Meaning |
|---|---|
| Component | IDs from [system-architecture §3.1](../architecture/system-architecture.md) |
| Validation | Test IDs from [test-strategy](../testing/test-strategy.md): FT functional, DT detection, IT integration, B benchmark, ST security, RT resilience, T POC |
| Evidence required | What must exist before any compliance answer can be "Yes" (OBL-06, OBL-07) |

## 1. Technical requirements (Schedule-9 §11)

| Req | Summary | Component(s) | Design reference | Validation | Status | Evidence required | Blockers |
|---|---|---|---|---|---|---|---|
| TR-01 | ≥ 3 zones | CMP-PGS (zone model), CMP-NRM, CMP-UI | system-architecture §6 | FT-01, T1 | Designed | 3 zones configured with traffic visible per zone in the POC | Q-03 |
| TR-02 | Single centralized dashboard | CMP-UI, CMP-API | system-architecture §11, ADR-008 | FT-02, T-POC "unified console" | Designed | Demo plus a feature walkthrough record | — |
| TR-03 | Malware and botnets | CMP-DET (beaconing, TI, signature), CMP-INT (sandbox) | S-06 §3, system-architecture §12 | DT-06, DT-19, IT-11 | Partial (limit): indirect detection only | Test records per scenario + limitation statement | Q-22, Q-24 |
| TR-04 | APT and Trojans | CMP-DET (graph, longitudinal, TI) | S-06 §3 | DT-16, DT-17, DT-19 | Partial (limit) | As TR-03 | — |
| TR-05 | Worm propagation on a service port | CMP-DET (graph fan-out) | S-06 §3 | DT-05 | Designed | Lab propagation test passed | — |
| TR-06 | Pattern analysis by IP, groups, pairs, bandwidth | CMP-FST, CMP-API, CMP-UI | data-flow §5.1 | FT-03 | Designed | Query/report demo with expected results | — |
| TR-07 | Real-time host behaviour monitoring | CMP-DET, CMP-UI | system-architecture §8 | B-08, FT-02 | Designed | Measured latency vs the agreed target | AM-06 |
| TR-08 | DoS/DDoS, scanning, worms, unexpected services, tunnelling, backdoors, forbidden protocols, policy violations | CMP-DET | S-06 §3 | DT-01 to DT-05, DT-08, DT-09, DT-12, DT-15 | Designed | Test record per category | Q-16 |
| TR-09 | Attack origin | CMP-NRM (NAT correlation), CMP-UI | system-architecture §5.4 | FT-04, IT-12 | Partial (limit): NAT and spoofing | Test with NAT logs or inside capture | Q-13 |
| TR-10 | Real-time mitigation suggestions | CMP-RSP | integration-design §4, ADR-012 | IT-15 | Designed | Suggestions shown on DoS/DDoS alerts in the test | Q-34 |
| TR-11 | (a) event/action list; (b) slow and small attacks; (c) limitations | Docs, CMP-DET (longitudinal) | S-06 §3, §9; system-architecture §12 | DT-16, document review | Designed | Published detection catalogue + limitations document, both based on tests | — |
| TR-12 | Long-lived connections (exfiltration) | CMP-DET, CMP-NRM (stitching) | data-flow §5.1 `segment` | DT-07 | Designed | Lab test passed | — |
| TR-13 | Apps on non-standard ports | CMP-SEN (DPD), CMP-DET | technology-evaluation §2.2 | DT-08 | Designed (cleartext/handshake-visible protocols) | Lab test passed + encryption limit stated | — |
| TR-14 | Unnecessary ports/services | CMP-DET (new service, policy), CMP-PGS (service policy) | S-06 §3 | DT-09, DT-12 | Designed | Test with an OPTCL-defined service policy | Q-16 |
| TR-15 | Risk levels | CMP-COR, CMP-DET scoring | data-flow §5.4, S-06 §6 | FT-06 | Designed | Severity mapping table agreed with the SOC | — |
| TR-16 | Physical and virtual environments | CMP-SEN, CMP-FLC | system-architecture §5.3 | FT-19 | Blocked | Test with the virtual traffic source | Q-05 |
| TR-17 | Centralized, non-intrusive monitoring | CMP-SEN/FLC (passive) | ADR-001 | FT-19, ST-01 (no transmit on capture NICs) | Designed | Config review + capture NIC transmit counter = 0 | — |
| TR-18 | Anomalous events, threshold alerting | CMP-DET | S-06 §3–4 | DT-03, DT-21 | Designed | Test passed | — |
| TR-19 | Custom rule creation | CMP-API, CMP-UI, CMP-DET | S-06 §8 | FT-07 | Designed | Create, test-on-history and enable demonstrated | — |
| TR-20 | Risky applications | CMP-SEN (app ID), CMP-DET | technology-evaluation §2.2 | DT-13 | Designed | Lab test per app category in scope | App category list |
| TR-21 | Profiling by subnet/CIDR | CMP-PGS (CIDR groups), CMP-FST | system-architecture §6 | FT-08 | Designed | Demo | — |
| TR-22 | Compatible with industry appliances for flow analysis | CMP-FLC, CMP-LGC | integration-design INT-03/04 | IT-07 | Blocked | Compatibility matrix with tested models only | Q-09, Q-23 |
| TR-23 | Scalable to SLDC distributed deployment | CMP-FLC (central), zone model | system-architecture §5.3, §10 | FT-20 | Designed | Multi-site flow ingestion test (simulated sites acceptable for function) | Q-08, C-02 |
| TR-24 | Undiscovered patterns; future new patterns | CMP-DET (new edge/host/country, baselines, ML), rule/content updates | ADR-004, S-06 §5 | DT-18, DT-21, ST-07 (content update) | Designed | Test passed + offline content-update rehearsal | — |
| TR-25 | Integrations + supported/unsupported product list | CMP-INT, CMP-LGC | integration-design §2–3 | IT-01 to IT-14 | Blocked | Compatibility matrix from test results | Q-10, Q-20 to Q-23 |
| TR-26 | Capture NetFlow and packets | CMP-FLC, CMP-SEN | system-architecture §5 | IT-07, B-01 | Designed | Both paths demonstrated | — |
| TR-27 | Apps on other ports; tunnelled apps (IM over HTTP) | CMP-SEN (DPD/app ID), CMP-DET | technology-evaluation §2.2 | DT-08, DT-20 | Partial (limit): encrypted tunnels | Lab test + limitation statement | — |
| TR-28 | Profile by TCP/UDP port | CMP-FST, CMP-UI | — | FT-09 | Designed | Demo | — |
| TR-29 | Application bandwidth graph | CMP-FST, CMP-UI | system-architecture §11 | FT-10 | Designed | Demo with correct values vs the test dataset | — |
| TR-30 | Packet-rate profiles | CMP-FST, CMP-UI | — | FT-11 | Designed | Demo | — |
| TR-31 | Week/day/hour profiles | CMP-BMS, CMP-UI | data-flow §5.8 | FT-12, DT-21 | Designed | Demo + baseline deviation test | — |
| TR-32 | New hosts; vulnerable new hosts via scanner input | CMP-NRM (asset discovery), CMP-INT (INT-08), CMP-DET | data-flow §5.7 | DT-10, DT-11, IT-08 | Designed | Test passed | Q-21 |
| TR-33 | HTTP data types in/out | CMP-SEN (HTTP), CMP-LGC (proxy) | data-flow §5.2, C-07 | FT-13, IT-13 | Partial (limit): cleartext/proxy only | Demo + limitation statement | Q-23 |
| TR-34 | Regular global threat-intel feed | CMP-TIF, CMP-DET | security-and-airgap §7, INT-09 | IT-09, DT-19, ST-08 | Partial (limit): offline cadence (C-05) | Import rehearsal + freshness statement | Q-24 |
| TR-35 | Data stays within premises; approval for outbound | All. Egress controls. | security-and-airgap §9 | ST-01 | Designed | Egress soak test + outbound path register | Q-27 |
| TR-36 | 5M records ≤ 180 s | CMP-FST, CMP-API (export) | capacity-and-resilience §7 B-05, ADR-022 | B-05, T7 | Blocked | Benchmark under the agreed definition on representative hardware | Q-01 |
| TR-37 | ML for unlimited hosts, no added licence | CMP-DET (ML), licensing | ADR-010 | DT-18, licence review | Commercial + Designed | Written commercial position + component licence evidence | Q-11 |
| TR-38 | Capture network traffic | CMP-SEN | — | B-01 | Designed | Capture test | — |
| TR-39 | Logs and raw packets in one console | CMP-UI, CMP-API, CMP-PCA | ADR-008 | FT-14, T6 | Designed | Alert→flow→packet workflow demo | — |
| TR-40a | Continuous capture, index, playback of all network data; prioritised info | CMP-SEN, CMP-PCA, CMP-UI | system-architecture §5.2, C-12 | FT-15, B-06, T6 | Designed (bounded by TR-41 retention) | Playback/retrieval demo + B-06 | — |
| TR-40b | Unknown-country traffic: country, business context, IPs; isolate; payload; sandbox | CMP-NRM (GeoIP, asset context), CMP-DET, CMP-UI, CMP-INT | C-08, INT-10 | DT-14, IT-11 | Designed (sandbox Blocked) | Test passed | Q-22, Q-31, Q-34 |
| TR-41 | Raw 7 days; normalized 15 days | CMP-PCA, CMP-FST, retention jobs | data-flow §11, capacity §4 | FT-16, T9, B-13 | Blocked (definition) | Retention verification over a ≥ 15-day run | Q-02, Q-19 |
| TR-42 | ≥ 512 Mbps Internet capture at DC | CMP-SEN | capacity §4.2 | B-01, T8 | Blocked (basis) | B-01 on representative hardware at 130% | Q-04, Q-29 |

## 2. Scope of work

| Req | Component(s) | Validation | Status |
|---|---|---|---|
| SOW-01 | Whole platform | T1 to T12 | Designed |
| SOW-02 | Deployment topology (DC/Main LDC) | Phase 13 | Designed |
| SOW-03 | CMP-FLC | IT-07 | Blocked (Q-09) |
| SOW-04 | Zone/CIDR policies, CMP-DET | FT-08, DT-12 | Designed |
| SOW-05 | CMP-INT (INT-01) | IT-01, IT-02, IT-04, IT-10, T10 | Blocked (Q-10) |
| SOW-06 | CMP-DET tuning lifecycle (S-06 §10) | DT false-positive measurement | Designed |
| SOW-07 | CMP-BMS, tuning workflow | DT-21 | Designed |

## 3. Obligations

| Req | Architecture response | Validation | Status |
|---|---|---|---|
| OBL-01 | Component EOL inventory (capacity-and-resilience §5.7), DR-05 | Inventory review | Designed |
| OBL-02 | Support routes (technology-evaluation §6) | Commercial | Commercial (Q-28) |
| OBL-03 | HA design, monitoring, runbooks. 24x7 staffing is not an architecture item. | RT-01 to RT-08, T11 | Designed (the 99.9% target is not proven) |
| OBL-04 | No SPOF (system-architecture §7, §9). ÷ 0.7 sizing (ADR-011). | RT-xx, B-04 | Designed (AD-07 exception pending) |
| OBL-05 | Air-gap design (security-and-airgap) | ST-01, ST-07, T12 | Designed |
| OBL-06 | DR-07: claim only tested capabilities | This matrix | Process |
| OBL-07 | Compliance column filled by the bid lead from the evidence above | — | Commercial |

## 4. Derived requirements

| Req | Where addressed | Validation |
|---|---|---|
| DR-01, DR-02 | security-and-airgap §6, §9 | ST-01 |
| DR-03 | ADR-011, capacity §1 | B-04, B-01 |
| DR-04 | system-architecture §9 | RT-01 to RT-08 |
| DR-05 | technology-evaluation §6 | Commercial review |
| DR-06 | data-flow §5.4–5.5 | DT-all (evidence check) |
| DR-07 | This matrix | Bid review |
| DR-08 | ADR-001 | FT-19 |
| DR-09 | security-and-airgap §14 | RT-09 (time drift) |
| DR-10 | data-flow §5.10, system-architecture §5.4 | B-01, FT-15 |
