# NBAD Requirements Baseline

**Project:** OPTCL Next Generation SOC & NOC — Network Behaviour Anomaly Detection (NBAD)
**Document status:** Draft v0.1 (2026-10-24) — extracted from the working copy, not validated against the original tender
**Phase:** 0 — Repository and requirements

## 1. Sources inspected

| ID | Source file (repository root) | Nature | Reliability for requirements |
|---|---|---|---|
| S-01 | `11_NBAD.docx` | Developer response sheet. Working copy of tender Schedule-9 §11 (tender pages 92–94 of 107), 42 rows | **Primary**, but it is a working copy. The original tender prevails. The compliance and remarks columns are empty. |
| S-02 | `NBAD_Project_Blueprint_OPTCL.docx` | Internal design blueprint v0.1, derived from S-01 | Proposal and analysis. Not a requirement source. |
| S-03 | `NBAD System Architecture Specification.docx` | Internal companion v0.1 | Proposal |
| S-04 | `NBAD Technology Stack and Tooling Guide.docx` | Internal companion v0.1 | Candidate list. Nothing is committed. |
| S-05 | `NBAD Data Model and Schema Specification.docx` | Internal companion v0.1 | Proposal |
| S-06 | `NBAD Detection Engineering Playbook.docx` | Internal companion v0.1 | Proposal. All thresholds are placeholders. |
| S-07 | `NBAD Integration Specification.docx` | Internal companion v0.1 | Proposal. Products are unknown. |
| S-08 | `NBAD Capacity Planning and Sizing Workbook.docx` | Internal companion v0.1 | Scenario calculations only |
| S-09 | `NBAD High Availability, Recovery and Operations Runbook.docx` | Internal companion v0.1 | Proposal. Targets are placeholders. |
| S-10 | `NBAD Air-Gap Operations and Security Design.docx` | Internal companion v0.1 | Proposal |
| S-11 | `Pasted 24-10-2026 at 12.22.19.textClipping` | Architecture-phase working instructions from the project lead | Governs process and constraints, not customer requirements |

**Not available:** the original 107-page tender, including Annexure-2 (§1.1(q), §1.1(s), §1.2(j), §1.3, §3.1-D, §4, §5), Schedule-4, Schedule-13, the PQR clauses and the POC criteria text. Every clause reference below comes from S-01 and is **unverified** against the original.

S-01 refers to its file as a 5-page sheet. S-02 notes that it was "prepared from the supplied 5-page NBAD developer response sheet".

## 2. Classification legend

| Tag | Meaning |
|---|---|
| **EXPLICIT** | Stated in S-01, the tender working copy. Must still be verified against the original tender. |
| **DERIVED** | Necessarily implied by an EXPLICIT requirement. The interpretation is ours. |
| **PROPOSED** | Comes from the internal design documents (S-02 to S-10). It is not a customer requirement. |
| **ASSUMPTION** | A working assumption. Listed in [ambiguities-and-conflicts.md](ambiguities-and-conflicts.md). |

## 3. Scope of work (tender Annexure-2 §3.1-D, as quoted in S-01)

| ID | Scope statement | Tag |
|---|---|---|
| SOW-01 | Monitor the network for unusual events or trends by collecting flows from network devices, to detect anomalous flows such as malware, identify user access policy violations, and give deep and broad visibility into all network traffic | EXPLICIT |
| SOW-02 | Implement the solution at DC/Main LDC | EXPLICIT |
| SOW-03 | Integrate network devices and collect flow records | EXPLICIT |
| SOW-04 | Configure policies for different segments and analyse flows | EXPLICIT |
| SOW-05 | Integrate with SIEM to enrich security alerts, support early detection and response, and provide a single view of the solution | EXPLICIT |
| SOW-06 | Use standard methodologies/models to reduce false positives and error rates | EXPLICIT |
| SOW-07 | Fine-tune the baseline profile for network access. Identify the network baseline and configure NBA policies. | EXPLICIT |

## 4. Obligations that apply to every module (as quoted in S-01)

| ID | Obligation | Clause cited in S-01 | Tag |
|---|---|---|---|
| OBL-01 | Latest available version, with a minimum 5-year End of Support Life (EOSL) from go-live | Annexure-2 1.1(s) / 1.2(j) | EXPLICIT |
| OBL-02 | Back-to-back comprehensive onsite OEM support for 5 years, plus an annual configuration audit by the OEM | Annexure-2 §5 item 6 | EXPLICIT |
| OBL-03 | 5-year onsite comprehensive warranty, 24x7x365 support, 99.9% uptime for the supplied solution | Annexure-2 §4 | EXPLICIT |
| OBL-04 | Redundancy/fault tolerance (no single point of failure) and at least 30% spare capacity at peak load | Annexure-2 1.1(q), 1.3 | EXPLICIT |
| OBL-05 | On-premises/air-gapped deployment. SOC event and alert data stay within OPTCL premises. | Module table (see TR-35) | EXPLICIT |
| OBL-06 | Everything stated in the bid becomes contractually binding. PQR 5 requires the core platform to work without depending on future roadmap features: answer "Yes" only for capabilities that exist today. | Annexure-2 preamble, PQR 5 | EXPLICIT |
| OBL-07 | Compliance answers must be exactly Yes / No / Can Be, with a datasheet or admin-guide reference. Anything that is not "Yes" goes to the bid lead for Schedule-4 (Techno-Commercial Deviation). | S-01 instructions, tender clause 11 | EXPLICIT (bid process) |

## 5. Technical requirements — Schedule-9 §11 (TR-01 … TR-42)

The wording below is condensed. S-01 has the exact text. "Category" groups requirements for traceability.

| ID | Requirement (condensed) | Category | Tag | Interpretation notes |
|---|---|---|---|---|
| TR-01 | Monitor and manage at least 3 separate zones | Coverage | EXPLICIT | The zone definition is unknown (Q-03). The working assumption is A-03. |
| TR-02 | Single centralized dashboard | Console | EXPLICIT | |
| TR-03 | Detect malware and botnets | Detection | EXPLICIT | Only indirect detection is possible (behaviour, threat intelligence, sandbox verdicts). See the visibility limits. |
| TR-04 | Detect APT and Trojan activity | Detection | EXPLICIT | Indirect, as for TR-03 |
| TR-05 | Detect an Internet worm from propagation behaviour on a service port | Detection | EXPLICIT | |
| TR-06 | Traffic pattern analysis by IP, IP groups, source/destination pairs, bandwidth, etc. | Analytics | EXPLICIT | |
| TR-07 | Real-time monitoring of host behaviour and traffic analysis | Analytics | EXPLICIT | "Real time" is undefined. The proposed latency budget is in system-architecture §8. |
| TR-08 | Detect DDoS/DoS, scanning, worms, unexpected application services (tunnelled protocols, backdoors, forbidden protocols), policy violations | Detection | EXPLICIT | |
| TR-09 | Identify where an attack originated | Detection | EXPLICIT | Limited by NAT and spoofing (Q-13) |
| TR-10 | Suggest mitigation measures for DoS/DDoS and similar events in real time | Response | EXPLICIT | Suggestion only. No automatic action by default (ADR-012). |
| TR-11 | (a) List the detectable events and any actions; (b) explain handling of slow, small attacks over long periods; (c) state overall limitations | Documentation / detection | EXPLICIT | Needs a deliverable document. See the detection catalogue and visibility limits. |
| TR-12 | Detect long-lived connections that may indicate exfiltration | Detection | EXPLICIT | |
| TR-13 | Detect applications on non-standard ports | Detection | EXPLICIT | Needs protocol identification (packet path) |
| TR-14 | Identify ports and services not needed for normal business operations | Detection / policy | EXPLICIT | Needs an OPTCL service policy (Q-16) |
| TR-15 | Classify events by risk level (High, Medium, Low, etc.) | Detection | EXPLICIT | |
| TR-16 | Analyse physical and virtual network environments | Coverage | EXPLICIT | The hypervisor is unknown (Q-05) |
| TR-17 | Centralized, non-intrusive traffic and flow-based monitoring | Collection | EXPLICIT | Passive only (ADR-001) |
| TR-18 | Detect anomalous security events, with threshold-based alerting | Detection | EXPLICIT | |
| TR-19 | Custom rule creation | Detection / console | EXPLICIT | |
| TR-20 | Identify traffic from risky applications (file sharing, P2P, …) | Detection | EXPLICIT | |
| TR-21 | Traffic profiling by logical network design (subnet/CIDR) | Analytics | EXPLICIT | |
| TR-22 | Compatible with industry-leading appliances (firewall, IPS, VPN, routers, …) for flow analysis | Integration | EXPLICIT | No product list is available (Q-09) |
| TR-23 | Support, and scale to cover, SLDC assets in a distributed deployment | Coverage | EXPLICIT | Conflicts in scope with SOW-02 (C-02) |
| TR-24 | Identify suspicious or previously undiscovered communication patterns, and support detection of newly discovered patterns in future | Detection | EXPLICIT | |
| TR-25 | Integrate with SIEM, VM, AD, LDAP, firewalls, IPS, VPN, routers, switches, Internet proxy, etc. List supported and unsupported products. | Integration | EXPLICIT | Needs a supported-products list deliverable |
| TR-26 | Capture NetFlow and packets | Collection | EXPLICIT | |
| TR-27 | Identify applications on non-well-known ports and applications tunnelling over other ports (for example, IM over HTTP classified as IM) | Detection | EXPLICIT | Limited by encryption |
| TR-28 | Profile traffic by TCP and UDP port | Analytics | EXPLICIT | |
| TR-29 | Application bandwidth utilisation graph | Console | EXPLICIT | |
| TR-30 | Traffic profiles by packet rate | Console / analytics | EXPLICIT | |
| TR-31 | Profiles in multiple timeframes: week, day, hour | Analytics | EXPLICIT | |
| TR-32 | Display new hosts on the network. Take inputs from other systems (for example, vulnerability scanners) and alert on new vulnerable hosts. | Detection / integration | EXPLICIT | |
| TR-33 | Display the type of data carried over HTTP into and out of the network | Analytics | EXPLICIT | Cleartext HTTP, or proxy logs, only (C-07) |
| TR-34 | Regular feed from global threat intelligence for proactive monitoring and alerting | Integration | EXPLICIT | Conflicts with the air gap; needs an offline import (C-05) |
| TR-35 | All events, alerts and other NG-SOC information stay within SLDC premises. Any outbound movement is reviewed and approved by SLDC on a need basis. | Data sovereignty | EXPLICIT | "SLDC" vs "OPTCL" premises (C-04) |
| TR-36 | Retrieve forensic results at "lightning speed": at least 5M records within 180 s | Performance | EXPLICIT | "Retrieve" and "record" are undefined (Q-01) |
| TR-37 | ML capability for unlimited hosts without additional licence | Licensing / analytics | EXPLICIT | Commercial interpretation pending (Q-11) |
| TR-38 | Capture network traffic | Collection | EXPLICIT | |
| TR-39 | Investigate logs and raw packet data from a single console | Console / forensics | EXPLICIT | |
| TR-40 | Support network threat detection use cases including (a) continuous monitoring: capture, index and **play back** all network data, with prioritised information for analysts; (b) suspicious traffic to an unknown country: country, business context and from/to IP; swift isolation and payload investigation; sandbox integration | Forensics / detection / integration | EXPLICIT | "Isolate" is read as analytical isolation (filtering), not network quarantine (C-08). "Play back all network data" is bounded by TR-41 retention. |
| TR-41 | Store RAW packet data for 7 days and normalized packet data for 15 days for forensics | Retention | EXPLICIT | "Normalized packet data" is undefined (Q-02) |
| TR-42 | Capture at least 512 Mbps of Internet traffic at the DC | Performance | EXPLICIT | Basis undefined: sustained/peak, per direction or aggregate (Q-04) |

S-01's last line reads "*Asterisked items in the firewall table are marked as printed in the tender.*" No NBAD row has an asterisk, and the NBAD sheet has no firewall table. This looks like template text carried over from another module. Recorded as C-09.

## 6. Derived non-functional requirements

These are our necessary interpretations of the EXPLICIT items above. Each needs customer confirmation.

| ID | Derived requirement | Derived from |
|---|---|---|
| DR-01 | No platform function may depend on Internet connectivity: install, update, licence, threat intelligence, geolocation, UI assets, time and DNS. | OBL-05, TR-35 |
| DR-02 | Every outbound data path is disabled by default and needs documented approval. | TR-35 |
| DR-03 | Every tier is sized so that peak load uses ≤ 70% of its tested capacity. | OBL-04 (30% spare), interpreted per C-03 |
| DR-04 | No component whose single failure stops collection, detection, alerting or the console in the production topology. | OBL-04 |
| DR-05 | All open-source components have a named support route for 5 years after go-live. | OBL-01, OBL-02 |
| DR-06 | Every alert is explainable and evidence-backed: evidence, rule/model version, observed vs expected. | SOW-06, TR-11, POC "Correlation & Incident Detection" |
| DR-07 | Compliance statements are made only for capabilities demonstrated in the current build. | OBL-06, OBL-07 |
| DR-08 | Monitoring is passive. Nothing goes inline or transmits on capture interfaces. | TR-17 |
| DR-09 | The timeline is accurate. All components are time-synchronised from local sources and the sync state is recorded. | TR-36, TR-39, TR-40 (forensic evidence) |
| DR-10 | Collection loss (packet drops, flow sequence gaps) is measured and shown against the affected evidence intervals. | TR-38, TR-42, DR-06 |

## 7. POC criteria fed by this module (S-01, indicative)

- Correlation & Incident Detection
- Unified single-console platform
- Product demonstration

The POC procedure and pass thresholds are not in the available sources (Q-15).

## 8. What this baseline is not

- It is **not** a compliance response. No TR row has been answered Yes, No or Can Be. That is a bid-lead/OEM responsibility under OBL-07.
- It does **not** state that any capability exists. At this date, no NBAD software has been built or tested.
