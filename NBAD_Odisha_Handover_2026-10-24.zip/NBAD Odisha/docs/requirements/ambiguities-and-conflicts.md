# Requirement Conflicts, Ambiguities and Working Assumptions

**Status:** Draft v0.1 (2026-10-24). Phase 0 output.
**Rule:** where sources disagree, this document records the conflict and a **proposed** resolution. No conflict is treated as resolved until the project lead or OPTCL approves the resolution. Open questions (Q-xx) are tracked in [../architecture/open-questions-and-risks.md](../architecture/open-questions-and-risks.md).

Source IDs (S-xx) and requirement IDs (TR-xx, SOW-xx, OBL-xx) are defined in [requirements-baseline.md](requirements-baseline.md).

## 1. Conflicts between or within sources

| ID | Conflict | Sources | Impact | Proposed resolution | Status |
|---|---|---|---|---|---|
| C-01 | The scope of work describes a **flow-collection** system ("by collecting flows from the network devices"). Several rows require **packet capture**, raw packet storage, playback and 512 Mbps capture. | SOW-01, SOW-03 vs TR-26, TR-38, TR-39, TR-40a, TR-41, TR-42 | Packet capture dominates cost: storage, sensors, archive. | Treat both as required. Full packet capture at the DC Internet edge (where TR-42 applies). Flow-first everywhere else. Per-site choice recorded in system-architecture §5. | Proposed |
| C-02 | The scope says "Implement the solution at DC/Main LDC". TR-23 requires the solution to "support and be scalable to cover assets of SLDC catering to distributed deployment". | SOW-02 vs TR-23 | Whether SLDC sites are in the first deployment or only a design capability | Design for distributed SLDC collection (flow export to central collectors). The first deployment covers DC/Main LDC. SLDC onboarding is a later phase unless OPTCL says otherwise. Needs Q-08. | Proposed |
| C-03 | **How "30% spare capacity" is computed.** S-02 §7.1 and S-08 §2 add a ×1.3 margin to the required capacity. That leaves only 23% of the total spare (0.3/1.3). S-03 §7 and S-09 §4 instead cap peak use at ≤ 70% of tested capacity, which means dividing by 0.7 (×1.43). | S-02, S-08 vs S-03, S-09, OBL-04 | ×1.3 under-sizes against a literal "30% spare" reading by about 10%. | Use the ≤ 70%-of-tested-ceiling rule (÷ 0.7) everywhere. The S-08 figures are restated in capacity-and-resilience §3. Confirm the exact definition in the tender (Q-26). | Proposed |
| C-04 | **Data locality boundary.** TR-35 says information must stay "within **SLDC** premises" and that SLDC approves any outbound movement. The module obligations say "within **OPTCL** premises". | TR-35 vs OBL-05 | Who approves outbound transfers, and whether central DC storage counts as "SLDC premises" | Treat the stricter reading as binding: no outbound path at all without written approval from the named approving authority. Ask OPTCL to name the boundary and the approver (Q-27). | Open |
| C-05 | TR-34 asks for a "regular feed from **global** threat intelligence". OBL-05 and TR-35 require an air-gapped, premises-only deployment. | TR-34 vs OBL-05, TR-35 | Live feeds cannot reach an air-gapped platform. | Offline, signed, batch import through the transfer zone (security-and-airgap §7). Feed freshness is limited by the approved import cadence, and this limit must be stated in the response. | Proposed |
| C-06 | S-07 §11 defines an "Automatic" response level (pre-approved automatic actions). TR-17, D-01 (S-03) and the architecture principles require non-intrusive, passive-first monitoring. TR-10 asks only for mitigation *suggestions*. | S-07 vs TR-17, TR-10, S-03 D-01 | Scope creep into active response. Risk of disrupting the OT/IT network. | First release: **Suggest** and **Prepare** only. "Execute with approval" stays a later, separately authorised option. "Automatic" is out of scope (ADR-012). | Proposed |
| C-07 | TR-33 asks to "display the type of data transported via HTTP into and out of the network". Most Internet HTTP traffic is TLS-encrypted, and NBAD does not decrypt it. | TR-33 vs visibility limits (S-06 §9) | The capability is partial. A "Yes" answer would overstate it. | Content type for cleartext HTTP, plus proxy-log enrichment if the proxy integration provides it. For TLS, only metadata (SNI, sizes, JA3/JA4-style fingerprints where available). State the limit in the response. | Proposed |
| C-08 | TR-40b says the analyst should "**isolate** such traffic swiftly and investigate the payload". "Isolate" could mean filtering in the console or network quarantine. | TR-40b vs TR-17, C-06 | Network quarantine is an active response. | Read it as analytical isolation: one-click filtering, pivoting and PCAP retrieval for the traffic. Network quarantine only through the approved response-action path (ADR-012). Confirm with OPTCL (Q-34). | Proposed |
| C-09 | S-01 ends with "Asterisked items in the firewall table are marked as printed in the tender". The NBAD sheet has no firewall table and no asterisked rows. | S-01 | The working copy may contain template text or have lost markers. | Check against the original tender (Q-15). Treat S-01 as possibly incomplete. | Open |
| C-10 | OBL-02 requires OEM onsite support for 5 years and an annual OEM configuration audit. S-02 §3 describes the product as a **new build**. | OBL-02 vs S-02 | If the platform is self-built, the bidder is in effect the OEM for it, while each open-source component has its own upstream. | Commercial and bid-lead decision (Q-28). Architecture impact: support routes are recorded per component (technology-evaluation §6). | Open |
| C-11 | TR-39 requires logs and raw packets in **one** console. S-04 notes that Arkime's own UI "may not satisfy the single-console requirement". | TR-39, TR-02 vs S-04 §3 | An off-the-shelf PCAP UI would become a second console. | Any PCAP subsystem is used as a back end only. Packet retrieval and playback are shown in the NBAD console (ADR-008). | Proposed |
| C-12 | TR-40a says "capture, index and play back **all** network data". S-08 §2.5 suggests capture filters and truncation to reduce storage. | TR-40a vs S-08 | Filtering may breach TR-40a. | No filtering or truncation at observation points that fall under TR-40a/TR-42 unless OPTCL approves it in writing. Filters stay a documented, approval-gated option. | Proposed |
| C-13 | TR-37 requires ML for unlimited hosts without an additional licence. Some candidate components are licensed per host, per flow or per interface (for example nProbe, commercial ML or NDR engines). | TR-37 vs S-04 | Licensing non-compliance | Prefer components without per-host or per-flow licensing for every analytics path (ADR-010). The commercial owner gives the written interpretation (Q-11). | Proposed |

## 2. Ambiguities that block sizing or acceptance

These are summaries. The full question, owner role and closure criteria are in open-questions-and-risks.md.

| ID | Ambiguity | Requirement | Why it matters | Linked question |
|---|---|---|---|---|
| AM-01 | What counts as a "record" in the 5M-record target, and what "retrieve" includes (execute, render, export, deliver), plus the time window, filters, concurrency and the load present during the test | TR-36 | The search-tier choice and hardware depend on it. Data moved varies about 5× with record size, and the workload varies even more with what "retrieve" includes. | Q-01 |
| AM-02 | "Normalized packet data": per-packet metadata, per-session records or a normalized payload copy | TR-41 | 15-day storage varies from low single-digit TB to about 83 TB (S-08 §5). | Q-02 |
| AM-03 | 512 Mbps: sustained or peak, per direction or aggregate, before or after NAT, which link | TR-42 | Sensor and archive sizing | Q-04 |
| AM-04 | Definition of the "3 separate zones" | TR-01 | Zone model, policies, baselines | Q-03 |
| AM-05 | 99.9% uptime: measurement window, service boundary, maintenance exclusions, whether degraded capture counts as down | OBL-03 | HA design scope | Q-14 |
| AM-06 | "Real time" (TR-07, TR-10) has no latency figure | TR-07, TR-10 | Detection pipeline design | Q-15 |
| AM-07 | "Lightning speed" (TR-36) beyond the 180 s figure | TR-36 | Treated as no additional requirement | Q-01 |
| AM-08 | Whether replicas and backups count toward the retention periods, and whether retention is a minimum, a maximum or both | TR-41 | Storage and deletion policy | Q-19 |
| AM-09 | BOQ "NBAD – 1 (unit not stated)" | Schedule-13 | Licence or commercial unit | Q-28 |

## 3. Working assumptions

Each assumption is used until it is confirmed or replaced. If an assumption changes, the documents listed in "Affects" must be re-checked.

| ID | Assumption | Basis | Affects | Confirm via |
|---|---|---|---|---|
| A-01 | S-01 reproduces the tender text accurately. | S-01 is the only requirement source available. | All | Q-15 |
| A-02 | NBAD is a self-built platform assembled from open-source components plus our own code. It is not a resold commercial NBAD product. | S-02 §3 "New product/build". Project brief (S-11). | Technology evaluation, licensing, support | Project lead |
| A-03 | Three zones: (Z1) Internet edge and DMZ; (Z2) data centre and server zones; (Z3) internal users, Main LDC and SLDC sites | S-03 §4.2 | Zone model, dashboards, baselines | Q-03 |
| A-04 | TR-42 is checked as 512 Mbps **aggregate of both directions, sustained**, at the DC Internet edge, captured **inside NAT** where possible. Sensors are additionally sized for 512 Mbps per direction as a stress case. | Conservative reading of S-01, S-03 §4.1 | Sensor and archive sizing | Q-04 |
| A-05 | Proposed definition **PD-01** for TR-36: a single forensic query over normalized flow/session records, filtered by time range and at least one entity attribute, returning ≥ 5,000,000 matching records exported to a file on the platform side within 180 s, measured while normal ingestion and detection are running | S-08 §6 recommendation | Search-tier choice and benchmark B-05 | Q-01 |
| A-06 | Proposed definition **PD-02** for TR-41: "normalized packet data" means per-session/protocol metadata records plus flow records. It excludes per-packet rows and payload copies. Raw payload is kept in PCAP for 7 days. | S-05 §14 and S-08 §5 (most common industry meaning). Not confirmed. | Storage sizing | Q-02 |
| A-07 | SLDC sites start flow-only, with no packet capture. | S-03 §4.1 | Collection design | Q-08 |
| A-08 | The SIEM accepts syslog over TLS in CEF or JSON. | S-07 §4 | Integration design | Q-10 |
| A-09 | Servers are Linux x86_64. The distribution is unknown. | Not stated anywhere | Packaging, hardening | Q-18, Phase 2 assessment |
| A-10 | The remote server to be provided is a development/prototype environment. It is not representative of production hardware or topology. | Not stated. Conservative. | What can be validated where (testing strategy §3) | Phase 2 assessment |
| A-11 | Concurrent analyst users ≤ 25 and concurrent forensic queries ≤ 5 (placeholders) | No source | API and search sizing | Q-32 |
| A-12 | Retention periods in TR-41 are **minimums**. Longer retention is allowed if storage permits, with deletion governed by OPTCL policy. | Wording "should store … for" | Retention jobs | Q-19 |
