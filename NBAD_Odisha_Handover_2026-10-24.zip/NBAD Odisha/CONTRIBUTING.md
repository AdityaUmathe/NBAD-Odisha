# Contributing to NBAD

## 1. Where work happens (mandatory)

| Activity | Local machine | Authorised remote server |
|---|---|---|
| Edit documentation and planning files | ✔ | ✔ |
| Static checks on documentation (link and ID checks, text search) | ✔ | ✔ |
| Write application source code | ✘ (until instructed) | ✔ (Phase 3+) |
| Install packages, runtimes, databases, container engines | ✘ | ✔ only per the approved server plan |
| Build, run services, run tests, capture packets | ✘ | ✔ only per the approved plan |
| Deploy | ✘ | ✔ only after the acceptance and approval gates |
| Connect to any server | ✘ unless authorised | Only the host(s) the project lead names |

On the remote server: inspect before changing anything, respect existing workloads, do not assume Internet access, and never restart, overwrite, expose or remove existing services without explicit authorisation.

## 2. Phase discipline

Follow the gate rules in [docs/implementation/master-checklist.md](docs/implementation/master-checklist.md). Work on one phase at a time and stop at each gate.

## 3. Documentation conventions

- Use the IDs consistently:

  | Prefix | Used for |
  |---|---|
  | TR, SOW, OBL, DR | Requirements |
  | C, AM, A | Conflicts, ambiguities, assumptions |
  | Q, R | Questions, risks |
  | ADR, AD | Decisions |
  | CMP | Components |
  | INT | Integrations |
  | B, DT, FT, IT, RT, ST, T | Tests |

  Add new IDs at the end of each sequence. Never reuse or renumber an ID.
- Label content as EXPLICIT, DERIVED, PROPOSED, ASSUMPTION, Estimate or Unverified.
- **Never claim** a capability, compatibility, performance figure, compliance or approval without a linked evidence record.
- Never invent owners, approvals, server resources, benchmark results or customer requirements.
- Mermaid is used for diagrams.
- Dates are ISO (YYYY-MM-DD). Times in data are UTC.

## 4. Secrets

No passwords, private keys, tokens, real credentials or customer secrets in any file, commit message, log or document. Use placeholders such as `${SECRET:name}`. A secret-pattern scan is part of the static checks.

## 5. Changes

- Record meaningful changes in [CHANGELOG.md](CHANGELOG.md).
- A change to an Accepted ADR needs a new, superseding ADR.
- Source documents (`*.docx`) are inputs and are not edited. Corrections go into the Markdown documents with a reference.

## 6. Future code conventions (applies from Phase 3)

These conventions are set in Phase 3 on the remote server: configuration kept apart from code, structured logging, explicit error handling, health endpoints, tests per component, versioned schemas and APIs, dependency inventory with licences.
