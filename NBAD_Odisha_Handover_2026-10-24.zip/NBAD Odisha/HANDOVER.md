# NBAD Project — Handover Note

**Date:** 2026-10-24
**From:** the previous project lead (reassigned), with the AI-assisted engineer (Claude Code)
**To:** the incoming NBAD team

## 1. What this project is

NBAD (Network Behaviour Anomaly Detection) for the OPTCL Next Generation SOC & NOC. It is a passive, on-premises, air-gap-capable platform that detects anomalous network behaviour from mirrored packets and exported flows. It keeps flow, session and packet evidence, provides one analyst console, and sends alerts to the SIEM. The requirements come from the tender working copy `11_NBAD.docx` (Schedule-9 §11, 42 rows).

## 2. Where things stand

| Item | Status |
|---|---|
| Phase 0 — requirements | **Done** (documentation) |
| Phase 1 — architecture & technology decisions | **Done** (documentation). **Waiting for approval** of decisions AD-01 to AD-14. |
| Phase 2 — remote server assessment | **Not started.** No server credentials were ever provided. No server was accessed. |
| Application code | **None written.** Nothing installed, built, run, benchmarked or deployed. |
| Compliance answers (Yes/No/Can Be) | **Not answered**. That belongs to the bid lead. |
| Version control | Not a Git repository yet (decision AD-10) |

## 3. Rules the previous lead set (please keep them, or change them deliberately)

1. **Remote-server-only development.** Nothing is installed, built or run on local machines. All development, testing and deployment happens only on a server the project lead explicitly authorises (ADR-023).
2. **Inspect the server read-only first**, report the findings, get approval, and only then change anything. Never disturb existing workloads.
3. **Work one phase at a time** and stop at each gate for the lead's instruction (gate rules: `docs/implementation/master-checklist.md` §1).
4. **No unsupported claims.** Nothing is called implemented, compliant or performant without a test record. Owners, approvals and benchmark numbers are never invented.
5. **No secrets** in files, Git or logs.
6. Do not assume Internet access. The target is air-gapped.

## 4. Read in this order

1. `README.md` — overview and layout
2. `docs/architecture/README.md` — architecture in one paragraph, plus the index
3. `docs/architecture/architecture-decisions.md` — the **14 decisions waiting for approval** (AD list at the bottom)
4. `docs/architecture/open-questions-and-risks.md` — 35 open questions, 22 risks
5. `docs/requirements/ambiguities-and-conflicts.md` — 13 conflicts found in the source documents
6. `docs/implementation/master-checklist.md` — phase status and next steps
7. `docs/handover/chat-transcript.md` — readable export of the working session (the prompts used and the assistant's answers)

## 5. Key outcomes of the session

- **Provisional technology direction (not approved):**
  - Option C: ClickHouse for flows and sessions; PostgreSQL for alerts, incidents and config; a custom PCAP writer with per-session index; Kafka; Zeek (Suricata pending); goflow2; Go services; React console; systemd + Ansible; no Kubernetes.
  - Option A (OpenSearch + Arkime) is the fallback.
  - Scorecard: C 3.90, A 3.75, B 3.45. The gap is within the uncertainty, so benchmark gates G-T1 to G-T6 decide.
- **Main conflicts:**
  - The ×1.3 margin vs the "30% spare" requirement (now ÷ 0.7).
  - The flow-only scope wording vs the packet-capture rows.
  - "SLDC premises" vs "OPTCL premises" for where data must stay.
  - The global threat-intel feed vs the air gap.
  - Who acts as "OEM" for a self-built platform.
- **Top blocking questions:**
  - Definition of "5M records in 180 s" (Q-01) and of "normalized packet data" (Q-02).
  - The basis of the 512 Mbps figure (Q-04).
  - The three-zone definition (Q-03).
  - Measured traffic (Q-07).
  - SIEM product (Q-10).
  - Air-gap boundary (Q-12).
  - RTO/RPO (Q-14).
  - The original tender (Q-15).
  - The ML licensing interpretation (Q-11).
- **Effort estimate given to the previous lead** (indicative, not a commitment): about 140–225 working days (about 7–11 months) for the full build. That excludes waiting on OPTCL, procurement and access, which can add 1–3 months. The internal blueprint (S-02) shows 22 weeks for a narrower scope. Re-estimate after Phase 2.

## 6. Immediate next steps for the new team

1. Assign a project lead and record the new owners. The documents use roles only.
2. Review and decide AD-01 to AD-14, then record the results in `architecture-decisions.md` and `CHANGELOG.md`.
3. Get the original 107-page tender and check the requirements baseline against it (Q-15).
4. Send the P1 questions to OPTCL and the bid lead.
5. Decide on version control (AD-10) and put this folder under Git.
6. Provide the remote server details (see `docs/operations/remote-server-prerequisites-and-assessment.md` §1) and start Phase 2 with the read-only assessment.

## 7. Package contents

Everything in this folder:

- the 10 source `.docx` documents (unchanged);
- the original project-brief clipping;
- 21 Markdown documents;
- this note.

No scratch files, tool caches or credentials are included.
